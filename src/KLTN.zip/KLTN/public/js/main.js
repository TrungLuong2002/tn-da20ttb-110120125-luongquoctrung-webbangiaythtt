$(document).ready(function () {

    var chart = new Morris.Line({

        element: 'myfirstchart',
        Linecolor: ['#819C79', 'fc8710', '#FF6541', 'A4ADD3', '#766B56'],
        pointFillColors: ['#fff'],
        pointStrokeColors: ['black'],
        parseTime: false,

       

        xkey: 'ngay_dat',

        ykeys: ['ma_don','tong_tien'],

        labels: ['Mã đơn hàng','tổng tiền']
    });
    $('#tuy-chon').change(function () {
        var ngay = $(this).val();
        var _token = $('input[name="_token"]').val();
        $.ajax({
            type: "POST",
            url: "http://localhost/laravel/KLTN/admin/thongke/tinh",
            data: { ngay: ngay, _token: _token },
            dataType: "JSON",
            success: function (data) {
                chart.setData(data);
                console.log(data);
                
            }
        });

    });

    // var chart = new Morris.Line({
    //     element: 'myfirstchart',
    //     lineColors: ['#819C79', 'fc8710', '#FF6541', 'A4ADD3', '#766B56'],
    //     pointFillColors: ['#fff'],
    //     pointStrokeColors: ['black'],
    //     parseTime: false,
    //     xkey: 'ngay_dat',
    //     ykeys: ['ma_don', 'tong_tien'],
    //     labels: ['Mã đơn hàng', 'Tổng tiền']
    // });

    // function fetchData(ngay) {
    //     var _token = $('input[name="_token"]').val();
    //     $.ajax({
    //         type: "POST",
    //         url: "/laravel/KLTN/admin/thongke/tinh",
    //         data: { ngay: ngay, _token: _token },
    //         dataType: "JSON",
    //         success: function (data) {
    //             chart.setData(data);
    //         }
    //     });
    // }


    // fetchData('7ngay');

    // $('#tuy-chon').change(function () {
    //     var ngay = $(this).val();
    //     fetchData(ngay);
    // });

})