$(document).ready(function() {
    $('#tab-rating').click(function() {
        $('#tab-rating').addClass('active');
        $('#tab-comment').removeClass('active');
        $('#content-rating').addClass('active');
        $('#content-comment').removeClass('active');
    });

    $('#tab-comment').click(function() {
        $('#tab-comment').addClass('active');
        $('#tab-rating').removeClass('active');
        $('#content-comment').addClass('active');
        $('#content-rating').removeClass('active');
    });
});
