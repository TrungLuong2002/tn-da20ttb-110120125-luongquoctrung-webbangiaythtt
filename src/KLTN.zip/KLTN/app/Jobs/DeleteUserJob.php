<?php

namespace App\Jobs;

use App\Models\UserModel;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class DeleteUserJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
  
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $now = Carbon::now();
        
        // Lấy tất cả user có Dinh_Danh=1 và created_at hơn 10 giây so với hiện tại
        $users = UserModel::where('Dinh_Danh', 1)
            ->where('created_at', '<', $now->subSeconds(10))
            ->get();
        
        // Duyệt qua từng user và xoá
        foreach ($users as $user) {
            $user->delete();
        }
    }
}
