<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TT_DatHangModel extends Model
{
    use HasFactory;
    protected $table='TT_Dat_Hang';
    protected $fillable=['Don_Hang_id','TT_Thanh_Toan','Id_Giao_Dich'];
    public $timestamps = false;
}
