<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OderModel extends Model
{
    use HasFactory;
   protected $table='Don_Hang';
   protected $primaryKey = 'Don_Hang_id';
   protected $fillable=['User_id','Phuong_Thuc_id','Tong_Tien','Ghi_Chu','Trang_Thai','Dia_Chi'];
   public function User()
    {
        return $this->belongsTo(UserModel::class, 'User_id', 'User_id');
    }
    public function Phuong_Thuc()
    {
        return $this->belongsTo(MethodModel::class, 'Phuong_Thuc_id', 'Phuong_Thuc_id');
    }
    public function orderDetails()
    {
        return $this->hasMany(OderDetailModel::class,'Don_Hang_id','Don_Hang_id');
    }
}
