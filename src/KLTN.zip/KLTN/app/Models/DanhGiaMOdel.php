<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DanhGiaMOdel extends Model
{
    use HasFactory;
    protected $table='Danh_Gia';
    protected $primaryKey = 'Danh_Gia_id';
    protected $fillable=['User_id','Ma_SP','So_Sao','Noi_Dung','Ngay_Danh_Gia'];
    public function User()
    {
        return $this->belongsTo(UserModel::class, 'User_id', 'User_id');
    }
    public function product()
    {
        return $this->belongsTo(productModel::class, 'Ma_SP', 'Ma_SP');
    }
   
}
