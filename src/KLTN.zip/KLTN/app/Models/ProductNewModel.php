<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductNewModel extends Model
{
    use HasFactory;
    protected $table='SP_Moi';
    public function product()
    {
        return $this->belongsTo(ProductModel::class, 'Ma_SP', 'Ma_SP');
    }
}
