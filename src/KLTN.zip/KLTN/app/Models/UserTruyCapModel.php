<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserTruyCapModel extends Model
{
    use HasFactory;
    protected $table='User_Truy_Cap';
    protected $fillable=['IP','Ngay'];
    public $timestamps = false;
}
