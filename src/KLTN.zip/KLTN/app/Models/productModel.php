<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class productModel extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'San_Pham'; 
    protected $primaryKey = 'San_Pham_id';

   protected $fillable=['Ma_SP','Ten_SP','Gia','Gia_cu','Img','Mo_Ta','Ma_Loai'];

   
    public function getproductNB()
    {
        return $this->hasOne(ProductNoiBacModel::class, 'Ma_SP', 'Ma_SP');
    }
}
