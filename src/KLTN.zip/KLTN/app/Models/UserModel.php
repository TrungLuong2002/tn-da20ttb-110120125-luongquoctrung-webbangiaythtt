<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserModel extends Model
{
    use HasFactory;
    protected $table='User';
    protected $primaryKey = 'User_id';
    public function diaChi()
    {
        return $this->hasOne(AddressModel::class, 'Dia_Chi_id', 'Dia_Chi_id');
    }
    public function orders()
    {
        return $this->hasMany(OderModel::class,'User_id','User_id');
    }
}
