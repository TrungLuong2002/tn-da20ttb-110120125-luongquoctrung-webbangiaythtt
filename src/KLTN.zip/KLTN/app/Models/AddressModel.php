<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AddressModel extends Model
{
    use HasFactory;
    protected $table ='Dia_Chi';
    protected $primaryKey = 'Dia_Chi_id';
    public function Tinh()
    {
        return $this->belongsTo(ProvineModel::class, 'Tinh_id', 'Tinh_id');
    }
}
