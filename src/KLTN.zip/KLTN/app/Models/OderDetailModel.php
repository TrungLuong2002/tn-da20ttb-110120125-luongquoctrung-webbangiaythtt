<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OderDetailModel extends Model
{
    use HasFactory;
    protected $table='Chi_Tiet_Don';
    protected $fillable=['Don_Hang_id','Chi_Tiet_SP_id','So_Luong','Tong_Tien'];
    protected $primaryKey = 'Chi_Tiet_Don_id';

    public function orders()
    {
        return $this->hasMany(OderModel::class,'Don_Hang_id','Don_Hang_id');
    }
    public function productdetail()
    {
        return $this->belongsTo(ProductDetailModel::class, 'Chi_Tiet_SP_id', 'Chi_Tiet_SP_id');
    }

}
