<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BinhLuanModel extends Model
{
    use HasFactory;
    protected $table='Binh_Luan';
    protected $primaryKey = 'Binh_Luan_id';
    protected $fillable=['Binh_Luan_id','Ten_User','Ma_SP','Binh_Luan','Tra_Loi','Ngay'];
    public $timestamps = false;

}
