<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductNoiBacModel extends Model
{
    use HasFactory;
   protected $table='SP_Noi_Bac';
   protected $primaryKey = 'SP_NB_id';
   public $timestamps = false;
    public function product()
    {
        return $this->belongsTo(ProductModel::class, 'Ma_SP', 'Ma_SP');
    }
}
