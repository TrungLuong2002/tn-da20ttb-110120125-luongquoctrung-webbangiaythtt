<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TruyCapModel extends Model
{
    use HasFactory;
    protected $table='Truy_Cap';
    protected $fillable=['IP','Ngay_Truy_Cap'];
    public $timestamps = false;
}
