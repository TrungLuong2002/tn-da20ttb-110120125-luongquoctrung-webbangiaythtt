<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
class AdminUserController extends Controller
{
    function show(){
        $user = UserModel::with('diaChi.Tinh')->get();
     
        return view('admin.user.user',compact('user'));
    }
    function deleteuser($id){
        $user = UserModel::where('User_id',$id);
     $user->delete();
        return redirect()->back();
    }
}
