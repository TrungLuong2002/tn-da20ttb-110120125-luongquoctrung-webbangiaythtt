<?php

namespace App\Http\Controllers;

use App\Models\AdminModel;
use App\Models\BinhLuanModel;
use App\Models\DanhGiaMOdel;
use App\Models\OderDetailModel;
use App\Models\OderModel;
use App\Models\ProductDetailModel;
use App\Models\productModel;
use App\Models\TruyCapModel;
use App\Models\UserModel;
use App\Models\UserTruyCapModel;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    function login()
    {
        $useradmin = $_POST['useradmin'];
        $passadmin = $_POST['passadmin'];
        $admin = AdminModel::where('UserAdmin', $useradmin)->where('PassAdmin', $passadmin)->first();
        if ($admin) {
            session()->put('adminlogin', 'Admin');
            session()->put('adminid', $admin->Admin_id);
            return redirect()->route('admin.index');
        } else {
            return back()->withErrors(['message' => 'Tên đăng nhập hoặc mật khẩu không đúng'])->withInput();
        }
    }
    function show()
    {
        $today = Carbon::now('Asia/Ho_Chi_Minh')->format('Y-m-d');
        $doanhthu = OderModel::whereDate('created_at', $today)->where('Trang_Thai', 'Đã duyệt')->get();
        $chuaxuli = OderModel::where('Trang_Thai', 'Đang xử lí')->get();
        $count_dt = 0;
        $count_xl = 0;
        foreach ($doanhthu as $item) {
            $count_dt += $item->Tong_Tien;
        }
        foreach ($chuaxuli as $item) {
            $count_xl++;
        }
        // --------------------
        $dau_thang = Carbon::now('Asia/Ho_Chi_Minh')->subMonth()->startOfMonth()->toDateString();
        $cuoi_thang = Carbon::now('Asia/Ho_Chi_Minh')->subMonth()->endOfMonth()->toDateString();
        $dau_thang_nay = Carbon::now('Asia/Ho_Chi_Minh')->startOfMonth()->toDateString();
        $now = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();

        $tong_thang_truoc = TruyCapModel::whereBetween('Ngay_Truy_Cap', [$dau_thang, $cuoi_thang])->get();
        $tong_thang_truoc_count = $tong_thang_truoc->count();

        $tong_thang_nay = TruyCapModel::whereBetween('Ngay_Truy_Cap', [$dau_thang_nay, $now])->get();
        $tong_thang_nay_count = $tong_thang_nay->count();

        $three_minutes_ago = Carbon::now('Asia/Ho_Chi_Minh')->subMinutes(10);
        $user_truy_cap = UserTruyCapModel::where('Ngay', '>=', $three_minutes_ago)->get();
        $user_truy_cap_count = $user_truy_cap->count();

        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;
    
      
        $user_new = UserModel::whereYear('created_at', $currentYear)
                             ->whereMonth('created_at', $currentMonth)
                             ->count();

        $user_count =  UserModel::all()->count();
        $order_count =  OderModel::all()->count();
        $comment_count = BinhLuanModel::all()->count();
        $product_count = productModel::all()->count();

        //   ---------------------------
        $orderDetails = OderDetailModel::all();

        $productCounts = $orderDetails->groupBy('Chi_Tiet_SP_id')->map->count();
        $result = [];
        foreach ($productCounts as $chiTietSpId => $count) {
            $productDetail = ProductDetailModel::find($chiTietSpId);
            if ($productDetail) {
                $maSp = $productDetail->Ma_SP;
                if (isset($result[$maSp])) {
                    $result[$maSp]['so_luong'] += $count;
                } else {
                    $result[$maSp] = [
                        'ma_sp' => $maSp,
                        'so_luong' => $count,
                    ];
                }
            }
        }


        $result = array_values($result);

        $resultJson = $result;


        return view('admin.index', compact(
            'count_dt',
            'count_xl',
            'tong_thang_truoc_count',
            'tong_thang_nay_count',
            'user_truy_cap_count',
            'user_new',
            'resultJson',
            'user_count',
            'order_count',
            'comment_count',
            'product_count'
        ));
    }
}
