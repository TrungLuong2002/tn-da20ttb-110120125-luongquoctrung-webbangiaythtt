<?php

namespace App\Http\Controllers;

use App\Models\OderDetailModel;
use App\Models\OderModel;
use App\Models\ProductDetailModel;
use App\Models\TT_DatHangModel;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;
use Srmklive\PayPal\Services\PayPal as PayPalClient;

class PaypalController extends Controller
{
    /**
     * create transaction.
     *
     * @return \Illuminate\Http\Response
     */
    public function createTransaction()
    {
        return view('user.paypal');
    }

    /**
     * process transaction.
     *
     * @return \Illuminate\Http\Response
     */
    public function processTransaction(Request $request)
    {
        
        if($request->session()->get('diachi')==""){
            return redirect()->back()->with('tb','vui lòng cập nhật địa chỉ.');
        }
        $tong = Cart::total();
        $total = str_replace(',', '', $tong);
        $total = str_replace('.', '', $tong);
        $tien = session('tien');
        $tien = ceil($total / 24000);




        $provider = new PayPalClient;
        $provider->setApiCredentials(config('paypal'));
        $paypalToken = $provider->getAccessToken();

        $response = $provider->createOrder([
            "intent" => "CAPTURE",
            "application_context" => [
                "return_url" => route('successTransaction'),
                "cancel_url" => route('cancelTransaction'),
            ],
            "purchase_units" => [
                0 => [
                    "amount" => [
                        "currency_code" => "USD",
                        "value" => $tien
                    ]
                ]
            ]
        ]);

        if (isset($response['id']) && $response['id'] != null) {

            // redirect to approve href
            foreach ($response['links'] as $links) {
                if ($links['rel'] == 'approve') {
                    return redirect()->away($links['href']);
                }
            }

            return redirect()
                ->route('createTransaction')
                ->with('error', 'Something went wrong.');
        } else {
            return redirect()
                ->route('Trangchu')
                ->with('error', $response['message'] ?? 'Something went wrong.');
        }
    }

    /**
     * success transaction.
     *
     * @return \Illuminate\Http\Response
     */
    public function successTransaction(Request $request)
    {
        $provider = new PayPalClient;
        $provider->setApiCredentials(config('paypal'));
        $provider->getAccessToken();
        $response = $provider->capturePaymentOrder($request['token']);

        if (isset($response['status']) && $response['status'] == 'COMPLETED') {

            $total = Cart::total();
            // $total = str_replace(',', '', $total); 
            // $total = str_replace('.', '', $total); 
            $phuong_thuc = 3;
            $tong_tien = $total;

            $trang_thai = 'Đã Thanh Toán';
            $date = date("Y-m-d");
            $order = new OderModel();
            $order->User_id = $request->session()->get('userid');
            $order->Phuong_Thuc_id = $phuong_thuc;
            $order->Tong_Tien = $tong_tien;

            $order->Trang_Thai = $trang_thai;
            $order->Ngay_Dat = $date;
            $order->Dia_Chi=$request->session()->get('diachi');
            $order->save();
            $don_hang_id = $order->getKey();
            foreach (Cart::content() as $item) {
                $id_sp = ProductDetailModel::where('Ma_SP', $item->id)
                    ->where('Ten_Mau', $item->options->color)
                    ->where('Kich_Thuoc', $item->options->size)
                    ->first();

                $id_sp->So_Luong = $id_sp->So_Luong - $item->qty;
                $id_sp->save();

                $orderdetail = new OderDetailModel();
                $orderdetail->Don_Hang_id = $don_hang_id;
                $orderdetail->Chi_Tiet_SP_id = $id_sp->Chi_Tiet_SP_id;
                $orderdetail->So_Luong = $item->qty;
                $orderdetail->Tong_Tien = $item->total;
                $orderdetail->save();
            }
            $tt_dathang = new TT_DatHangModel();
            $tt_dathang->Don_Hang_id = $don_hang_id;
            $tt_dathang->TT_Thanh_Toan = "Thanh Toán Paypal";
            $tt_dathang->Id_Giao_Dich = $response['id'];
            $tt_dathang->save();
            Cart::destroy();
            return redirect()->route('user.order.duyet');
        } else {
            return redirect()
                ->route('Trangchu')
                ->with('error', $response['message'] ?? 'Lỗi.');
        }
    }

    /**
     * cancel transaction.
     *
     * @return \Illuminate\Http\Response
     */
    public function cancelTransaction(Request $request)
    {
        return redirect()
            ->route('Trangchu')
            ->with('error', $response['message'] ?? 'You have canceled the transaction.');
    }
}
