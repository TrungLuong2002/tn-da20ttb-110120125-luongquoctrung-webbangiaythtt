<?php

namespace App\Http\Controllers;

use App\Models\ColorModel;
use App\Models\LoaiModel;
use App\Models\ProductDetailModel;
use App\Models\productModel;
use App\Models\SizeModel;
use Illuminate\Http\Request;

class AdminProductController extends Controller
{
    function show()
    {
        $product = productModel::simplePaginate(5);
        $product_het = ProductDetailModel::where('So_Luong', 0)->count();

        return view('admin.product.product', compact('product', 'product_het'));
    }
    public function showdetail($Ma_SP)
    {
        $product_detail = ProductDetailModel::where('Ma_SP', $Ma_SP)->get();
        $product_ten = productModel::where('Ma_SP', $Ma_SP)->first();
        return view('admin.product.productdetail', compact('product_detail', 'product_ten'));
    }

    function showcreate()
    {
        $maloai = LoaiModel::all();
        return view('admin.product.create', compact('maloai'));
    }
    public function createproduct(Request $request)
    {
        $request->validate([
            'ma_sp' => [
                'required',
                'regex:/^(GNTT|GNUTT|GNCC|GNSD|PK|GNUCG)[0-9]*$/'
            ],
            'ten_sp' => 'required',
            'gia' => 'required|numeric',
            'gia_cu' => 'numeric|nullable',
            'img' => 'required|image|mimes:jpeg,png,jpg,gif',
            'mo_ta' => 'required',
        ], [
            'ma_sp.required' => 'Vui lòng nhập mã sản phẩm.',
            'ma_sp.regex' => 'Mã sản phẩm phải bắt đầu bằng GNTT, GNUTT, GNCC, GNSD, PK, GNUCG.',
            'ten_sp.required' => 'Vui lòng nhập tên sản phẩm.',
            'gia.required' => 'Vui lòng nhập giá sản phẩm.',
            'gia.numeric' => 'Giá sản phẩm phải là số.',
            'gia_cu.numeric' => 'Giá sản phẩm phải là số.',
            'img.required' => 'Vui lòng chọn ảnh cho sản phẩm.',
            'img.image' => 'Tập tin phải là hình ảnh.',
            'img.mimes' => 'Định dạng hình ảnh phải là jpeg, png, jpg hoặc gif.',
            'mo_ta.required' => 'Vui lòng nhập mô tả sản phẩm.',
        ]);
        $product_count = productModel::where('Ma_SP', $request->input('ma_sp'))->count();
        if ($product_count > 0) {
            $tb = "Đã tồn tại mã sản phẩm: " . $request->input('ma_sp');
            return back()->with('tb', $tb)->withInput();
        }
        if ($request->hasFile('img')) {
            $image = $request->file('img');
            $name = $image->getClientOriginalName();
            $image->move('public/uploads/images', $name);
            $part = 'uploads/images/' . $name;
        }
        $product = new productModel();
        $product->Ma_SP = $request->input('ma_sp');
        $product->Ten_SP = $request->input('ten_sp');
        $product->Gia = $request->input('gia');
        $product->Gia_cu = $request->input('gia_cu');
        $product->Mo_Ta = $request->input('mo_ta');
        $product->Ma_Loai = $request->input('ma_loai');
        $product->Img = $part;
        $product->save();
        return redirect()->route('admin.product');
    }
    function showcreatedetail()
    {
        $color = ColorModel::all();
        $size = SizeModel::all();
        $product = productModel::all();
        return view('admin.product.createdetail', compact('color', 'size', 'product'));
    }
    function createdetailproduct(Request $request)
    {
        $request->validate([
            'ma_sp' => 'required',
            'color' => 'required',
            'size' => 'required',
            'soluong' => 'required|numeric',
        ], [
            'ma_sp.required' => 'Vui lòng chọn mã sản phẩm.',
            'color.required' => 'Vui lòng chọn màu sắc.',
            'size.required' => 'Vui lòng chọn kích thước.',
            'soluong.numeric' => 'Số lượng phải là số.',
            'soluong.required' => 'Vui lòng nhập số lượng.',
        ]);

        $masp = $request->input('ma_sp');
        $color = $request->input('color');
        $size = $request->input('size');
        $soluong = $request->input('soluong');
        $product = ProductDetailModel::where('Ma_SP', $masp)->where('Ten_Mau', $color)->where('Kich_Thuoc', $size)->get();
        $count = count($product);
        if ($count > 0) {
            $tb = 'Đã tồn tại chi tiết trên';
            return back()->with('tb', $tb)->withInput();
        } else {
            $productdetail = new ProductDetailModel();
            $productdetail->Ma_SP = $masp;
            $productdetail->Ten_Mau = $color;
            $productdetail->Kich_Thuoc = $size;
            $productdetail->So_Luong = $soluong;
            $productdetail->save();
            return redirect()->route('admin.product');
        }
    }

    public function deleteproduct($id)
    {
        $product = productModel::find($id);
        $product->delete();
        return redirect()->route('admin.product');
    }
    public function thungrac()
    {
        $rac = productModel::onlyTrashed()->get();
        return view('admin.product.thungrac', compact('rac'));
    }
    public function khoiphuc($id)
    {
        productModel::onlyTrashed()->where('San_Pham_id', $id)->restore();
        return redirect()->route(('admin.product.rac'));
    }
    public function xoavv($id)
    {
        productModel::onlyTrashed()->where('San_Pham_id', $id)->forceDelete();
        return redirect()->route(('admin.product.rac'));
    }
    public function updateshow($id)
    {
        $product = productModel::find($id);
        $maloai = LoaiModel::all();
        return view('admin.product.update', compact('product', 'maloai'));
    }
    public function updateproduct(Request $request, $id)
    {
        $request->validate([
            'ma_sp' => 'required',
            'ten_sp' => 'required',
            'gia' => 'required|numeric',

            'img' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'mo_ta' => 'required',
        ], [
            'ma_sp.required' => 'Vui lòng nhập mã sản phẩm.',
            'ten_sp.required' => 'Vui lòng nhập tên sản phẩm.',
            'gia.required' => 'Vui lòng nhập giá sản phẩm.',
            'gia.numeric' => 'Giá sản phẩm phải là số.',

            'img.required' => 'Vui lòng chọn ảnh cho sản phẩm.',
            'img.image' => 'Tập tin phải là hình ảnh.',
            'img.mimes' => 'Định dạng hình ảnh phải là jpeg, png, jpg hoặc gif.',
            'img.max' => 'Kích thước tập tin ảnh không được vượt quá 2MB.',
            'mo_ta.required' => 'Vui lòng nhập mô tả sản phẩm.',
        ]);

        if ($request->hasFile('img')) {
            $image = $request->file('img');
            $name = $image->getClientOriginalName();
            $image->move('public/uploads/images', $name);
            $part = 'uploads/images/' . $name;
        }
        $product = productModel::find($id);
        $product->Ma_SP = $request->input('ma_sp');
        $product->Ten_SP = $request->input('ten_sp');
        $product->Gia = $request->input('gia');
        $product->Gia_cu = $request->input('gia_cu');
        $product->Ma_Loai = $request->input('ma_loai');
        $product->Img = $part;
        $product->Mo_Ta = $request->input('mo_ta');
        $product->save();
        return redirect()->route('admin.product');
    }
    public function deleteproductdetail($id)
    {
        $productdetail = ProductDetailModel::find($id);
        $productdetail->delete();
        return redirect()->route('admin.product.detail', ['Ma_SP' => $productdetail->Ma_SP]);
    }
    public function thungracdetail()
    {
        $rac = ProductDetailModel::onlyTrashed()->get();
        return view('admin.product.thungracdetail', compact('rac'));
    }
    public function khoiphucdetail($id)
    {
        ProductDetailModel::onlyTrashed()->where('Chi_Tiet_SP_id', $id)->restore();
        return redirect()->route(('admin.product.racdetail'));
    }
    public function xoavvdetail($id)
    {
        ProductDetailModel::onlyTrashed()->where('Chi_Tiet_SP_id', $id)->forceDelete();
        return redirect()->route(('admin.product.racdetail'));
    }
    public function updatedetailshow($id)
    {
        $productdetail = ProductDetailModel::find($id);
        $size = SizeModel::all();
        $color = ColorModel::all();
        return view('admin.product.updatedetail', compact('productdetail', 'size', 'color'));
    }
    public function updateproductdetail(Request $request, $id)
    {
        $productdetail = ProductDetailModel::find($id);

        if ($productdetail->Ten_Mau == $request->input('color') && $productdetail->Kich_Thuoc == $request->input('size')) {
            $tb = "Đã tồn tại";
            return back()->with('tb', $tb)->withInput();
        } else {
            $productdetail->Kich_Thuoc = $request->input('size');
            $productdetail->Ten_Mau = $request->input('color');
            $productdetail->save();
            return redirect()->route('admin.product');
        }
    }

    public function searchproduct(Request $request)
    {

        $product = productModel::where('Ma_SP','like', '%' . $request->input('search') . '%')
            ->orWhere('Ten_SP', 'like', '%' . $request->input('search') . '%')
            ->get();
        $title = $request->input('search');
        return view('admin.product.productseach', compact('product', 'title'));
    }
}
