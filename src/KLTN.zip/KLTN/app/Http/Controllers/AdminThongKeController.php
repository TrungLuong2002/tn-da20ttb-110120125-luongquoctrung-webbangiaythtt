<?php

namespace App\Http\Controllers;

use App\Models\OderModel;
use App\Models\TruyCapModel;
use App\Models\UserModel;
use App\Models\UserTruyCapModel;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdminThongKeController extends Controller
{
    public function show()
    {
        return view('admin.thongke.doanhthu');
    }
    public function tinh(Request $request)
    {
        $data = $request->all();
        $today = Carbon::now('Asia/Ho_Chi_Minh')->format('d-m-Y H:i:s');
        $sub7ngay = Carbon::now('Asia/Ho_Chi_Minh')->subDay(7)->toDateString();
        $startOfLastMonth = Carbon::now('Asia/Ho_Chi_Minh')->startOfMonth()->subMonth()->toDateString();
        $endOfLastMonth = Carbon::now('Asia/Ho_Chi_Minh')->subMonth()->endOfMonth()->toDateString();
        $now = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();
        $sub30ngay = Carbon::now('Asia/Ho_Chi_Minh')->subDay(30)->toDateString();
        
        $chart_data = [];
    
        if ($data['ngay'] == '7ngay') {
            $get = OderModel::whereBetween('Ngay_Dat', [$sub7ngay, $now])->orderBy('Ngay_Dat', 'ASC')->get();
        } elseif ($data['ngay'] == 'thang-truoc') {
            $get = OderModel::whereBetween('Ngay_Dat', [$startOfLastMonth, $endOfLastMonth])->orderBy('Ngay_Dat', 'ASC')->get();
        } elseif ($data['ngay'] == '30ngay') {
            $get = OderModel::whereBetween('Ngay_Dat', [$sub30ngay, $now])->orderBy('Ngay_Dat', 'ASC')->get();
        } else {
            $get = collect();
        }
    
        foreach ($get as $item) {
            $chart_data[] = [
                'ma_don' => $item->Don_Hang_id,
                'tong_tien' => is_numeric($item->Tong_Tien) ? number_format($item->Tong_Tien) : 0,
                'ngay_dat' => $item->Ngay_Dat
            ];
        }
    
        return response()->json($chart_data);
    }
    public function user(Request $request)
    {
        $dau_thang = Carbon::now('Asia/Ho_Chi_Minh')->subMonth()->startOfMonth()->toDateString();
        $cuoi_thang = Carbon::now('Asia/Ho_Chi_Minh')->subMonth()->endOfMonth()->toDateString();
        $dau_thang_nay = Carbon::now('Asia/Ho_Chi_Minh')->startOfMonth()->toDateString();
        $now = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();

        $tong_thang_truoc = TruyCapModel::whereBetween('Ngay_Truy_Cap', [$dau_thang, $cuoi_thang])->get();
        $tong_thang_truoc_count = $tong_thang_truoc->count();

        $tong_thang_nay = TruyCapModel::whereBetween('Ngay_Truy_Cap', [$dau_thang_nay, $now])->get();
        $tong_thang_nay_count = $tong_thang_nay->count();

        $three_minutes_ago = Carbon::now('Asia/Ho_Chi_Minh')->subMinutes(10);
        $user_truy_cap = UserTruyCapModel::where('Ngay', '>=', $three_minutes_ago)->get();
        $user_truy_cap_count = $user_truy_cap->count();

        $usernew = UserModel::whereDate('created_at', $now)->get();
        $count_user=0;
        foreach($usernew as $item){
            $count_user++;
        }
        return view('admin.thongke.user', compact('tong_thang_truoc_count', 'tong_thang_nay_count', 'user_truy_cap_count','count_user'));
    }
}
