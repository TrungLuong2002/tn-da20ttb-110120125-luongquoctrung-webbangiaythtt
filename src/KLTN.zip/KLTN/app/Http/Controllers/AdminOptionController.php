<?php

namespace App\Http\Controllers;

use App\Models\ColorModel;
use App\Models\ImageModel;
use App\Models\ProductDetailModel;
use App\Models\productModel;
use App\Models\ProductNoiBacModel;
use App\Models\SizeModel;
use App\Models\SliderModel;
use Illuminate\Http\Request;

class AdminOptionController extends Controller
{
    function showimage()
    {
        $image = ImageModel::all()->groupBy('Ma_SP');

        return view('admin.product.showimage', compact('image'));
    }

    function showcreateimage()
    {
        $product = productModel::all();

        return view('admin.product.createimg', compact('product'));
    }
    function createimage(Request $request)
    {
        $request->validate([
            'ma_sp' => 'required',
            'image' => 'required',

        ], [
            'ma_sp.required' => 'Vui lòng chọn mã sản phẩm.',
            'image.required' => 'Vui lòng chọn ảnh.',

        ]);

        $image = ImageModel::where('Ma_SP', $request->input('ma_sp'))->get();
        $count = count($image);

        if ($count > 3) {
            $tb = "Vượt quá số lượng ảnh cho phép";
            return back()->with('tb', $tb)->withInput();
        } else {

            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $name = $image->getClientOriginalName();
                $image->move('public/uploads/images', $name);
                $part = 'uploads/images/' . $name;
            }
            $image = new ImageModel();
            $image->Ma_SP = $request->input('ma_sp');
            $image->Link = $part;
            $image->save();
            return redirect()->route('admin.product.showimage');
        }
    }
    function deleteimage_item($id)
    {
        $image = ImageModel::where('Anh_id', $id);
        $image->delete();
        return redirect()->route('admin.product.showimage');
    }
    function deleteimage($Ma_SP)
    {
        $image = ImageModel::where('Ma_SP', $Ma_SP);
        $image->delete();
        return redirect()->route('admin.product.showimage');
    }
    function showcolor()
    {
        $color = ColorModel::all();
        return view('admin.product.colorshow', compact('color'));
    }
    function createcolor(Request $request)
    {
        $request->validate([
            'ten_mau' => 'required',
        ], [
            'ten_mau.required' => 'Vui lòng chọn màu.',
        ]);


        $mau = ColorModel::where('Ten_Mau', $request->input('ten_mau'))->exists();
        if ($mau) {
            $tb = "Đã tồn tại vui lòng chọn màu khác";
            return back()->with('tb', $tb)->withInput();
        } else {
            $color = new ColorModel();
            $color->Ten_Mau = $request->input('ten_mau');
            $color->save();
            return redirect()->route('admin.product.showcrolor');
        }
    }
    function deletecolor($id)
    {
        $color = ColorModel::where('Mau_id', $id)->first();
        $color->delete();
        return redirect()->route('admin.product.showcrolor');
    }
    function updatecolor(Request $request)
    {
        $request->validate([
            'mau_cu' => 'required',
            'mau_moi' => 'required',
        ], [
            'mau_cu.required' => 'Vui lòng chọn màu.',
            'mau_moi.required' => 'Vui lòng nhập màu.',
        ]);

        $id = $request->input('mau_cu');
        $mau = ColorModel::where('Ten_Mau', $request->input('mau_moi'))->exists();
        if ($mau) {
            $tb2 = "Đã tồn tại vui lòng chọn màu khác";
            return back()->with('tb2', $tb2)->withInput();
        } else {
            $color = ColorModel::find($id);
            $color->Ten_Mau = $request->input('mau_moi');
            $color->save();
            return redirect()->route('admin.product.showcrolor');
        }
    }
    function showsize()
    {
        $size = SizeModel::all();
        return view('admin.product.sizeshow', compact('size'));
    }
    function createsize(Request $request)
    {
        $request->validate([
            'kich_thuoc' => 'required|numeric',
        ], [
            'kich_thuoc.required' => 'Vui lòng chọn kích thước.',
            'kich_thuoc.numeric' => 'kích thước là số.',
        ]);


        $kichthuoc = SizeModel::where('Kich_Thuoc', $request->input('kich_thuoc'))->exists();
        if ($kichthuoc) {
            $tb = "Đã tồn tại vui lòng chọn kích thước khác";
            return back()->with('tb', $tb)->withInput();
        } else {
            $size = new SizeModel();
            $size->Kich_Thuoc = $request->input('kich_thuoc');
            $size->save();
            return redirect()->route('admin.product.showsize');
        }
    }
    function deletesize($id)
    {
        $size = SizeModel::where('Kich_Thuoc_id', $id)->first();
        $size->delete();
        return redirect()->route('admin.product.showsize');
    }
    function updatesize(Request $request)
    {
        $request->validate([
            'kich_thuoc_cu' => 'required',
            'kich_thuoc_moi' => 'required|numeric',
        ], [
            'kich_thuoc_cu.required' => 'Vui lòng chọn kích thước.',
            'kich_thuoc_moi.required' => 'Vui lòng nhập kích thước.',
            'kich_thuoc_moi.numeric' => 'kích thước là số.',
        ]);

        $id = $request->input('kich_thuoc_cu');
        $size = SizeModel::where('Kich_Thuoc', $request->input('kich_thuoc_moi'))->exists();
        if ($size) {
            $tb2 = "Đã tồn tại vui lòng chọn kích thước khác";
            return back()->with('tb2', $tb2)->withInput();
        } else {
            $size = SizeModel::find($id);
            $size->Kich_Thuoc = $request->input('kich_thuoc_moi');
            $size->save();
            return redirect()->route('admin.product.showsize');
        }
    }

    public function showslider()
    {
        $slide = SliderModel::all();

        return view('admin.slider.show', compact('slide'));
    }
    public function createslidershow()
    {
        return view('admin.slider.showcreate');
    }
    public function createslider(Request $request)
    {
        $request->validate([

            'image' => 'required',

        ], [

            'image.required' => 'Vui lòng chọn ảnh.',

        ]);

        $image = SliderModel::all();
        $count = count($image);

        if ($count > 0) {
            $tb = "Vượt quá số lượng ảnh cho phép";
            return back()->with('tb', $tb)->withInput();
        } else {

            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $name = $image->getClientOriginalName();
                $image->move('public/uploads/images', $name);
                $part = 'uploads/images/' . $name;
            }
            $slider = new SliderModel();
            $slider->Link = $part;
            $slider->save();
            return redirect()->route('admin.slider');
        }
    }
    public function deleteslider($id)
    {
        $slide = SliderModel::find($id);
        $slide->delete();
        return redirect()->route('admin.slider');
    }

    public function shownoibac()
    {
        $product = ProductNoiBacModel::with('product')->get();

        return view('admin.product.shownoibac', compact('product'));
    }
    public function deletenoibac($id)
    {
        $product = ProductNoiBacModel::where('SP_NB_id', $id)->first();

        if ($product) {
            // Xóa sản phẩm
            $product->delete();
        }

        return redirect()->back();
    }
    public function showcreatenoibac()
    {
        $product = productModel::all();

        return view('admin.product.showcreatenoibac', compact('product'));
    }
    public function createnoibac(Request $request)
    {
        $request->validate([

            'ma_sp' => 'required',

        ], [

            'ma_sp.required' => 'Vui lòng chọn mã sản phẩm.',

        ]);
        $count = ProductNoiBacModel::where('Ma_SP', $request->input('ma_sp'))->count();
        if ($count > 0) {
            return redirect()->back()->with('tb', 'đã tồn tại');
        }
        $product_nb = new ProductNoiBacModel();
        $product_nb->Ma_SP = $request->input('ma_sp');
        $product_nb->save();
        return redirect()->route('admin.product.noibac');
    }
    public function showproducthet()
    {
        $product_het = ProductDetailModel::where('So_Luong', 0)->get();

        return view('admin.product.hethang', compact('product_het'));
    }
    public function capnhatsoluong(Request $request,$id)
    {
      $product=ProductDetailModel::find($id);
      $product->So_Luong=$request->input('soluong');
      $product->save();
        return redirect()->route('admin.product');
    }
}
