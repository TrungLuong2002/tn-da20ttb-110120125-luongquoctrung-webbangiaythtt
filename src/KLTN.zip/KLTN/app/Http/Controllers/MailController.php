<?php

namespace App\Http\Controllers;


use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use App\Mail\MailCheckOut;
use App\Mail\Mailhuy;
use App\Mail\MailLayMK;
use App\Mail\MailXacNhan;
use App\Models\OderDetailModel;
use App\Models\OderModel;
use App\Models\UserModel;
use Carbon\Carbon;

class MailController extends Controller
{
    function sendmail($id, $mail)
    {

        $order = OderModel::with('User')->where('Don_Hang_id', $id)->first();
        $orderDetail = OderDetailModel::where('Don_Hang_id', $id)->get();
        $data = [
            'order' => $order,
            'orderDetail' => $orderDetail,
            'user' => $order->User
        ];
        Mail::to($mail)->send(new MailCheckOut($data));
        $ordernew = OderModel::where('Don_Hang_id', $id)->first();;
        $ordernew->Trang_Thai = "Đã duyệt";
        $ordernew->save();
        return redirect()->route('admin.order');
    }
    function huydon($id, $mail)
    {

        $order = OderModel::with('User')->where('Don_Hang_id', $id)->first();
        $orderDetail = OderDetailModel::where('Don_Hang_id', $id)->get();
        $data = [
            'order' => $order,
            'orderDetail' => $orderDetail,
            'user' => $order->User
        ];
        Mail::to($mail)->send(new Mailhuy($data));
        $ordernew = OderModel::where('Don_Hang_id', $id)->first();;
        $ordernew->Trang_Thai = "Đã huỷ";
        $ordernew->save();
        return redirect()->route('admin.order');
    }
    function xacnhan(Request $request)
    {
        $request->validate([
            'fullname' => 'required',
            'username' => 'required',
            'password' => 'required',
            'email' => 'required|regex:/^[a-zA-Z0-9._%+-]+@gmail\.com$/',
            'phone' => 'required|numeric',



        ], [
            'fullname.required' => 'Vui lòng nhập tên.',
            'username.required' => 'Vui lòng nhập username.',
            'password.required' => 'Vui lòng nhập password.',
            'email.required' => 'Vui lòng nhập email.',
            'email.regex' => 'Email phải có định dạng xxx@gmail.com.',
            'phone.numeric' => 'Số điện thoại phải là dạng số.',
            'phone.required' => 'Vui lòng nhập sdt.',
        ]);
        $count_user_email = UserModel::where('Email', $request->input('email'))->count();
        $count_user_phone = UserModel::where('SDT', $request->input('phone'))->count();

        if ($count_user_email > 0) {
            return redirect()->back()->with('tb1', 'Email đã tồn tại vui lòng chọn email khác');
        }
        if ($count_user_phone > 0) {
            return redirect()->back()->with('tb2', 'Số điện thoại đã tồn tại vui lòng chọn số khác');
        }



        $fullname = $request->input('fullname');
        $username = $request->input('username');
        $password = $request->input('password');
        $email = $request->input('email');
        $phone = $request->input('phone');





        $data = time();

        Mail::to($request->input('email'))->send(new MailXacNhan($data));
        return view('user.xacnhan', compact('data', 'fullname', 'username', 'password', 'email', 'phone'));
    }
    public function checkmail(Request $request)
    {
        $fullname = $request->input('fullname');
        $username = $request->input('username');
        $password = $request->input('password');
        $email = $request->input('email');
        $phone = $request->input('phone');


        if ($request->input('giatri') == $request->input('data')) {
            $user = new UserModel();
            $user->FullName = $fullname;
            $user->Username = $username;
            $user->Password = $password;
            $user->Email = $email;
            $user->SDT = $phone;
            $user->save();
            return view('user.thanhcong');
        } else {
            $data = $request->input('data');
            $tb = "Sai mã";
            return view('user.xacnhan', compact('tb', 'data', 'fullname', 'username', 'password', 'email', 'phone'));
        }
    }
    function laylaimk(Request $request)
    {

        $user_email = UserModel::where('Email', $request->input('giatri'))->first();
        if (isset($user_email)) {
            $data = [
                'pass' => $user_email->Password

            ];
        } else {
            $data = [
                'pass' => ""

            ];
        }


        Mail::to($request->input('giatri'))->send(new MailLayMK($data));
        return view('user.Laythanhcong');
    }
}
