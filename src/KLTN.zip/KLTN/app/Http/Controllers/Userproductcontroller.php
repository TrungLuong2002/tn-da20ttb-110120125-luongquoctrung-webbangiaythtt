<?php

namespace App\Http\Controllers;

use App\Models\BinhLuanModel;
use App\Models\DanhGiaMOdel;
use Illuminate\Http\Request;
use App\Models\ProductModel;
use App\Models\ProductDetailModel;
use App\Models\ProductNoiBacModel;
use App\Models\ImageModel;
use App\Models\OderDetailModel;
use App\Models\SliderModel;
use App\Models\UserModel;
use Carbon\Carbon;

class Userproductcontroller extends Controller
{
    public function show()
    {

        $productNam = ProductModel::where('Ma_Loai', 'ML001')->get();
        $productNu = ProductModel::where('Ma_Loai', 'ML002')->get();
        $productNB = ProductNoiBacModel::with('product')->get();
        $productNew = ProductModel::orderBy('San_Pham_id', 'desc')->take(8)->get();
        $banner=SliderModel::all();
        return view('user.Trangchu', compact('productNam', 'productNu', 'productNB', 'productNew','banner'));
    }
    public function showDetail($id, $Ma_SP)
    {

        $productDetail = ProductModel::where('San_Pham_id', $id)->first();
        $pro_detail=ProductDetailModel::where('Ma_SP',$Ma_SP)->get();
        $comment=BinhLuanModel::all();
        $count_sl = 0;
        foreach ($pro_detail as $item) {
            $count_sl += $item->So_Luong;
        }
         
      

        $color = ProductDetailModel::where('Ma_SP', $Ma_SP)
            ->distinct()
            ->pluck('Ten_Mau');


        $size = ProductDetailModel::where('Ma_SP', $Ma_SP)
            ->distinct()
            ->pluck('Kich_Thuoc');

        $img = ImageModel::where('Ma_SP', $Ma_SP)->get();
        $product_lq = ProductModel::where('Ma_Loai', $productDetail->Ma_Loai)->get();

        // --------------------
        $danhgia = DanhGiaMOdel::where('Ma_SP', $Ma_SP)->get();
        $userId = session()->get('userid');
        $count_cm = OderDetailModel::whereHas('orders', function ($query) use ($userId) {
            $query->where('User_id', $userId)
                ->whereIn('Trang_Thai', ['Đã duyệt', 'Đã Thanh Toán']);
        })->whereHas('productdetail', function ($query) use ($Ma_SP) {
            $query->where('Ma_SP', $Ma_SP);
        })->count();
        $sodanhgia = DanhGiaMOdel::where('Ma_SP', $Ma_SP)->get()->count();
        $sosao = $danhgia->sum('So_Sao');
        if ($sodanhgia > 0) {
            $tbsao = ceil($sosao / $sodanhgia);
        } else {
            $tbsao = 0;
        }

        return view('user.UserproductDetail', compact('productDetail', 'color', 'size', 'img', 'danhgia', 'product_lq', 'count_cm', 'tbsao','count_sl','comment'));
    }
    public function danhgia(Request $request, $id_user, $Ma_SP)
    {
        $id_sp = productModel::where('Ma_SP', $Ma_SP)->first();
        $danhgia = new DanhGiaMOdel();
        $danhgia->User_id = $id_user;
        $danhgia->Ma_SP = $Ma_SP;
        $danhgia->So_Sao = $request->input('rating');;
        $danhgia->Noi_Dung = $request->input('review');
        $danhgia->Ngay_Danh_Gia = Carbon::now();
        $danhgia->save();

        return redirect()->route('User.productDetail', ['id' => $id_sp->San_Pham_id, 'Ma_SP' => $Ma_SP]);
    }
    public function comment(Request $request, $Ma_SP)
    {
        $comment = new BinhLuanModel();
        $comment->Ten_User=$request->input('name');
        $comment->Ma_SP=$Ma_SP;
        $comment->Binh_Luan=$request->input('comment');
        $comment->Ngay= Carbon::now();
        $comment->save();
       
        return redirect()->back();
    }
    public function showAll($action, $name)
    {
        if ($action == "all") {
            $productAll = ProductModel::all();
        } elseif ($action == "ML001") {
            $productAll = ProductModel::where('Ma_Loai', 'ML001')->get();
        } elseif ($action == "ML002") {
            $productAll = ProductModel::where('Ma_Loai', 'ML002')->get();
        } elseif ($action == "GNTT") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'GNTT' . '%')->get();
        } elseif ($action == "GNSD") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'GNSD' . '%')->get();
        } elseif ($action == "GNUTT") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'GNUTT' . '%')->get();
        } elseif ($action == "GNUCG") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'GNUCG' . '%')->get();
        } elseif ($action == "PK") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'PK' . '%')->get();
        }

        return view('user.UserproductAll', compact('productAll', 'action', 'name'));
    }

    public function loc(Request $request, $name)
    {
        $action = $request->input('action');
        if ($action == "all") {
            $query = ProductModel::query();
        } elseif ($action == "ML001") {
            $query = ProductModel::where('Ma_Loai', 'ML001');
        } elseif ($action == "ML002") {
            $query = ProductModel::where('Ma_Loai', 'ML002');
        } elseif ($action == "GNTT") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'GNTT' . '%');
        } elseif ($action == "GNSD") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'GNSD' . '%');
        } elseif ($action == "GNUTT") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'GNUTT' . '%');
        } elseif ($action == "GNUCG") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'GNUCG' . '%');
        } elseif ($action == "PK") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'PK' . '%');
        }

        if ($request->has('loc') && $request->loc != '') {
            if ($request->loc == 'cao-den-thap') {
                $query->orderBy('Gia', 'desc');
            } elseif ($request->loc == 'thap-den-cao') {
                $query->orderBy('Gia', 'asc');
            } elseif ($request->loc == 'nho200') {
                $query->where('Gia', '<', 200000);
            } elseif ($request->loc == '200den500') {
                $query->whereBetween('Gia', [200000, 500000]);
            } elseif ($request->loc == 'tren500') {
                $query->where('Gia', '>', 500000);
            }
        }
        

        $productAll = $query->get();
        return view('user.UserproductAll', compact('productAll', 'action', 'name'));
    }
    public function search(Request $request)
    {
        $key = $request->input('search');
        $product_search = ProductModel::where('Ten_SP', 'like', '%' . $key . '%')->get();
        return view('User.Usersearch', compact('product_search', 'key'));
    }
    public function getcolor(Request $request)
    {
        $productId = $request->input('id');
        $productMaSP = $request->input('Ma_SP');


        $colors = ProductDetailModel::where('Ma_SP', $productMaSP)
        ->distinct()
        ->pluck('Ten_Mau');


  
        if ($colors->isNotEmpty()) {
            return response()->json([
                'success' => true,
                'colors' => $colors,
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No colors found for this product',
            ]);
        }
    }
    public function getsize(Request $request)
    {
        $selectedColor = $request->input('color');
        $productMaSP = $request->input('Ma_SP');


        $sizes = ProductDetailModel::where('Ma_SP', $productMaSP)
            ->where('Ten_Mau', $selectedColor)
            ->pluck('Kich_Thuoc');

        if ($sizes->isNotEmpty()) {
            return response()->json([
                'success' => true,
                'sizes' => $sizes,
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No sizes found for this color',
            ]);
        }
    }
}
