<?php

namespace App\Http\Controllers;

use App\Models\BinhLuanModel;
use App\Models\DanhGiaMOdel;
use App\Models\ImageModel;
use Illuminate\Http\Request;
use App\Models\ProductModel;
use App\Models\ProductDetailModel;
use App\Models\ProductNoiBacModel;
use App\Models\ProductNewModel;
use App\Models\TruyCapModel;
use App\Models\UserTruyCapModel;
use Carbon\Carbon;

class ProductController extends Controller
{
    public function show(Request $request)
    {

        $productNam = ProductModel::where('Ma_Loai', 'ML001')->get();
        $productNu = ProductModel::where('Ma_Loai', 'ML002')->get();
        $productNB = ProductNoiBacModel::with('product')->get();
        $productNew = ProductModel::orderBy('San_Pham_id', 'desc')->take(8)->get();

        $ip = $request->ip();
        $ip_truy_cap = UserTruyCapModel::where('IP', $ip);
        if ($ip) {
            $ip_truy_cap->delete();
            $truy_cap = new UserTruyCapModel();
            $truy_cap->IP = $ip;
            $truy_cap->Ngay =  Carbon::now('Asia/Ho_Chi_Minh');
            $truy_cap->save();
        } else {
            $truy_cap = new UserTruyCapModel();
            $truy_cap->IP = $ip;
            $truy_cap->Ngay =  Carbon::now('Asia/Ho_Chi_Minh');
            $truy_cap->save();
        }

        $ip_truy_cap = TruyCapModel::where('IP', $ip);
        $ip_truy_cap = $ip_truy_cap->count();
        if ($ip_truy_cap < 1) {
            $truy_cap = new TruyCapModel();
            $truy_cap->IP = $ip;
            $truy_cap->Ngay_Truy_Cap = date("Y-m-d");
            $truy_cap->save();
        }

        return view('index', compact('productNam', 'productNu', 'productNB', 'productNew'));
    }

    public function showDetail($id, $Ma_SP)
    {

        $productDetail = ProductModel::where('San_Pham_id', $id)->first();
$comment=BinhLuanModel::all();
  
        $color = ProductDetailModel::where('Ma_SP', $Ma_SP)
            ->distinct()
            ->pluck('Ten_Mau');

        
        $size = ProductDetailModel::where('Ma_SP', $Ma_SP)
            ->distinct()
            ->pluck('Kich_Thuoc');
            // return $color;
        // $productDetails = ProductDetailModel::where('Ma_SP', $Ma_SP)->get();
        // $Detail = $productDetails;
        // $DetailColor = $productDetails;
        $img = ImageModel::where('Ma_SP', $Ma_SP)->get();
        //    return $img;
        $product_lq = ProductModel::where('Ma_Loai', $productDetail->Ma_Loai)->get();

        $danhgia = DanhGiaMOdel::where('Ma_SP', $Ma_SP)->get();
        $sodanhgia = DanhGiaMOdel::where('Ma_SP', $Ma_SP)->get()->count();
        $sosao = $danhgia->sum('So_Sao');
        if ($sodanhgia > 0) {
            $tbsao = ceil($sosao / $sodanhgia);
        } else {
            $tbsao = 0;
        }


        return view('productDetail', compact('productDetail', 'color', 'size', 'img', 'danhgia', 'product_lq', 'tbsao','comment'));
    }
    public function comment(Request $request, $Ma_SP)
    {
        $comment = new BinhLuanModel();
        $comment->Ten_User=$request->input('name');
        $comment->Ma_SP=$Ma_SP;
        $comment->Binh_Luan=$request->input('comment');
        $comment->Ngay= Carbon::now();
        $comment->save();
       
        return redirect()->back();
    }

    public function showAll($action, $name)
    {
        if ($action == "all") {
            $productAll = ProductModel::all();
        } elseif ($action == "ML001") {
            $productAll = ProductModel::where('Ma_Loai', 'ML001')->get();
        } elseif ($action == "ML002") {
            $productAll = ProductModel::where('Ma_Loai', 'ML002')->get();
        } elseif ($action == "GNTT") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'GNTT' . '%')->get();
        } elseif ($action == "GNSD") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'GNSD' . '%')->get();
        } elseif ($action == "GNUTT") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'GNUTT' . '%')->get();
        } elseif ($action == "GNUCG") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'GNUCG' . '%')->get();
        } elseif ($action == "PK") {
            $productAll = ProductModel::where('Ma_SP', 'like', '%' . 'PK' . '%')->get();
        }

        return view('productAll', compact('productAll', 'action', 'name'));
    }

    public function loc(Request $request, $name)
    {
        $action = $request->input('action');
        if ($action == "all") {
            $query = ProductModel::query();
        } elseif ($action == "ML001") {
            $query = ProductModel::where('Ma_Loai', 'ML001');
        } elseif ($action == "ML002") {
            $query = ProductModel::where('Ma_Loai', 'ML002');
        } elseif ($action == "GNTT") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'GNTT' . '%');
        } elseif ($action == "GNSD") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'GNSD' . '%');
        } elseif ($action == "GNUTT") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'GNUTT' . '%');
        } elseif ($action == "GNUCG") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'GNUCG' . '%');
        } elseif ($action == "PK") {
            $query = ProductModel::where('Ma_SP', 'like', '%' . 'PK' . '%');
        }

        if ($request->has('loc') && $request->loc != '') {
            if ($request->loc == 'cao-den-thap') {
                $query->orderBy('Gia', 'desc');
            } elseif ($request->loc == 'thap-den-cao') {
                $query->orderBy('Gia', 'asc');
            } elseif ($request->loc == 'nho200') {
                $query->where('Gia', '<', 200000);
            } elseif ($request->loc == '200den500') {
                $query->whereBetween('Gia', [200000, 500000]);
            } elseif ($request->loc == 'tren500') {
                $query->where('Gia', '>', 500000);
            }
        }
        

       

        $productAll = $query->get();
        return view('productAll', compact('productAll', 'action', 'name'));
    }
    public function search(Request $request)
    {
        $key = $request->input('search');
        $product_search = ProductModel::where('Ten_SP', 'like', '%' . $key . '%')->get();
        return view('search', compact('product_search', 'key'));
    }

    public function getcolor(Request $request)
    {
        $productId = $request->input('id');
        $productMaSP = $request->input('Ma_SP');


        $colors = ProductDetailModel::where('Ma_SP', $productMaSP)->pluck('Ten_Mau');


        if ($colors->isNotEmpty()) {
            return response()->json([
                'success' => true,
                'colors' => $colors,
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No colors found for this product',
            ]);
        }
    }
    public function getsize(Request $request)
    {
        $selectedColor = $request->input('color');
        $productMaSP = $request->input('Ma_SP');


        $sizes = ProductDetailModel::where('Ma_SP', $productMaSP)
            ->where('Ten_Mau', $selectedColor)
            ->pluck('Kich_Thuoc');

        if ($sizes->isNotEmpty()) {
            return response()->json([
                'success' => true,
                'sizes' => $sizes,
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No sizes found for this color',
            ]);
        }
    }
}
