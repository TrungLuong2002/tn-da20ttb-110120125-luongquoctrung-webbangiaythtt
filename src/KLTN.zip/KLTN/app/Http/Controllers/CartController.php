<?php

namespace App\Http\Controllers;

use App\Models\AddressModel;
use App\Models\DistrictModel;
use App\Models\OderDetailModel;
use App\Models\OderModel;
use App\Models\ProductModel;
use App\Models\ProductDetailModel;
use App\Models\ProvineModel;
use App\Models\TT_DatHangModel;
use App\Models\UserModel;
use App\Models\WardModel;
use Illuminate\Http\Request;
use Gloudemans\Shoppingcart\Facades\Cart;

class CartController extends Controller
{
    function show()
    {
        return view('user.cart');
    }

    public function addcart(Request $request, $Ma_SP)
    {
        $request->validate([
            'color' => 'required',
            'size' => 'required',
        ], [
            'color.required' => 'Vui lòng chọn màu.',
            'size.required' => 'Vui lòng chọn kích thước.',

        ]);

        if (session()->has('userlogin')) {
            $idsp=ProductDetailModel::where('Ma_SP',$Ma_SP)->where('Ten_Mau',$request->input(('color')))->where('Kich_Thuoc',$request->input(('size')))->first();
            $count_pd=ProductDetailModel::where('Ma_SP',$Ma_SP)->where('Ten_Mau',$request->input(('color')))->where('Kich_Thuoc',$request->input(('size')))->count();
         
            if($count_pd>0 && $idsp->So_Luong>0){
                $product = ProductModel::where('Ma_SP', $Ma_SP)->first();
                $size = $request->input('size');
                $color = $request->input('color');
                Cart::add([
                    'id' => $product->Ma_SP,
                    'name' => $product->Ten_SP,
                    'qty' => 1,
                    'price' => $product->Gia,
                    'options' =>
                    [
                        'soluong'=>$idsp->So_Luong,
                        'img' => $product->Img,
                        'size' => $size,
                        'color' => $color,
                    ]
                ]);
    
                return view('user.cart');
            }else{
                return redirect()->back()->with('tb', 'Sản phẩm không còn màu và kích thước vừa chọn.');
            }
            
        } else {

            return redirect()->route('login');
        }
    }

    public function addcartbuynow(Request $request, $Ma_SP)
    {
        $request->validate([
            'color' => 'required',
            'size' => 'required',
        ], [
            'color.required' => 'Vui lòng chọn màu.',
            'size.required' => 'Vui lòng chọn kích thước.',

        ]);

        if (session()->has('userlogin')) {
            $product = ProductModel::where('Ma_SP', $Ma_SP)->first();
            $size = $request->input('size');
            $color = $request->input('color');
            Cart::add([
                'id' => $product->Ma_SP,
                'name' => $product->Ten_SP,
                'qty' => 1,
                'price' => $product->Gia,
                'options' =>
                [
                    'img' => $product->Img,
                    'size' => $size,
                    'color' => $color,
                ]
            ]);

            return redirect()->route(('checkoutcart'));
        } else {

            return redirect()->route('login');
        }
    }



    public function remove($rowId)
    {
        Cart::remove($rowId);
        return view('user.cart');
    }

    public function destroy()
    {
        Cart::destroy();
        return view('user.cart');
    }
    public function update(Request $request)
    {
       
        $data = $request->get('qty');
   
     

        foreach ($data as $k => $v) {
            Cart::update($k, $v);
        }
        return view('user.cart');
    }

    public function checkout()
    {
        
        $user = UserModel::where('User_id', session('userid'))->first();
        $address = AddressModel::where('Dia_Chi_id', $user->Dia_Chi_id)->first();

        if ($address) {
            $provine = ProvineModel::where('Tinh_id', $address->Tinh_id)->first();
            $district = DistrictModel::where('Huyen_id', $address->Huyen_id)->first();
            $ward = WardModel::where('Xa_id', $address->Xa_id)->first();

            return view('user.checkoutcart', compact('address', 'user', 'provine', 'district', 'ward'));
        } else {
            return view('user.checkoutcart', compact('user', 'address'));
        }
    }

    public function dathang(Request $request)
    {
        if ($request->has('dathang')) {
            $request->validate([
                'payment-method' => 'required',
                'address' => 'required',
            ], [
                'payment-method.required' => 'Vui lòng chọn phương thức thanh toán.',
                'address.required' => 'Vui lòng thêm địa chỉ.',
    
            ]);

            $total = Cart::total();
            // $total = str_replace(',', '', $total); 
            // $total = str_replace('.', '', $total); 
            $phuong_thuc = 2;
            $tong_tien = $total;
            $ghi_chu = $request->input('note');
            $trang_thai = 'Đang xử lí';
            $date = date("Y-m-d");

            $order = new OderModel();
            $order->User_id = $request->session()->get('userid');
            $order->Phuong_Thuc_id = $phuong_thuc;
            $order->Tong_Tien = $tong_tien;
            $order->Ghi_Chu = $ghi_chu;
            $order->Trang_Thai = $trang_thai;
            $order->Ngay_Dat = $date;
            $order->Dia_Chi = $request->input('address');
            $order->save();
            $don_hang_id = $order->getKey();

            foreach (Cart::content() as $item) {
                $id_sp = ProductDetailModel::where('Ma_SP', $item->id)
                    ->where('Ten_Mau', $item->options->color)
                    ->where('Kich_Thuoc', $item->options->size)
                    ->first();

               $id_sp->So_Luong = $id_sp->So_Luong-$item->qty;
               $id_sp->save();
                
                $orderdetail = new OderDetailModel();
                $orderdetail->Don_Hang_id = $don_hang_id;
                $orderdetail->Chi_Tiet_SP_id = $id_sp->Chi_Tiet_SP_id;
                $orderdetail->So_Luong = $item->qty;
                $orderdetail->Tong_Tien = $item->total;
                $orderdetail->save();
            }

            Cart::destroy();

            return redirect()->route('user.order');
        } elseif ($request->has('payUrl')) {
            $request->validate([
             
                'address' => 'required',
            ], [
             
                'address.required' => 'Vui lòng thêm địa chỉ.',
    
            ]);
            $total = Cart::total();
            $total = str_replace(',', '', $total); 
            $total = str_replace('.', '', $total);
            $endpoint = "https://test-payment.momo.vn/v2/gateway/api/create";


            $partnerCode = 'MOMOBKUN20180529';
            $accessKey = 'klm05TvNBzhg7h7j';
            $secretKey = 'at67qH6mk8w5Y1nAyMoYKMWACiEi2bsa';

            $orderInfo = "Thanh toán qua MoMo";
            $amount = $total;
            // return $amount;
            $orderId = time() . "";
            $redirectUrl = route('momo.xuli');
            $ipnUrl = route('momo.xuli');
            $extraData = $request->input('address');

            $partnerCode =  $partnerCode;
            $accessKey = $accessKey;
            $serectkey = $secretKey;
            $orderId = $orderId; // Mã đơn hàng
            $orderInfo =  $orderInfo;
            $amount =  $amount;
            $ipnUrl = $ipnUrl;
            $redirectUrl =  $redirectUrl;
            $extraData =         $extraData;
            $requestId = time() . "";

            $requestType = "payWithATM";

            //before sign HMAC SHA256 signature
            $rawHash = "accessKey=" . $accessKey . "&amount=" . $amount . "&extraData=" . $extraData . "&ipnUrl=" . $ipnUrl . "&orderId=" . $orderId . "&orderInfo=" . $orderInfo . "&partnerCode=" . $partnerCode . "&redirectUrl=" . $redirectUrl . "&requestId=" . $requestId . "&requestType=" . $requestType;
            $signature = hash_hmac("sha256", $rawHash, $serectkey);
            $data = array(
                'partnerCode' => $partnerCode,
                'partnerName' => "Test",
                "storeId" => "MomoTestStore",
                'requestId' => $requestId,
                'amount' => $amount,
                'orderId' => $orderId,
                'orderInfo' => $orderInfo,
                'redirectUrl' => $redirectUrl,
                'ipnUrl' => $ipnUrl,
                'lang' => 'vi',
                'extraData' => $extraData,
                'requestType' => $requestType,
                'signature' => $signature
            );
            $result = $this->execPostRequest($endpoint, json_encode($data));
            $jsonResult = json_decode($result, true);  // decode json

            //Just a example, please check more in there


            // header('Location: ' . $jsonResult['payUrl']);
            return redirect()->to($jsonResult['payUrl']);
        } elseif ($request->has('redirect')) {
            $total_bill = 100000;
            $vnp_Url = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
            $vnp_Returnurl = "http://127.0.0.1:8000/laravel/php/checkout"; // Cập nhật URL trả về
            $vnp_TmnCode = "9UIOZWDY"; // Mã website của bạn tại VNPay
            $vnp_HashSecret = "ABS5VPWC9AAGOT9WIVBK1XVMA7GFCVZ8"; // Chuỗi bí mật
    
            $vnp_TxnRef = time(); // Mã giao dịch. Mỗi lần thanh toán bạn cần tạo một mã giao dịch duy nhất
            $vnp_OrderInfo = "Thanh toán hoá đơn";
            $vnp_OrderType = "billpayment";
            $vnp_Amount = $total_bill * 100; // Số tiền cần thanh toán (tính bằng VND)
            $vnp_Locale = "vn"; // Ngôn ngữ. Mặc định là tiếng Việt (vn)
            $vnp_BankCode = "NCB"; // Mã ngân hàng. Nếu không có, để trống.
            $vnp_IpAddr = $_SERVER['REMOTE_ADDR']; // Địa chỉ IP của khách hàng
        
        $inputData = array(
            "vnp_Version" => "2.1.0",
            "vnp_TmnCode" => $vnp_TmnCode,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => date('YmdHis'),
            "vnp_CurrCode" => "VND",
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_OrderInfo" => $vnp_OrderInfo,
            "vnp_OrderType" => $vnp_OrderType,
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $vnp_TxnRef,
        );
        
        if (isset($vnp_BankCode) && $vnp_BankCode != "") {
            $inputData['vnp_BankCode'] = $vnp_BankCode;
        }
        if (isset($vnp_Bill_State) && $vnp_Bill_State != "") {
            $inputData['vnp_Bill_State'] = $vnp_Bill_State;
        }
        
        //var_dump($inputData);
        ksort($inputData);
        $query = "";
        $i = 0;
        $hashdata = "";
        foreach ($inputData as $key => $value) {
            if ($i == 1) {
                $hashdata .= '&' . urlencode($key) . "=" . urlencode($value);
            } else {
                $hashdata .= urlencode($key) . "=" . urlencode($value);
                $i = 1;
            }
            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }
        
        $vnp_Url = $vnp_Url . "?" . $query;
        if (isset($vnp_HashSecret)) {
            $vnpSecureHash =   hash_hmac('sha512', $hashdata, $vnp_HashSecret);//  
            $vnp_Url .= 'vnp_SecureHash=' . $vnpSecureHash;
        }
        $returnData = array('code' => '00'
            , 'message' => 'success'
            , 'data' => $vnp_Url);
            if (isset($_POST['redirect'])) {
                header('Location: ' . $vnp_Url);
                die();
            } else {
                echo json_encode($returnData);
            }
           
            // vui lòng tham khảo
        } elseif ($request->has('onepay')) {
            // *********************
            // START OF MAIN PROGRAM
            // *********************

            // Define Constants
            // ----------------
            // This is secret for encoding the MD5 hash
            // This secret will vary from merchant to merchant
            // To not create a secure hash, let SECURE_SECRET be an empty string - ""
            // $SECURE_SECRET = "secure-hash-secret";
            // Khóa bí mật - được cấp bởi OnePAY
            $SECURE_SECRET = "A3EFDFABA8653DF2342E8DAC29B51AF0";

            // add the start of the vpcURL querystring parameters
            // *****************************Lấy giá trị url cổng thanh toán*****************************
            $vpcURL = 'https://mtf.onepay.vn/onecomm-pay/vpc.op' . "?";

            // Remove the Virtual Payment Client URL from the parameter hash as we 
            // do not want to send these fields to the Virtual Payment Client.
            // bỏ giá trị url và nút submit ra khỏi mảng dữ liệu
            // unset($_POST["virtualPaymentClientURL"]);
            // unset($_POST["SubButL"]);
            $vpc_Merchant = 'ONEPAY';
            $vpc_AccessCode = 'D67342C2';
            $vpc_MerchTxnRef = time();
            $vpc_OrderInfo = 'JSECURETEST01';
            $vpc_Amount = '100';
            $vpc_ReturnURL = redirect()->route('Trangchu');
            $vpc_Version = '2';
            $vpc_Command = 'pay';
            $vpc_Locale = 'vn';
            $vpc_Currency = 'VND';
            $data = array(
                'vpc_Merchant' => $vpc_Merchant,
                'vpc_AccessCode' => $vpc_AccessCode,
                'vpc_MerchTxnRef' => $vpc_Merchant,
                'vpc_OrderInfo' => $vpc_OrderInfo,
                'vpc_Amount' => $vpc_Amount,
                'vpc_ReturnURL' => $vpc_ReturnURL,
                'vpc_Version' => $vpc_Version,
                'vpc_Command' => $vpc_Command,
                'vpc_Locale' => $vpc_Locale,
                'vpc_Currency' => $vpc_Currency
            );
            //$stringHashData = $SECURE_SECRET; *****************************Khởi tạo chuỗi dữ liệu mã hóa trống*****************************
            $stringHashData = "";
            // sắp xếp dữ liệu theo thứ tự a-z trước khi nối lại
            // arrange array data a-z before make a hash
            ksort($data);

            // set a parameter to show the first pair in the URL
            // đặt tham số đếm = 0
            $appendAmp = 0;

            foreach ($data as $key => $value) {

                // create the md5 input and URL leaving out any fields that have no value
                // tạo chuỗi đầu dữ liệu những tham số có dữ liệu
                if (strlen($value) > 0) {
                    // this ensures the first paramter of the URL is preceded by the '?' char
                    if ($appendAmp == 0) {
                        $vpcURL .= urlencode($key) . '=' . urlencode($value);
                        $appendAmp = 1;
                    } else {
                        $vpcURL .= '&' . urlencode($key) . "=" . urlencode($value);
                    }
                    //$stringHashData .= $value; *****************************sử dụng cả tên và giá trị tham số để mã hóa*****************************
                    if ((strlen($value) > 0) && ((substr($key, 0, 4) == "vpc_") || (substr($key, 0, 5) == "user_"))) {
                        $stringHashData .= $key . "=" . $value . "&";
                    }
                }
            }
            //*****************************xóa ký tự & ở thừa ở cuối chuỗi dữ liệu mã hóa*****************************
            $stringHashData = rtrim($stringHashData, "&");
            // Create the secure hash and append it to the Virtual Payment Client Data if
            // the merchant secret has been provided.
            // thêm giá trị chuỗi mã hóa dữ liệu được tạo ra ở trên vào cuối url
            if (strlen($SECURE_SECRET) > 0) {
                //$vpcURL .= "&vpc_SecureHash=" . strtoupper(md5($stringHashData));
                // *****************************Thay hàm mã hóa dữ liệu*****************************
                $vpcURL .= "&vpc_SecureHash=" . strtoupper(hash_hmac('SHA256', $stringHashData, pack('H*', $SECURE_SECRET)));
            }

            // FINISH TRANSACTION - Redirect the customers using the Digital Order
            // ===================================================================
            // chuyển trình duyệt sang cổng thanh toán theo URL được tạo ra
            // header("Location: " . $vpcURL);
            return redirect()->to($vpcURL);

            // *******************
            // END OF MAIN PROGRAM
            // *******************
        }
    }

    function execPostRequest($url, $data)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt(
            $ch,
            CURLOPT_HTTPHEADER,
            array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($data)
            )
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        //execute post
        $result = curl_exec($ch);
        //close connection
        curl_close($ch);
        return $result;
    }



    public function momoxuli(Request $request)
    {
        if (isset($_GET['partnerCode'])) {
            $total = Cart::total();
            // $total = str_replace(',', '', $total); 
            // $total = str_replace('.', '', $total); 
            $phuong_thuc = 1;
            $tong_tien = $total;
            $ghi_chu = $request->input('note');
            $trang_thai = 'Đã Thanh Toán';
            $date = date("Y-m-d");
            $order = new OderModel();
            $order->User_id = $request->session()->get('userid');
            $order->Phuong_Thuc_id = $phuong_thuc;
            $order->Tong_Tien = $tong_tien;
            $order->Ghi_Chu = $ghi_chu;
            $order->Trang_Thai = $trang_thai;
            $order->Ngay_Dat = $date;
            $order->Dia_Chi = $_GET['extraData'];
            $order->save();
            $don_hang_id = $order->getKey();
            foreach (Cart::content() as $item) {
                $id_sp = ProductDetailModel::where('Ma_SP', $item->id)
                    ->where('Ten_Mau', $item->options->color)
                    ->where('Kich_Thuoc', $item->options->size)
                    ->first();

               $id_sp->So_Luong = $id_sp->So_Luong-$item->qty;
               $id_sp->save();
                
                $orderdetail = new OderDetailModel();
                $orderdetail->Don_Hang_id = $don_hang_id;
                $orderdetail->Chi_Tiet_SP_id = $id_sp->Chi_Tiet_SP_id;
                $orderdetail->So_Luong = $item->qty;
                $orderdetail->Tong_Tien = $item->total;
                $orderdetail->save();
            }
            $tt_dathang = new TT_DatHangModel();
            $tt_dathang->Don_Hang_id = $don_hang_id;
            $tt_dathang->TT_Thanh_Toan = $_GET['orderInfo'];
            $tt_dathang->Id_Giao_Dich = $_GET['transId'];
            $tt_dathang->save();
            Cart::destroy();
            return redirect()->route('user.order.duyet');
        }
    }
}
