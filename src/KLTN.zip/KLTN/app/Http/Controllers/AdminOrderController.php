<?php

namespace App\Http\Controllers;

use App\Models\OderDetailModel;
use App\Models\OderModel;
use App\Models\UserModel;
use Illuminate\Http\Request;

class AdminOrderController extends Controller
{
    function show(){
        $order=OderModel::with('User')->get();
       
        return view('admin.order.order',compact('order'));
    }
    function showdetail($id){
        $order = OderModel::with('orderDetails.productdetail.product')->find($id);

        return view('admin.order.orderdetail',compact('order'));
    }
    function hoandon($id){
        $order=OderModel::where('Don_Hang_id',$id)->first();
        $order->Trang_Thai="Từ chối nhận hàng";
        $order->save();
        return redirect()->route('admin.order');
        
    }
    function showhoandon(){
       
        $user =UserModel::withCount(['orders as solan' => function ($query) {
            $query->where('Trang_Thai', 'Từ chối nhận hàng');
        }])->having('solan', '>', 0)->get();


        return view('admin.order.userhoan',compact('user'));
    }

}
