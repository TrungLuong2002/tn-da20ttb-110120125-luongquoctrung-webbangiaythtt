<?php

namespace App\Http\Controllers;

use App\Models\BinhLuanModel;
use App\Models\DanhGiaMOdel;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdminCommentController extends Controller
{
    public function showdanhgia()
    {
        $title = "";
        $danhgia = DanhGiaMOdel::all();
        return view('admin.conment.danhgia', compact('danhgia', 'title'));
    }

    public function locdanhgia(Request $request, $id)
    {
        $request->validate([

            'locdanhgia' => 'required',

        ], [

            'locdanhgia.required' => 'Vui lòng chọn thuộc tính.',

        ]);
        if ($request->input('locdanhgia') == "7ngay") {
            $title = "7 ngày";
            $now = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();
            $sub7ngay = Carbon::now('Asia/Ho_Chi_Minh')->subDay(7)->toDateString();
            $danhgia = DanhGiaMOdel::whereBetween('Ngay_Danh_Gia', [$sub7ngay, $now])->orderBy('Ngay_Danh_Gia', 'ASC')->get();
            return view('admin.conment.locdanhgia', compact('danhgia', 'title'));
        } elseif ($request->input('locdanhgia') == "chua-tra-loi") {
            $title = "chưa trả lời";
            $danhgia = DanhGiaMOdel::where('Tra_Loi', null)->get();
            return view('admin.conment.locdanhgia', compact('danhgia', 'title'));
        } elseif ($request->input('locdanhgia') == "1sao") {
            $title = "1 sao";
            $danhgia = DanhGiaMOdel::where('So_Sao', 1)->get();
            return view('admin.conment.locdanhgia', compact('danhgia', 'title'));
        } elseif ($request->input('locdanhgia') == "2sao") {
            $title = "2 sao";
            $danhgia = DanhGiaMOdel::where('So_Sao', 2)->get();
            return view('admin.conment.locdanhgia', compact('danhgia', 'title'));
        } elseif ($request->input('locdanhgia') == "3sao") {
            $title = "3 sao";
            $danhgia = DanhGiaMOdel::where('So_Sao', 3)->get();
            return view('admin.conment.locdanhgia', compact('danhgia', 'title'));
        } elseif ($request->input('locdanhgia') == "4sao") {
            $title = "4 sao";
            $danhgia = DanhGiaMOdel::where('So_Sao', 4)->get();
            return view('admin.conment.locdanhgia', compact('danhgia', 'title'));
        } elseif ($request->input('locdanhgia') == "5sao") {
            $title = "5 sao";
            $danhgia = DanhGiaMOdel::where('So_Sao', 5)->get();
            return view('admin.conment.locdanhgia', compact('danhgia', 'title'));
        } elseif ($request->input('locdanhgia') == "all") {

            return redirect()->route('admin.showdanhgia');
        }
    }


    public function traloidanhgia(Request $request, $id)
    {
        $danhgia = DanhGiaMOdel::find($id);
        $danhgia->Tra_Loi = $request->input('traloi');
        $danhgia->save();
        $tb = "Đã trả lời";

        return back()->with('tb', $tb)->withInput();
    }
    public function deletedanhgia($id)
    {
        $danhgia = DanhGiaMOdel::find($id);
        $danhgia->delete();
        return redirect()->back();
    }

    public function showbinhluan()
    {
        $title = "";
        $binhluan = BinhLuanModel::all();
        return view('admin.conment.binhluan', compact('binhluan', 'title'));
    }

    public function locbinhluan(Request $request, $id)
    {
        $request->validate([

            'locdanhgia' => 'required',

        ], [

            'locdanhgia.required' => 'Vui lòng chọn thuộc tính.',

        ]);
        if ($request->input('locdanhgia') == "7ngay") {
            $title = "7 ngày";
            $now = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();
            $sub7ngay = Carbon::now('Asia/Ho_Chi_Minh')->subDay(7)->toDateString();
            $binhluan = BinhLuanModel::whereBetween('Ngay', [$sub7ngay, $now])
                ->orderBy('Ngay', 'ASC')
                ->get();
            return view('admin.conment.locbinhluan', compact('binhluan', 'title'));
        } elseif ($request->input('locdanhgia') == "chua-tra-loi") {
            $title = "chưa trả lời";
            $binhluan = BinhLuanModel::where('Tra_Loi', null)->get();
            return view('admin.conment.locbinhluan', compact('binhluan', 'title'));
        } elseif ($request->input('locdanhgia') == "all") {

            return redirect()->route('admin.showbinhluan');
        }
    }


    public function traloibinhluan(Request $request, $id)
    {
        $binhluan = BinhLuanModel::find($id);
        $binhluan->Tra_Loi = $request->input('traloi');
        $binhluan->save();
        $tb = "Đã trả lời";

        return back()->with('tb', $tb)->withInput();
    }
    public function deletebinhluan($id)
    {
        $binhluan = BinhLuanModel::find($id);
        $binhluan->delete();
        return redirect()->back();
    }
}
