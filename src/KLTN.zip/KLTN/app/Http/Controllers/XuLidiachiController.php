<?php

namespace App\Http\Controllers;

use App\Models\DistrictModel;
use App\Models\WardModel;
use Illuminate\Http\Request;

class XuLidiachiController extends Controller
{
    public function getHuyen($tinh_id){
        $huyen = DistrictModel::where('Tinh_id', $tinh_id)->get();
        return response()->json($huyen);
    }
    public function getXa($huyen_id){
        $xa = WardModel::where('Huyen_id', $huyen_id)->get();
        return response()->json($xa);
    }
}
