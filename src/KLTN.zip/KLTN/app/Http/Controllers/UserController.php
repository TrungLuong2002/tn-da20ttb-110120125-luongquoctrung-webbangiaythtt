<?php

namespace App\Http\Controllers;

use App\Models\AddressModel;
use App\Models\DistrictModel;
use App\Models\OderDetailModel;
use App\Models\OderModel;
use App\Models\ProvineModel;
use App\Models\UserModel;
use App\Models\WardModel;
use Illuminate\Http\Request;

class UserController extends Controller
{
    function login(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');
        $user = UserModel::where('username', $username)
            ->where('password', $password)
            ->first();
        if ($user) {
            session()->put('userlogin', $user->FullName);
            session()->put('userid', $user->User_id);
            return redirect()->route('Trangchu');
        } else {
            return back()->withErrors(['message' => 'Tên đăng nhập hoặc mật khẩu không đúng'])->withInput();
        }
    }
    function logout()
    {
        session()->flush();
        return redirect()->route('index');
    }

    function dangki(Request $request)
    {
        $request->validate([
            'fullname' => 'required',
            'username' => 'required',
            'password' => 'required',
            'email' => 'required|regex:/^[a-zA-Z0-9._%+-]+@gmail\.com$/',
            'phone' => 'required|numeric',
            


        ], [
            'fullname.required' => 'Vui lòng nhập tên.',
            'username.required' => 'Vui lòng nhập username.',
            'password.required' => 'Vui lòng nhập password.',
            'email.required' => 'Vui lòng nhập email.',
            'email.regex' => 'Email phải có định dạng xxx@gmail.com.',
            'phone.numeric' => 'Số điện thoại phải là dạng số.',
            'phone.required' => 'Vui lòng nhập sdt.',
        ]);
        
    }



    public function showtt()
    {
        $user = UserModel::where('User_id', session('userid'))->first();


        $address = AddressModel::where('Dia_Chi_id', $user->Dia_Chi_id)->first();



        $tinh = ProvineModel::all();
        $huyen = DistrictModel::all();
        $xa = WardModel::all();
        if ($address) {
            $provine = ProvineModel::where('Tinh_id', $address->Tinh_id)->first();
            $district = DistrictModel::where('Huyen_id', $address->Huyen_id)->first();
            $ward = WardModel::where('Xa_id', $address->Xa_id)->first();

            return view('user.tt', compact('address', 'user', 'provine', 'district', 'ward', 'tinh', 'huyen', 'xa'));
        } else {
            return view('user.tt', compact('user', 'tinh', 'huyen', 'xa'));
        }
    }
    public function doipass()
    {
        return view('user.doipass');
    }
    public function doimk()
    {
        $user = UserModel::where('User_id', session('userid'))->first();
        $passmain = $user->Password;
        $pass = $_POST['password'];
        $passnew = $_POST['passnew'];
        $passnewN = $_POST['passnewN'];
        if ($passmain != $pass) {
            $tb = "Sai mật khẩu";
        } elseif ($passmain == $pass && $passnew != $passnewN) {
            $tb = "Sai mật khẩu";
        } elseif ($passmain == $pass && $passnew == $passnewN) {
            $user->Password = $passnew;
            $user->save();
            $tb = "Cập nhật thành công";
        }
        return view('user.doipass', compact('tb'));
    }
    public function order()
    {
        $order = OderModel::where('User_id', session('userid'))
            ->where('Trang_Thai', 'Đang xử lí')
            ->get();

        return view('user.order', compact('order'));
    }
    public function huydon($id)
    {
        $order = OderModel::where('Don_Hang_id', $id)->first();
           $order->Trang_Thai="Đã huỷ";
$order->save();
        return redirect()->back();
    }
    public function orderhuy()
    {
        $orderhuy = OderModel::where('User_id', session('userid'))
            ->where('Trang_Thai', 'Đã huỷ')
            ->get();

        return view('user.orderhuy', compact('orderhuy'));
    }
    public function orderduyet()
    {
        $orderduyet = OderModel::where('User_id', session('userid'))
            ->where(function ($query) {
                $query->where('Trang_Thai', 'Đã duyệt')
                    ->orWhere('Trang_Thai', 'Đã Thanh Toán');
            })
            ->get();

        return view('user.orderduyet', compact('orderduyet'));
    }
    public function orderdetail($id)
    {
        $order = OderModel::with('orderDetails.productdetail.product')->find($id);
        //   return $order;

        return view('user.orderDetail', compact('order'));
    }
    public function update_tt(Request $request)
    {
        $request->validate([
            'tinh' => 'required',
            'huyen' => 'required',
            'xa' => 'required',


        ], [
            'tinh.required' => 'Vui lòng chọn tỉnh.',
            'huyen.required' => 'Vui lòng chọn huyện.',
            'xa.required' => 'Vui lòng chọn xã.',

        ]);
        $tinh = $request->input('tinh');
        $huyen = $request->input('huyen');
        $xa = $request->input('xa');
        $user = UserModel::where('User_id', session('userid'))->first();

        if ($user->Dia_Chi_id == NULL) {
            $address = new AddressModel();
            $address->Tinh_id = $tinh;
            $address->Huyen_id = $huyen;
            $address->Xa_id = $xa;
            $address->save();

            $address_id = $address->getKey();
            $user->FullName = $request->input('name');
            $user->Email = $request->input('email');
            $user->SDT = $request->input('phone');
            $user->Dia_Chi_id = $address_id;
            $user->save();
        } else {
            $user->FullName = $request->input('name');
            $user->Email = $request->input('email');
            $user->SDT = $request->input('phone');
            $user->save();
            $address = AddressModel::where('Dia_Chi_id', $user->Dia_Chi_id)->first();
            $address->Tinh_id = $tinh;
            $address->Huyen_id = $huyen;
            $address->Xa_id = $xa;
            $address->save();
        }

        return redirect()->back()->with('tb', 'Cập nhật thông tin thành công.');
    }
}
