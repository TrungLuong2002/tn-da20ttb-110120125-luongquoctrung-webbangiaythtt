<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('css/global.css') }}">
    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/Trangchu.css') }}">
    <link rel="stylesheet" href="{{ asset('css/productDetail.css') }}">
    <link rel="stylesheet" href="{{ asset('css/productAll.css') }}">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>@yield('titlle')</title>

</head>

<body>
    <div id="container">
        <div id="header-wp">
            <div id="head-top">

                <div id="main-menu-wp">
                    <ul id="main-menu">
                        <li>
                            <a href="{{route('index')}}" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="{{route('productAll',['action'=>'all','name'=>'Sản Phẩm'])}}" title="">Sản phẩm</a>
                        </li>
                    
                        <li>
                            <a href="" title="">Liên hệ</a>
                        </li>
                    </ul>
                </div>

            </div>
            <div id="head-body-wp">
                <div id="head-body">
                    <div id="logo">
                        <a href="{{route('index')}}"><img class="max-width" src="{{ asset('uploads/images/logo3.jpeg') }}"
                                alt=""></a>
                    </div>
                    <div id="form-search">
                        <form action="{{route('search')}}" method="POST">
                            @csrf
                            <input type="text" name="search" id="search" placeholder="tim kiem">
                            <input type="submit" value="Tìm Kiếm" id="btn-search" name="btn-search">
                        </form>
                    </div>
                    <div id="acction">
                        <div id="phone">
                            <div id="icon-phone">
                                <a href=""> <i class="fa-solid fa-headphones"></i></a>

                            </div>
                            <div id="phone-number">
                                <p>Tư vấn</p>
                                <p>0376166306</p>
                            </div>

                        </div>
                        <div id="cart">
                            <a href="{{route('show.cart')}}"><i class="fa-solid fa-cart-shopping"></i></a>
                        </div>
                        <div id="login">
                            <a href="{{route('login')}}"><i class="fa-solid fa-user"></i></a>
                        </div>

                    </div>

                </div>
            </div>

        </div>
        <div id="main-content">
            <div id="content-wp">
                <div id="side-bar">
                    <div id="menu">
                        <div id="title-menu">
                            <h3>DANH MỤC SẢN PHẨM</h3>
                        </div>
                        <div id="menu-sp">
                            <ul class="list-item">
                                <li>
                                    <a href="{{route('productAll',['action'=>'ML001','name'=>'Giày Nam'])}}" title="">Giày nam</a>
                                    <ul class="sub-menu">
                                        <li>
                                            <a href="{{route('productAll',['action'=>'GNTT','name'=>'Giày Nam Thể Thao'])}}" title="">Giày thể thao nam</a>
                                        </li>
                                        <li>
                                            <a href="{{route('productAll',['action'=>'GNSD','name'=>'Sandal Nam'])}}" title="" >Sandal nam</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="{{route('productAll',['action'=>'ML002','name'=>'Giày Nữ'])}}" title="">Giày nữ</a>
                                    <ul class="sub-menu">
                                        <li>
                                            <a href="{{route('productAll',['action'=>'GNUTT','name'=>'Giày Nữ Thể Thao'])}}" title="">Giày thể thao nữ</a>
                                        </li>
                                        <li>
                                            <a href="{{route('productAll',['action'=>'GNUCG','name'=>'Giày Cao Gót'])}}" title="">Giày cao gót</a>

                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="{{route('productAll',['action'=>'PK','name'=>'Phụ Kiện'])}}" title="">Phụ kiện</a>
                                </li>
                            </ul>

                        </div>
                    </div>
                    <div id="tt-phu">
                        @yield('tt-phu')
                    </div>

                </div>
                <div id="content">
                    @yield('content')

                </div>



            </div>
        </div>

        <div id="footer">
            <div id="foot-body">

                <div class="block" id="info-company">
                    <h3 class="title">SHOP GIÀY</h3>
                    <p>SHOP GIÀY luôn cung cấp luôn là sản phẩm chất lượng, có nhiều chính sách ưu đãi cực lớn cho khách
                        hàng .</p>

                </div>
                <div class="block" id="info-shop">
                    <h3 class="title">Thông tin cửa hàng</h3>
                    <ul class="list-item">
                        <li>
                            <p>Cầu Ngang-Trà Vinh</p>
                        </li>
                        <li>
                            <p>037.290.5640 - 0376.166.306</p>
                        </li>
                        <li>
                            <p>luongtrung9902@gmail.com</p>
                        </li>
                    </ul>
                </div>
                <div class="block ">
                    <h3 class="title">Chính sách mua hàng</h3>
                    <ul class="list-item">
                        <li>
                            <a href="" title="">Quy định - chính sách</a>
                        </li>
                        <li>
                            <a href="" title="">Chính sách bảo hành - đổi trả</a>
                        </li>

                    </ul>
                </div>

            </div>
            <div id="food-end">
                <p id="copyright">© Bản quyền thuộc về Lương Quốc Trung</p>
            </div>
        </div>

    </div>
    {{-- <div class="overlay"></div> --}}
    {{-- <div id="login-container">
        <h3>Đăng Nhập</h3>
        <form id="loginForm" action="{{ route('login') }}" method="POST">
        @csrf
            <div class="input-group">
                <label for="username">Tên đăng nhập:</label>
                <input type="text" id="username" name="username">
            </div>
            <div class="input-group">
                <label for="password">Mật khẩu:</label>
                <input type="password" id="password" name="password">
            </div>
            <div id="action">
                <a href="">Quên mật khẩu?</a>
                <p>Bạn chưa có tài khoản?<a href="dangki.php"> Đăng kí</a></p>

            </div>
            <button type="submit">Login</button>
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

        </form>
    </div>



    <script>
        function disableBodyScroll() {
            $('body').addClass('body-no-scroll');
        }

        function enableBodyScroll() {
            $('body').removeClass('body-no-scroll');
        }

        $(document).ready(function() {
            $('#login').on('click', function(event) {
                event.preventDefault();
                $('#login-container').css('opacity', '1');
                $('.overlay').css('display', 'block');
                disableBodyScroll();
            });

            $('.overlay').on('click', function() {
                $('#login-container').css('opacity', '0');
                $('.overlay').css('display', 'none');
                enableBodyScroll();
            });
        });
    </script> --}}
</body>

</html>
