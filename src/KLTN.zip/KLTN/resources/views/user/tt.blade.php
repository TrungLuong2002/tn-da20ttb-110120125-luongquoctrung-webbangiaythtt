@extends('layout.Cartlayout')
@section('title', 'gio hang')
@section('content')

    <style>
        #sidebar ul li a.mau-menu.mau-menu {
            border-left: 2px solid #fa0101;
            background-color: #ffe3e3;
        }
    </style>

    <div id="sidebar">
        <ul id="tt">
            <li><a class="mau-menu" href="{{ route('user.tt') }}">Thông tin cá nhân</a></li>
            <li><a href="{{ route('user.doipass') }}">Đổi mật khẩu</a></li>
            <li><a href="{{ route('user.order') }}">Đơn hàng</a></li>
        </ul>
    </div>
    <div id="content">
        <h2>Thông tin cá nhân</h2>
        <form action="{{ route('user.updatett') }}" method="post">
            @csrf
            <label for="name">Tên</label>
            <input type="text" id="name" name="name" value="{{ $user->FullName }}">

            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="{{ $user->Email }}">

            <label for="phone">Số điện thoại</label>
            <input type="text" id="phone" name="phone" value="{{ $user->SDT }}">

            <label for="address">Địa chỉ</label><br>

            @if (isset($address))
                @php
                    $diachi = $ward->Ten_Xa . ', ' . $district->Ten_Huyen . ', ' . $provine->Ten_Tinh;
                    Session::put('diachi', $diachi);
                @endphp
                <select name="tinh" id="tinh">
                    @if (isset($tinh))
                        @foreach ($tinh as $tinh)
                            <option value="{{ $tinh->Tinh_id }}"
                                {{ $provine->Ten_Tinh == $tinh->Ten_Tinh ? 'selected' : '' }}>
                                {{ $tinh->Ten_Tinh }}
                            </option>
                        @endforeach
                    @endif
                </select>
                <select name="huyen" id="huyen">
                    @if (isset($huyen))
                        @foreach ($huyen as $huyen)
                            <option value="{{ $huyen->Huyen_id }}"
                                {{ $district->Ten_Huyen == $huyen->Ten_Huyen ? 'selected' : '' }}>
                                {{ $huyen->Ten_Huyen }}
                            </option>
                        @endforeach
                    @endif
                </select>
                <select name="xa" id="xa">
                    @if (isset($xa))
                        @foreach ($xa as $xa)
                            <option value="{{ $xa->Xa_id }}" {{ $ward->Ten_Xa == $xa->Ten_Xa ? 'selected' : '' }}>
                                {{ $xa->Ten_Xa }}
                            </option>
                        @endforeach
                    @endif
                </select><br><br>
            @else
            @php
            $diachi = "";
            Session::put('diachi', $diachi);
        @endphp
                <select name="tinh" id="tinh">
                    @if (isset($tinh))
                        <option value="">----chọn tỉnh-----</option>
                        @foreach ($tinh as $tinh)
                            <option value="{{ $tinh->Tinh_id }}">{{ $tinh->Ten_Tinh }}</option>
                        @endforeach
                    @endif
                </select>
                <select name="huyen" id="huyen">
                    @if (isset($huyen))
                        <option value="">----chọn huyện-----</option>
                        @foreach ($huyen as $huyen)
                            <option value="{{ $huyen->Huyen_id }}">{{ $huyen->Ten_Huyen }}</option>
                        @endforeach
                    @endif
                </select>
                <select name="xa" id="xa">
                    @if (isset($xa))
                        <option value="">----chọn xã-----</option>
                        @foreach ($xa as $xa)
                            <option value="{{ $xa->Xa_id }}">{{ $xa->Ten_Xa }}</option>
                        @endforeach
                    @endif
                </select><br><br>
            @endif
            @if (session('tb'))
                <p style="color:rgb(5, 132, 0)">{{ session('tb') }}</p>
            @endif
            @error('tinh')
                <p style="color: red">{{ $message }}</p>
            @enderror
            @error('huyen')
                <p style="color: red">{{ $message }}</p>
            @enderror
            @error('xa')
                <p style="color: red">{{ $message }}</p>
            @enderror
            <input type="submit" value="Cập nhật">
        </form>
    </div>

    <script>
        $(document).ready(function() {
            $('#tinh').change(function() {
                var tinh_id = $(this).val();
                $.ajax({
                    url: '{{ route('user.gethuyen', ':tinh_id') }}'.replace(':tinh_id', tinh_id),
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        $('#huyen').empty();
                        $('#huyen').append('<option value="">Chọn huyện</option>');
                        $('#xa').empty();
                        $('#xa').append('<option value="">Chọn xã</option>');
                        $.each(response, function(key, huyen) {
                            $('#huyen').append('<option value="' + huyen.Huyen_id +
                                '">' + huyen.Ten_Huyen + '</option>');
                        });
                    }
                });
            });

            $('#huyen').change(function() {
                var huyen_id = $(this).val();
                $.ajax({
                    url: '{{ route('user.getxa', ':huyen_id') }}'.replace(':huyen_id', huyen_id),
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {

                        $.each(response, function(key, xa) {
                            $('#xa').append('<option value="' + xa.Xa_id + '">' + xa
                                .Ten_Xa + '</option>');
                        });
                    }
                });
            });
        });
    </script>
@endsection
