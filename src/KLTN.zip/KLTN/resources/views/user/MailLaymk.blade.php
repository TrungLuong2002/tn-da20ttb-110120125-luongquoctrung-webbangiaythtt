<p>Mật khẩu của bạn là: <strong>{{ $data['pass'] }}</strong></p>
