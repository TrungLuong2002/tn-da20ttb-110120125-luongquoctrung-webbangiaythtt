@extends('layout.appUser')
@section('title', 'Search')
@section('tt-phu')

@endsection
@section('content')
    <div id="content-head">
        @if (isset($product_search))
            <h1>Kết quả tìm kiếm cho "{{ $key }}"</h1>
        @endif
    </div>
    <div id="content-body">
        <ul class="list-product">
            @if (isset($product_search) && count($product_search) > 0)
                @foreach ($product_search as $item)
                    <li>
                        <a href="{{ route('User.productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP]) }}"
                            title="" class="thumb">
                            <img src="{{ asset($item->Img) }}">
                        </a>
                        <a href="{{ route('User.productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP]) }}"
                            title="" class="product-name">{{ $item->Ten_SP }}</a>
                        <div class="price">
                            <span class="new">{{ number_format($item->Gia, 0, ',', '.') }}đ</span>
                            @if ($item->Gia_cu != null)
                                <span class="old">{{ number_format($item->Gia_cu, 0, ',', '.') }}đ</span>
                            @endif
                        </div>
                        <div class="task">
                            <a href="#" title="Thêm giỏ hàng" class="add-cart">Thêm giỏ hàng</a>
                            <a href="#" title="Mua ngay" class="buy-now">Mua ngay</a>
                        </div>
                    </li>
                @endforeach
            @else
                <p>Không tìm thấy sản phẩm nào.</p>
            @endif
        </ul>
    </div>
@endsection
