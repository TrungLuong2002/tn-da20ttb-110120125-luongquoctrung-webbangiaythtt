@extends('layout.Cartlayout')
@section('title', 'gio hang')
@section('content')
    <form action="{{ route('dat-hang') }}" method="POST">
        @csrf
        <div id="content-wp">
            <div id="customer-info">
                <h2>THÔNG TIN KHÁCH HÀNG</h1>
                    <div id="frm-tt">
                        @if ($user)

                            <div class="form-row clearfix">
                                <div class="form-col fl-left">
                                    <label for="fullname">Họ tên</label>
                                    <input type="text" name="fullname" id="fullname" value="{{ $user->FullName }}">
                                </div>
                                <div class="form-col fl-right">
                                    <label for="email">Email</label>
                                    <input type="email" name="email" id="email" value="{{ $user->Email }}">
                                </div>
                            </div>
                            <div class="form-row clearfix">
                                <div class="form-col fl-left">
                                    <label for="address">Địa chỉ</label>
                                    @if ($address)
                                        <input type="text" name="address" id="address"
                                            value="{{ $ward->Ten_Xa }}, {{ $district->Ten_Huyen }}, {{ $provine->Ten_Tinh }}">
                                    @else
                                        <input type="text" name="address" id="address" value="">
                                    @endif

                                </div>
                                <div class="form-col fl-right">
                                    <label for="phone">Số điện thoại</label>
                                    <input type="tel" name="phone" id="phone" value="{{ $user->SDT }}">
                                </div>
                            </div>
                            <div class="form-row  clearfix">
                                <div class="form-col">
                                    <label for="notes">Ghi chú</label>
                                    <textarea name="note"></textarea>
                                </div>
                            </div>
                        @endif

                    </div>
            </div>
            <div id="order-info">
                <h2>THÔNG TIN ĐƠN HÀNG</h1>
                    <table class="shop-table">
                        <thead>
                            <tr>
                                <td>Sản phẩm</td>
                                <td>Tổng</td>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach (Cart::content() as $item)
                                <tr class="cart-item">
                                    <td class="product-name">{{ $item->name }} ( {{ $item->options->color }} |
                                        {{ $item->options->size }} )<strong class="product-quantity">x
                                            {{ $item->qty }}</strong></td>
                                    <td class="product-total">{{ number_format($item->total, 0, ',', '.') }} đ</td>
                                </tr </tbody>
                            @endforeach

                        <tfoot>
                            <tr class="order-total">
                                <td>Tổng đơn hàng:</td>
                                <td><strong class="total-price">{{ Cart::total() }} đ</strong></td>
                            </tr>
                        </tfoot>
                    </table>

                    <ul id="payment-methods">
                        <li>
                            <input type="radio" id="direct-payment" name="payment-method" value="home-payment">
                            <label for="direct-payment">Thanh toán Khi nhận hàng</label>
                        </li>
                        <input type="hidden" name="total" value="{{ Cart::total() }}">
                        <button type="submit" name="payUrl" id="momo">Thanh toán MOMO</button>
                        {{-- <button type="submit" name="redirect" id="vnpay">Thanh toán VNPAY</button> --}}
                        <button type="submit" name="onepay" id="onepay">Thanh toán ONEPAY</button>
                      
                        <a href="{{ route('processTransaction') }}" id="paypal"><img
                                src="{{ asset('uploads/images/paypalicon.jpeg') }}" alt=""></a>


                    </ul>
                    @error('payment-method')
                        <p style="color: red">{{ $message }}</p>
                    @enderror
                    @error('address')
                        <p style="color: red">{{ $message }}</p>
                    @enderror
                    @if (session('tb'))
                        <p style="color: red">
                            {{ session('tb') }}
                        </p>
                    @endif


                    <div class="place-order-wp clearfix">
                        <input type="submit" id="order-now" name="dathang" value="Đặt hàng">
                    </div>
            </div>
        </div>
    </form>
@endsection
