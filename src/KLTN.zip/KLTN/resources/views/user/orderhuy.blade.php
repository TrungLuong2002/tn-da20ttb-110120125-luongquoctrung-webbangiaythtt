@extends('layout.Cartlayout')
@section('title', 'gio hang')
@section('content')
<style>
    #sidebar ul li a.mau-menu {
    border-left: 2px solid #fa0101;
    background-color: #ffe3e3;
}
</style>
    <div id="sidebar">
        <ul id="tt">
            <li><a href="{{ route('user.tt') }}">Thông tin cá nhân</a></li>
            <li><a href="{{ route('user.doipass') }}">Đổi mật khẩu</a></li>
            <li><a class="mau-menu" href="{{ route('user.order') }}">Đơn hàng</a></li>
        </ul>
    </div>
    <div id="content">
        <div class="container">

            <h2>Danh sách đơn hàng</h2>
            <nav class="order-menu">
                <ul>
                    <li><a href="{{ route('user.order') }}">Đang xử lí</a></li>
                    <li><a class="mau" href="{{ route('user.order.huy') }}">Đơn đã hủy</a></li>
                    <li><a href="{{ route('user.order.duyet') }}">Đơn đã duyệt</a></li>
                </ul>
            </nav>
            @if (isset($orderhuy))

                <table class="order-table">
                    <thead>
                        <tr>
                            <th>STT</th>
                            <th>Ngày Đặt</th>
                            <th>Trạng Thái</th>
                            <th>Tổng Tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $count = 0;
                        @endphp
                        @foreach ($orderhuy as $item)
                            @php
                                $count++;
                            @endphp
                            <tr>
                                <td>{{ $count }}</td>
                                <td>{{$item->Ngay_Dat}}</td>
                                <td>{{$item->Trang_Thai}}</td>
                                <td>{{$item->Tong_Tien}}đ</td>
                                <td><a href="{{route('user.order.detail',['id'=>$item->Don_Hang_id])}}">xem chi tiet</a></td>
                                

                            </tr>
                        @endforeach
                    </tbody>
                </table>


            @endif

        </div>

    </div>


@endsection
