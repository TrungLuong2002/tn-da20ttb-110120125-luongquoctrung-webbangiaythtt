@extends('layout.Cartlayout')
@section('title', 'gio hang')
@section('content')

    <div id="sidebar">
        <ul id="tt">
            <li><a href="{{ route('user.tt') }}">Thông tin cá nhân</a></li>
            <li><a href="{{ route('user.doipass') }}">Đổi mật khẩu</a></li>
            <li><a href="{{ route('user.order') }}">Đơn hàng</a></li>
        </ul>
    </div>
    <div id="content">
        <div class="container">

            <h2>Chi tiết đơn hàng</h2>
            <nav class="order-menu">
                <ul>
                    <li><a href="{{ route('user.order') }}">Đang xử lí</a></li>
                    <li><a href="{{ route('user.order.huy') }}">Đơn đã hủy</a></li>
                    <li><a href="{{ route('user.order.duyet') }}">Đơn đã duyệt</a></li>
                </ul>
            </nav>
            @if (isset($order))

                <table class="order-table">
                    <thead>
                        <tr>
                            <th>STT</th>
                            <th>Tên sản phẩm</th>
                            <th>Màu sắc</th>
                            <th>Kích thước</th>
                            <th>Số lượng</th>
                            <th>Tổng Tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $count = 0;
                        @endphp
                        @foreach ($order->orderDetails as $item)
                            @php
                                $count++;
                            @endphp
                            <tr>
                                <td>{{ $count }}</td>
                                <td>{{$item->productdetail->product->Ten_SP}}</td>
                                <td>{{$item->productdetail->Ten_Mau}}</td>
                                <td>{{$item->productdetail->Kich_Thuoc}}</td>
                                <td>{{$item->So_Luong}}</td>
                                <td>{{ number_format($item->Tong_Tien, 0, ',', '.') }}đ</td>
                             

                            </tr>
                        @endforeach
                    </tbody>
                </table>


            @endif

        </div>

    </div>


@endsection
