@extends('layout.appUser')
@section('title', 'Trang chu')
@section('tt-phu')
    <style>
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
            display: none;
        }

        .centered-form {
            width: 300px;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            z-index: 1000;
            display: none;

            flex-direction: column;
            align-items: center;
            max-width: 400px;
            margin: 0 auto;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .centered-form h3 {
            text-align: center;
            margin-bottom: 20px;
            color: #f50c0c;
        }

        .centered-form label {
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .centered-form select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 15px;
            background-color: #fff;
            font-size: 16px;
        }

        .form-phu {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-phu .btn-add {
            font-size: 12px;
            display: block;
            border: 1px solid #fd0101;
            color: #fd0101;
            padding: 5px 5px;
            margin-right: 5px;
            width: 100px;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
            margin: 0 auto;
        }

        .form-phu .btn-add:hover {

            background-color: #fd0101;
            color: #f2f2f2;

        }

        .form-phu select {
            background-color: #f2f2f2;
            color: #333;
        }

        /* -------------- */
        .centered-form2 {
            width: 300px;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            z-index: 1000;
            display: none;

            flex-direction: column;
            align-items: center;
            max-width: 400px;
            margin: 0 auto;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .centered-form2 h3 {
            text-align: center;
            margin-bottom: 20px;
            color: #f50c0c;
        }

        .centered-form2 label {
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .centered-form2 select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 15px;
            background-color: #fff;
            font-size: 16px;
        }

        .form-phu2 {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-phu2 .btn-add {
            font-size: 12px;
            display: block;
            border: 1px solid #fd0101;
            color: #fd0101;
            padding: 5px 5px;
            margin-right: 5px;
            width: 100px;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
            margin: 0 auto;
        }

        .form-phu2 .btn-add:hover {

            background-color: #fd0101;
            color: #f2f2f2;

        }

        .form-phu2 select {
            background-color: #f2f2f2;
            color: #333;
        }
        #slider .slide img{
            max-height: 100%;
        }
    </style>
    <h3 class="title">SẢN PHẨM NỔI BẬC</h3>
    <ul class="list-product-phu">
        @if (isset($productNB))
            @foreach ($productNB as $item)
                <li>
                    <div class="ttp-wp">
                        <a href="{{ route('User.productDetail', ['id' => $item->product->San_Pham_id, 'Ma_SP' => $item->product->Ma_SP]) }}"
                            title="" class="img-ttp">
                            <img src="{{ asset($item->product->Img) }}">
                        </a>
                        <div class="tt">
                            <a href="{{ route('User.productDetail', ['id' => $item->product->San_Pham_id, 'Ma_SP' => $item->product->Ma_SP]) }}"
                                title="" class="product-name">{{ $item->product->Ten_SP }}</a>
                            <div class="price">
                                <span class="new">{{ number_format($item->product->Gia, 0, ',', '.') }}đ</span>
                                @if ($item->product->Gia_cu != null)
                                    <span class="old">{{ number_format($item->product->Gia_cu, 0, ',', '.') }}đ</span>
                                @endif

                            </div>


                        </div>
                    </div>
                    <a href="{{ route('User.productDetail', ['id' => $item->product->San_Pham_id, 'Ma_SP' => $item->product->Ma_SP]) }}"
                        class="xem">Xem</a>
                </li>
            @endforeach
        @endif

    </ul>
@endsection
@section('content')
    <div id="slider">
        @if ($banner)
            @foreach ($banner as $item)
            <div class="slide"><img src="{{ asset($item->Link) }}" alt="Image 1"></div>
      
            @endforeach
        @endif
        

    </div>
    <script></script>
    <div id="support-wp">
        <ul id="support">
            <li>
                <div class="thumb">
                    <img src="{{ asset('uploads/images/icon-1.png') }}">
                </div>
                <h3 class="title">Miễn phí vận chuyển</h3>
                <p class="desc">Tới tận tay khách hàng</p>
            </li>
            <li>
                <div class="thumb">
                    <img src="{{ asset('uploads/images/icon-2.png') }}">
                </div>
                <h3 class="title">Tư vấn 24/7</h3>
                <p class="desc">09999999</p>
            </li>
            <li>
                <div class="thumb">
                    <img src="{{ asset('uploads/images/icon-3.png') }}">
                </div>
                <h3 class="title">Tiết kiệm hơn</h3>
                <p class="desc">Với nhiều ưu đãi cực lớn</p>
            </li>
            <li>
                <div class="thumb">
                    <img src="{{ asset('uploads/images/icon-4.png') }}">
                </div>
                <h3 class="title">Thanh toán nhanh</h3>
                <p class="desc">Hỗ trợ nhiều hình thức</p>
            </li>
            <li>
                <div class="thumb">
                    <img src="{{ asset('uploads/images/icon-5.png') }}">
                </div>
                <h3 class="title">Đặt hàng online</h3>
                <p class="desc">Thao tác đơn giản</p>
            </li>
        </ul>
    </div>
    <div class="overlay" id="overlay"></div>
    <div class="product">
        <div class="section-head">
            <h3 class="section-title">SẢN PHẨM MỚI</h3>
        </div>
        <ul class="list-product">
            @if (isset($productNew))
                @foreach ($productNew as $item)
                    <li>
                        <a href="{{ route('User.productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP]) }}"
                            title="" class="thumb">
                            <img src="{{ asset($item->Img) }}">
                        </a>
                        <a href="{{ route('User.productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP]) }}"
                            title="" class="product-name">{{ $item->Ten_SP }}</a>
                        <div class="price">
                            <span class="new">{{ number_format($item->Gia, 0, ',', '.') }}đ</span>
                            @if ($item->Gia_cu != null)
                                <span class="old">{{ number_format($item->Gia_cu, 0, ',', '.') }}đ</span>
                            @endif
                        </div>
                        <div class="task">
                            <a href="javascript:void(0)" title="Thêm giỏ hàng" class="add-cart"
                                data-id="{{ $item->San_Pham_id }}" data-masp="{{ $item->Ma_SP }}">Thêm giỏ hàng</a>
                            <a href="javascript:void(0)" title="Thêm giỏ hàng" data-id="{{ $item->San_Pham_id }}"
                                data-masp="{{ $item->Ma_SP }}" class="buy-now">Mua
                                ngay</a>

                        </div>
                        <div class="centered-form form-phu">
                            <form action="{{ route('addcart', ['Ma_SP' => $item->Ma_SP]) }}" method="post">
                                @csrf
                                <h3>Chọn tùy chọn</h3>
                                <label for="color">Màu sắc</label>
                                <select name="color" class="color-select" required>
                                    <option value=""></option>
                                </select>
                                <label for="size">Kích cỡ</label>
                                <select name="size" class="size-select">
                                    <option value=""></option>
                                </select>
                                <input type="submit" class="btn-add" value="Thêm giỏ hàng" required>
                            </form>

                        </div>
                        <div class="centered-form2 form-phu2">
                            <form action="{{ route('addcartbuynow', ['Ma_SP' => $item->Ma_SP]) }}" method="post">
                                @csrf
                                <h3>Chọn tùy chọn</h3>
                                <label for="color">Màu sắc</label>
                                <select name="color" class="color-select" required>
                                    <option value=""></option>
                                </select>
                                <label for="size">Kích cỡ</label>
                                <select name="size" class="size-select">
                                    <option value=""></option>
                                </select>
                                <input type="submit" class="btn-add" value="Mua" required>
                            </form>

                        </div>
                    </li>
                @endforeach
            @endif
        </ul>
    </div>
    <div class="product">
        <div class="section-head">
            <h3 class="section-title">Giày Nam</h3>
        </div>
        <ul class="list-product">
            @if (isset($productNam))
                @php $count = 0; @endphp
                @foreach ($productNam as $itemNam)
                    @if ($count < 4)
                        <li>
                            <a href="{{ route('User.productDetail', ['id' => $itemNam->San_Pham_id, 'Ma_SP' => $itemNam->Ma_SP]) }}"
                                title="" class="thumb">
                                <img src="{{ asset($itemNam->Img) }}">
                            </a>
                            <a href="{{ route('User.productDetail', ['id' => $itemNam->San_Pham_id, 'Ma_SP' => $itemNam->Ma_SP]) }}"
                                title="" class="product-name">{{ $itemNam->Ten_SP }}</a>
                            <div class="price">
                                <span class="new">{{ number_format($itemNam->Gia, 0, ',', '.') }}đ</span>
                                @if ($itemNam->Gia_cu != null)
                                    <span class="old">{{ number_format($itemNam->Gia_cu, 0, ',', '.') }}đ</span>
                                @endif
                            </div>
                            <div class="task">
                                <a href="javascript:void(0)" title="Thêm giỏ hàng" class="add-cart"
                                    data-id="{{ $item->San_Pham_id }}" data-masp="{{ $itemNam->Ma_SP }}">Thêm giỏ
                                    hàng</a>
                                <a href="javascript:void(0)" title="Thêm giỏ hàng" data-id="{{ $item->San_Pham_id }}"
                                    data-masp="{{ $itemNam->Ma_SP }}" class="buy-now">Mua
                                    ngay</a>

                            </div>
                            <div class="centered-form form-phu">
                                <form action="{{ route('addcart', ['Ma_SP' => $itemNam->Ma_SP]) }}" method="post">
                                    @csrf
                                    <h3>Chọn tùy chọn</h3>
                                    <label for="color">Màu sắc</label>
                                    <select name="color" class="color-select" required>
                                        <option value=""></option>
                                    </select>
                                    <label for="size">Kích cỡ</label>
                                    <select name="size" class="size-select" required>
                                        <option value=""></option>
                                    </select>
                                    <input type="submit" class="btn-add" value="Thêm giỏ hàng">
                                </form>

                            </div>
                            <div class="centered-form2 form-phu2">
                                <form action="{{ route('addcartbuynow', ['Ma_SP' => $itemNam->Ma_SP]) }}" method="post">
                                    @csrf
                                    <h3>Chọn tùy chọn</h3>
                                    <label for="color">Màu sắc</label>
                                    <select name="color" class="color-select" required>
                                        <option value=""></option>
                                    </select>
                                    <label for="size">Kích cỡ</label>
                                    <select name="size" class="size-select" required>
                                        <option value=""></option>
                                    </select>
                                    <input type="submit" class="btn-add" value="Mua">
                                </form>

                            </div>
                        </li>
                    @endif
                    @php $count++; @endphp
                @endforeach
            @endif
        </ul>
        <a href="{{ route('productAll', ['action' => 'ML001', 'name' => 'Giày Nam']) }}" class="xemthem">XEM THÊM</a>
        <div class="section-head">
            <h3 class="section-title">Giày Nữ</h3>
        </div>
        <ul class="list-product">

            @if (isset($productNu))
                @php $count = 0; @endphp
                @foreach ($productNu as $item)
                    @if ($count < 4)
                        <li>
                            <a href="{{ route('User.productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP]) }}"
                                title="" class="thumb">
                                <img src="{{ asset($item->Img) }}">
                            </a>
                            <a href="{{ route('User.productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP]) }}"
                                title="" class="product-name">{{ $item->Ten_SP }}</a>
                            <div class="price">
                                <span class="new">{{ number_format($item->Gia, 0, ',', '.') }}đ</span>
                                @if ($item->Gia_cu != null)
                                    <span class="old">{{ number_format($item->Gia_cu, 0, ',', '.') }}đ</span>
                                @endif
                            </div>
                            <div class="task">
                                <a href="javascript:void(0)" title="Thêm giỏ hàng" class="add-cart"
                                    data-id="{{ $item->San_Pham_id }}" data-masp="{{ $item->Ma_SP }}">Thêm giỏ hàng</a>
                                <a href="javascript:void(0)" title="Thêm giỏ hàng" data-id="{{ $item->San_Pham_id }}"
                                    data-masp="{{ $item->Ma_SP }}" class="buy-now">Mua
                                    ngay</a>

                            </div>
                            <div class="centered-form form-phu">
                                <form action="{{ route('addcart', ['Ma_SP' => $item->Ma_SP]) }}" method="post">
                                    @csrf
                                    <h3>Chọn tùy chọn</h3>
                                    <label for="color">Màu sắc</label>
                                    <select name="color" class="color-select" required>
                                        <option value=""></option>
                                    </select>
                                    <label for="size">Kích cỡ</label>
                                    <select name="size" class="size-select" required>
                                        <option value=""></option>
                                    </select>
                                    <input type="submit" class="btn-add" value="Thêm giỏ hàng">
                                </form>

                            </div>
                            <div class="centered-form2 form-phu2">
                                <form action="{{ route('addcartbuynow', ['Ma_SP' => $item->Ma_SP]) }}" method="post">
                                    @csrf
                                    <h3>Chọn tùy chọn</h3>
                                    <label for="color">Màu sắc</label>
                                    <select name="color" class="color-select" required>
                                        <option value=""></option>
                                    </select>
                                    <label for="size">Kích cỡ</label>
                                    <select name="size" class="size-select">
                                        <option value=""></option>
                                    </select>
                                    <input type="submit" class="btn-add" value="Mua" required>
                                </form>

                            </div>
                        </li>
                        @php $count++; @endphp
                    @endif
                @endforeach

            @endif

        </ul>
        <a href="{{ route('user.productAll', ['action' => 'ML002', 'name' => 'Giày Nữ']) }}" class="xemthem">XEM THÊM</a>

    </div>
    <script>
        $(document).ready(function() {
            $('.add-cart').click(function(e) {
                e.preventDefault();
                var productId = $(this).data('id');
                var productMaSP = $(this).data('masp');
                var overlay = $('#overlay');
                var centeredForm = $(this).closest('li').find('.centered-form');
                var colorSelect = centeredForm.find('.color-select');
                var sizeSelect = centeredForm.find('.size-select');
                overlay.fadeIn();
                centeredForm.fadeIn();
                $.ajax({
                    url: "{{ route('user.getcolor') }}",
                    method: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        id: productId,
                        Ma_SP: productMaSP
                    },
                    success: function(response) {
                        if (response.success) {
                            var colorOptions = '<option value="">Chọn màu</option>';
                            $.each(response.colors, function(index, color) {
                                colorOptions += '<option value="' + color + '">' +
                                    color + '</option>';
                            });
                            colorSelect.html(colorOptions);
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error fetching colors: ' + xhr.responseText);
                    }
                });
                centeredForm.on('change', '.color-select', function() {
                    var selectedColor = $(this).val();
                    $.ajax({
                        url: "{{ route('user.getsize') }}",
                        method: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}',
                            color: selectedColor,
                            Ma_SP: productMaSP
                        },
                        success: function(response) {
                            if (response.success) {
                                var sizeOptions =
                                    '<option value="">Chọn kích cỡ</option>';
                                $.each(response.sizes, function(index, size) {
                                    sizeOptions += '<option value="' + size +
                                        '">' + size + '</option>';
                                });
                                sizeSelect.html(sizeOptions);
                            } else {
                                alert(response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('Error fetching sizes: ' + xhr.responseText);
                        }
                    });
                });
            });

            $('.buy-now').click(function(e) {
                e.preventDefault();
                var productId = $(this).data('id');
                var productMaSP = $(this).data('masp');
                var overlay = $('#overlay');
                var centeredForm = $(this).closest('li').find('.centered-form2');
                var colorSelect = centeredForm.find('.color-select');
                var sizeSelect = centeredForm.find('.size-select');
                overlay.fadeIn();
                centeredForm.fadeIn();
                $.ajax({
                    url: "{{ route('user.getcolor') }}",
                    method: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        id: productId,
                        Ma_SP: productMaSP
                    },
                    success: function(response) {
                        if (response.success) {
                            var colorOptions = '<option value="">Chọn màu</option>';
                            $.each(response.colors, function(index, color) {
                                colorOptions += '<option value="' + color + '">' +
                                    color + '</option>';
                            });
                            colorSelect.html(colorOptions);
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error fetching colors: ' + xhr.responseText);
                    }
                });
                centeredForm.on('change', '.color-select', function() {
                    var selectedColor = $(this).val();
                    $.ajax({
                        url: "{{ route('user.getsize') }}",
                        method: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}',
                            color: selectedColor,
                            Ma_SP: productMaSP
                        },
                        success: function(response) {
                            if (response.success) {
                                var sizeOptions =
                                    '<option value="">Chọn kích cỡ</option>';
                                $.each(response.sizes, function(index, size) {
                                    sizeOptions += '<option value="' + size +
                                        '">' + size + '</option>';
                                });
                                sizeSelect.html(sizeOptions);
                            } else {
                                alert(response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('Error fetching sizes: ' + xhr.responseText);
                        }
                    });
                });
            });

            $('#overlay').click(function() {
                $(this).fadeOut();
                $('.centered-form').fadeOut();
                $('.centered-form2').fadeOut();
            });
        });
    </script>




@endsection
