@extends('layout.Cartlayout')
@section('title', 'gio hang')
@section('content')
    <style>
          #sidebar ul li a.mau-menu {
            border-left: 2px solid #fa0101;
            background-color: #ffe3e3;
        }
    </style>
    <div id="sidebar">
        <ul id="tt">
            <li><a href="{{ route('user.tt') }}">Thông tin cá nhân</a></li>
            <li><a class="mau-menu" href="{{ route('user.doipass') }}">Đổi mật khẩu</a></li>
            <li><a href="{{ route('user.order') }}">Đơn hàng</a></li>
        </ul>
    </div>
    <div id="content">
        <h2>Đổi mật khẩu</h2>
        <form id="frm-doimk" action="{{ route('user.doimk') }}" method="post">
            @csrf
            <label for="name">Mật khẩu cũ</label>
            <input type="password" id="password" name="password" required>

            <label for="passnew">mật khẩu mới</label>
            <input type="password" id="passnew" name="passnew" required>

            <label for="passnewN">Nhập lại mật khẩu mới</label>
            <input type="password" id="passnewN" name="passnewN" required>
            @if (isset($tb))
                <p style="color:red; margin-bottom:10px">{{ $tb }}</p>
            @endif

            <input type="submit" value="Đổi mật khẩu">

        </form>
    </div>

@endsection
