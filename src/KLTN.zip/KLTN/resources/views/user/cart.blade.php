@extends('layout.Cartlayout')
@section('title','gio hang')
@section('content')
                @if (session()->has('userlogin') && Cart::count()>0)
                <div id="info-cart">
                    <form action="{{ route('update.cart') }}" method="post">
                        @csrf
                
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>STT</td>
                                    <td>Ảnh sản phẩm</td>
                                    <td>Tên sản phẩm</td>
                                    <td>Giá sản phẩm</td>
                                    <td>Màu sắc</td>
                                    <td>Kích thước</td>
                                    <td>Số lượng</td>
                                    <td>Thành tiền</td>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $t = 0;
                                @endphp
                                @foreach (Cart::content() as $item)
                                    @php
                                        $t++;
                                    @endphp
                                  
                                    <tr>
                                        <td>{{ $t }}</td>
                                        <td>
                                            <a href="" title="" class="thumb">
                                                <img src="{{ asset($item->options->img) }}" alt="">
                                            </a>
                                        </td>
                                        <td>
                                            <a href="" title=""
                                                class="name-product">{{ $item->name }}</a>
                                        </td>
                                        <td>{{ number_format($item->price, 0, ',', '.') }} đ</td>
                                        <td>{{ $item->options->color }}</td>
                                        <td>{{ $item->options->size }}</td>
                                        <td>
                                         
                                            <input type="number" min="1" max="{{ $item->options->soluong }}" name="qty[{{ $item->rowId }}]"
                                                value="{{ $item->qty }}" class="num-order">
                                        </td>
                                        <td>{{ number_format($item->total, 0, ',', '.') }} đ</td>
                                        <td>
                                            <a href="{{ route('remove.cart', ['rowId' => $item->rowId]) }}"
                                                title="" class="del-product"><i
                                                    class="fa-solid fa-trash-can"></i></a>
                                        </td>
                                    </tr>
                                @endforeach


                            </tbody>
                            <tfoot>
                                <tr class="not">
                                    <td colspan="8">

                                        <p id="total-price">Tổng giá: <span>{{ Cart::total() }} đ</span></p>

                                    </td>
                                </tr>
                                <tr class="not">
                                    <td id="tt" colspan="8">



                                        <input type="submit" value="Cập nhật giỏ hàng" id="update-cart" name="checkout-cart">
                                          @if (session('tb'))
                    <p style="color: red">
                        {{ session('tb') }}
                    </p>
                @endif
                                        <a href="{{route('checkoutcart')}}" title="" id="checkout-cart">Đặt hàng</a>

                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </form>
                </div>
                <div id="action-cart-wp">

                    <p class="title">Click vào <span>“Cập nhật giỏ hàng”</span> để cập nhật số lượng. Click vào
                        <span>“Xoá” </span>để xóa sản phẩm ra khỏi giỏ hàng. Nhấn vào thanh toán để hoàn tất mua hàng.
                    </p>
                    <a href="{{ route('Trangchu') }}" title="" id="buy-more">Mua tiếp</a><br />
                    <a href="{{ route('destroy.cart') }}" title="" id="delete-cart">Xóa giỏ hàng</a>

                </div>
                @else
                <div id="thong-bao">
                    <p >Không có sản phẩm trong giỏ hàng</p>
                    @if (session()->has('userlogin'))
                    <a href="{{route('Trangchu')}}"> Mua Ngay</a>
                    @else
                    <a href="{{route('index')}}"> Mua Ngay</a>
                    @endif
                    

                </div>
                @endif
                
               
          
@endsection