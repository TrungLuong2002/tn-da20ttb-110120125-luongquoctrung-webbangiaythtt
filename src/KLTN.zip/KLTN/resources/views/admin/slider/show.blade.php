@extends('admin.layout.main')
@section('title', 'quan li anh san pham')
@section('content')
    <div class="container">

        <h1>Danh sách slide</h1>
        <div id="wp-img">
            <a href="{{ route('admin.createslidershow') }}" class="btn-them">+Thêm slide</a>
            <table id="tb-image">
                <thead>
                    <tr>
                        
                        <th>Ảnh</th>
    
                    </tr>
                </thead>
                <tbody>
    
                    @if ($slide)
                        <tr>
    
                            <td id="image">
                                @foreach ($slide as $item)
                                    <div>
                                        <img src="{{ asset($item->Link) }}"" alt="">
                                        <a class="btn-xoa" href="{{route('admin.deleteslider',['id'=>$item->Slide_id])}}"><i class="fa-solid fa-trash"></i></a>
                                    </div>
                                @endforeach
                            </td>
    
    
                        </tr>
    
                    @endif
                </tbody>
            </table>
        </div>
     
    </div>
@endsection
