@extends('admin.layout.main')
@section('title', 'Thêm Sản Phẩm')
@section('content')
    <div class="container">
        <style>
            #frm-themAnhSP #wp-form {
                width: 400px;
                margin: 0 auto;
                display: flex;
                flex-direction: column;
                gap: 15px;
                padding: 20px;
                border: 1px solid #ddd;
                border-radius: 8px;
                background-color: #f9f9f9;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }

            #frm-themAnhSP #wp-form .form-group {
                display: flex;
                flex-direction: column;
            }

            #frm-themAnhSP #wp-form .form-group label {
                margin-bottom: 5px;
                font-weight: bold;
            }

            #frm-themAnhSP #wp-form .form-group select,
            #frm-themAnhSP #wp-form .form-group input[type="file"] {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }

            #frm-themAnhSP #wp-form .btn {
                align-self: center;
                padding: 10px 20px;
                border: none;
                border-radius: 4px;
                background-color: #007bff;
                color: white;
                font-size: 16px;
                cursor: pointer;
                transition: background-color 0.3s;
            }

            #frm-themAnhSP #wp-form .btn:hover {
                background-color: #0056b3;
            }
        </style>

        <h1>Thêm slide</h1>
        <form id="frm-themAnhSP" action="{{ route('admin.createslider') }}" method="POST" 
            enctype="multipart/form-data">
            @csrf
            <div id="wp-form">
              
                <div class="form-group">
                    <label for="img">Ảnh</label>
                    <input type="file" class="form-control-file" id="image" name="image">
                    @error('image')
                        <p style="color: red">{{ $message }}</p>
                    @enderror
                </div>

                <input type="submit" class="btn" value="Thêm">
                @if (session('tb'))
                <p style="color: red">{{ session('tb') }}</p>
            @endif
            </div>
        </form>
    </div>
@endsection
