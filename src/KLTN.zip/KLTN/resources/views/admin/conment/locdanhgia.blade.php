@extends('admin.layout.main')
@section('title', 'quan li san pham')
@section('content')
    <style>
        .frm-traloi .traloi {
            font-family: Arial, Helvetica, sans-serif;
            width: 300px;
            height: 50px;
        }
        #frm-locdanhgia{
            margin-bottom: 20px;
        }
        #frm-locdanhgia #locdanhgia{
            padding: 3px;
        }
        #frm-locdanhgia #btn-locdanhgia{
            display: inline-block;
            padding: 3px;
         
        }
    </style>
    <div class="container">

        <h1>Danh sách đánh giá {{$title}}</h1>
        <form action="{{route('admin.locdanhgia',['noidung'=>"khac"])}}" id="frm-locdanhgia">
            @csrf
            <select name="locdanhgia" id="locdanhgia">
                <option value="">------------</option>
                <option value="all">Tất cả đánh giá</option>
                <option value="chua-tra-loi">Chưa trả lời</option>
                <option value="7ngay">7 ngày</option>
                <option value="1sao">1 sao</option>
                <option value="2sao">2 sao</option>
                <option value="3sao">3 sao</option>
                <option value="4sao">4 sao</option>
                <option value="5sao">5 sao</option>
            </select>
        
            <input type="submit" id="btn-locdanhgia" value="Lọc">
            @error('locdanhgia')
            <p style="color: red">{{$message}}</p>
        @enderror
        </form>
        <table id="tb-order">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã sản phẩm</th>
                    <th>Số sao</th>
                    <th>Nội dung</th>
                    @if (session('tb'))
                        <p style="color: #00af26">{{ session('tb') }}</p>
                    @endif

                </tr>
            </thead>
            <tbody>
                @php
                    $stt = 0;
                @endphp
                @if ($danhgia)
                    @foreach ($danhgia as $item)
                        @php
                            $stt++;
                        @endphp
                        <tr>
                            <td>{{ $stt }}</td>
                            <td>{{ $item->product->Ma_SP }}</td>
                            <td>
                                @for ($i = 1; $i <= $item->So_Sao; $i++)
                                    <span class="user-rating" style="color: #f5b301;"">&#9733;</span>
                                @endfor
                            </td>
                            <td>{{ $item->Noi_Dung }}</td>
                            <td>
                                <form action="{{ route('admin.traloidanhgia', ['id' => $item->Danh_Gia_id]) }}"
                                    class="frm-traloi">
                                    @csrf
                                    <textarea name="traloi" class="traloi">{{ $item->Tra_Loi }}</textarea><br>
                                    <input type="submit" value="Trả lời">
                                </form>
                            </td>
                            <td>
                                <a class="btn-xoa" href="{{route('admin.deletedanhgia',['id'=>$item->Danh_Gia_id])}}"><i class="fa-solid fa-trash"></i></a>
                            </td>
                        
                        </tr>
                    @endforeach
                @endif


            </tbody>
        </table>
    </div>

@endsection
