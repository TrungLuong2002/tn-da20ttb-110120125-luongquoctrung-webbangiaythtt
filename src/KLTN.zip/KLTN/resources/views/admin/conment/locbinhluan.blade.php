@extends('admin.layout.main')
@section('title', 'quan li san pham')
@section('content')
    <style>
        .frm-traloi .traloi {
            font-family: Arial, Helvetica, sans-serif;
            width: 300px;
            height: 50px;
        }
        #frm-locdanhgia{
            margin-bottom: 20px;
        }
        #frm-locdanhgia #locdanhgia{
            padding: 3px;
        }
        #frm-locdanhgia #btn-locdanhgia{
            display: inline-block;
            padding: 3px;
         
        }
    </style>
    <div class="container">

        <h1>Danh sách bình luận {{$title}}</h1>
        <form action="{{route('admin.locbinhluan',['noidung'=>"khac"])}}" id="frm-locdanhgia">
            @csrf
            <select name="locdanhgia" id="locdanhgia">
                <option value="">------------</option>
                <option value="all">Tất cả bình luận</option>
                <option value="chua-tra-loi">Chưa trả lời</option>
                <option value="7ngay">7 ngày qua</option>
            </select>
        
            <input type="submit" id="btn-locdanhgia" value="Lọc">
            @error('locdanhgia')
            <p style="color: red">{{$message}}</p>
        @enderror
        </form>
        <table id="tb-order">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Tên người dùng</th>
                    <th>Mã sản phẩm</th>
                    <th>Nội dung</th>

                    @if (session('tb'))
                        <p style="color: #00af26">{{ session('tb') }}</p>
                    @endif

                </tr>
            </thead>
            <tbody>
                @php
                    $stt = 0;
                @endphp
                @if ($binhluan)
                    @foreach ($binhluan as $item)
                        @php
                            $stt++;
                        @endphp
                        <tr>
                            <td>{{ $stt }}</td>
                            <td>{{ $item->Ten_User }}</td>
                            <td>{{ $item->Ma_SP }}</td>
                            <td>{{ $item->Binh_Luan }}</td>
                            <td>
                                <form action="{{ route('admin.traloibinhluan', ['id' => $item->Binh_Luan_id]) }}"
                                    class="frm-traloi">
                                    @csrf
                                    <textarea name="traloi" class="traloi">{{ $item->Tra_Loi }}</textarea><br>
                                    <input type="submit" value="Trả lời">
                                </form>
                            </td>
                            <td>
                                <a class="btn-xoa" href="{{ route('admin.deletebinhluan', ['id' => $item->Binh_Luan_id]) }}"><i
                                        class="fa-solid fa-trash"></i></a>
                            </td>

                        </tr>
                    @endforeach
                @endif


            </tbody>
        </table>
    </div>

@endsection
