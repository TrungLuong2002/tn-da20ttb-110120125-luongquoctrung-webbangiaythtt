@extends('admin.layout.main')
@section('title', 'Trang Chủ')
@section('content')

    <div class="container">
        <style>
            #containerr {
                width: 100%;
                height: 100%;
                margin: 0;
                padding: 0;
            }

            #list-block {
                display: flex;
                list-style-type: none;
                padding: 0;
                margin-top: 20px;
                margin-bottom: 50px;
            }

            #list-block li {
                flex: 1;
                margin: 5px;
                border: 1px solid #ddd;
                text-align: center;
                position: relative;
            }

            #list-block li .content {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px;
            }

            #list-block li .content .title {
                text-align: left;
            }

            #list-block li .content .title span {
                font-size: 30px;
                font-weight: bold;
                color: #fff;
            }

            #list-block li .content .title p {
                font-size: 16px;
                color: #fff;
            }

            #list-block li .content .icon {
                text-align: right;
                font-size: 40px;
                color: #fff;
                opacity: 0.5;
            }

            #list-block li .chi-tiet {
                display: block;
                width: 100%;
                text-decoration: none;
                color: #000;
                margin-top: 10px;
                background-color: rgba(0, 0, 0, 0.1);
                opacity: 0.7;
                padding: 4px;
                transition: opacity 0.3s;
                color: #fff;
            }

            #list-block li .chi-tiet i {
                margin-left: 5px;
                background-color: #fff;
                border-radius: 50%;
                color: #000;
            }

            #list-block li .chi-tiet:hover {
                opacity: 1;
            }

            #user-block {
                background-color: rgb(255, 102, 0);
            }

            #order-block {
                background-color: rgb(0, 88, 143);
            }

            #coment-block {
                background-color: rgb(143, 0, 112);
            }

            #product-block {
                background-color: rgb(154, 21, 21);
            }

            #doanh-thu {
                border: 1px solid #bcbcbc;
                padding: 20px;
                border-radius: 20px; 
                background-color: #fbf1e6;
                color:#0c0298;
            }

            #doanh-thu h2 {
                font-size: 20px;
                font-weight: bold;
                margin-bottom: 10px;
            }

            #wp-end {
                display: flex;
            }

            #user {
                flex-basis: 30%;
            }
            #tk-user {
                width: 70%;
                border: 1px solid #999;
               text-align: left;
               padding-left: 20px;
               margin-top: 20px;
               border-radius: 20px; 
               background-color: #fde0e0;
               color:#410061;
               margin: 20px auto;
        
            }
            #tk-user h3{
             text-align: center;
            }

            #product {
                flex-basis: 70%;
                height: 500px;
            }
        </style>

        <h1>XIN CHÀO ADMIN</h1>

        <ul id="list-block">
            <li id="user-block">
                <div class="content">
                    <div class="title">
                        <span>{{$user_count}}</span>
                        <p>Người Dùng</p>
                    </div>
                    <div class="icon">
                        <p><i class="fa-solid fa-user-group"></i></p>
                    </div>
                </div>
                <a href="{{ route('admin.user') }}" class="chi-tiet">Chi tiết<i class="fa-solid fa-arrow-right"></i></a>
            </li>
            <li id="order-block">
                <div class="content">
                    <div class="title">
                        <span>{{$order_count}}</span>
                        <p>Đơn Hàng</p>
                    </div>
                    <div class="icon">
                        <p><i class="fa-solid fa-cart-shopping"></i></p>
                    </div>
                </div>
                <a href="{{ route('admin.order') }}" class="chi-tiet">Chi tiết<i class="fa-solid fa-arrow-right"></i></a>
            </li>
            <li id="coment-block">
                <div class="content">
                    <div class="title">
                        <span>{{$comment_count}}</span>
                        <p>Bình Luận</p>
                    </div>
                    <div class="icon">
                        <p><i class="fa-regular fa-comments"></i></p>
                    </div>
                </div>
                <a href="{{ route('admin.showbinhluan') }}" class="chi-tiet">
                    Chi tiết<i class="fa-solid fa-arrow-right"></i>
                </a>
            </li>
            <li id="product-block">
                <div class="content">
                    <div class="title">
                        <span>{{$product_count}}</span>
                        <p>Sản Phẩm</p>
                    </div>
                    <div class="icon">
                        <p><i class="fa-solid fa-box"></i></p>
                    </div>
                </div>
                <a href="{{ route('admin.product') }}" class="chi-tiet">Chi tiết<i class="fa-solid fa-arrow-right"></i></a>
            </li>
        </ul>

        <h1>Thống Kê</h1>
        <div id="doanh-thu">
            <h2>Doanh Thu</h2>
            <p>Tổng hôm nay: {{ number_format($count_dt, 0, ',', '.') }}.000đ</p>
            <p>Đơn hàng chưa xử lí: {{ $count_xl }}</p>
            <p>Lọc:</p>
            <form action="">
                @csrf
                <select id="tuy-chon">
                    <option value="">-----</option>
                    <option value="7ngay">7 ngày qua</option>
                    <option value="thang-truoc">Tháng trước</option>
                    <option value="30ngay">30 ngày qua</option>
                </select>
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
            </form>

            <div id="myfirstchart" style="height: 250px;"></div>
        </div>

        <div id="wp-end">
            <div id="user">
                <div id="tk-user">
                    <h3>Thống kê người dùng</h3>
                    <p>Tổng số người dùng: {{$user_count}}</p>
                    <p>Truy cập trong tháng trước: {{ $tong_thang_truoc_count }}</p>
                    <p>Truy cập trong tháng này: {{ $tong_thang_nay_count }}</p>
                    <p>Số người dùng mới trong tháng: {{ $user_new }}</p>
                    <p>Đang truy cập: {{ $user_truy_cap_count }}</p>
                </div>
               
            </div>

            <div id="product">
                <div id="containerr"></div>
            </div>
        </div>

    </div>
    <script>
        anychart.onDocumentReady(function() {
            var productsData = @json($resultJson);

            // console.log(productsData);
            var data = anychart.data.set(
                productsData.map(function(product) {
                    return {
                        'x': product.ma_sp,
                        'value': product.so_luong
                    };
                })
            );

            console.log(data);
            var chart = anychart.pie(data)
                .innerRadius('55%')
                .title('Sản phẩm được ưa chuộng')
                .container('containerr');
            // create a color palette
            // var palette = anychart.palettes.distinctColors();

            // set the colors according to the brands
            //   palette.items([
            //     { color: '#1dd05d' },
            //     { color: '#000000' },
            //     { color: '#00a3da' },
            //     { color: '#156ef2' },
            //     { color: '#f60000' },
            //     { color: '#96a6a6' }
            //   ]);

            // var label = anychart.standalones.label();

            // // configure the label settings
            // label
            //     .useHtml(true)
            //     .text(
            //         '<span style = "color: #313136; font-size:20px;">Global Market Share of <br/> Music Streaming Apps</span>' +
            //         '<br/><br/></br><span style="color:#444857; font-size: 12px;"><i>Spotify and Apple Music have more <br/>than 50% of the total market share</i></span>'
            //     )
            //     .position('center')
            //     .anchor('center')
            //     .hAlign('center')
            //     .vAlign('middle');

            // // set the label as the center content
            // chart.center().content(label);
            // // apply the donut chart color palette
            // chart.palette(palette);
            chart.draw();
        });
    </script>



@endsection
