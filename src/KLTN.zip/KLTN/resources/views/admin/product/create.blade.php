@extends('admin.layout.main')
@section('title', 'Thêm Sản Phẩm')
@section('content')
    <div class="container">
        <h1>Thêm Sản Phẩm Mới</h1>
        <form id="frm-themSP" method="POST" action="{{route('admin.product.createproduct')}}" enctype="multipart/form-data">
            @csrf
            <div id="wp-form">
                <div id="left">
                    <div class="form-group">
                        <label for="ma_sp">Mã Sản Phẩm</label>
                        <input type="text" class="form-control" id="ma_sp" name="ma_sp">
                        @error('ma_sp')
                            <p style="color: red">{{$message}}</p>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="ten_sp">Tên Sản Phẩm</label>
                        <input type="text" class="form-control" id="ten_sp" name="ten_sp">
                        @error('ten_sp')
                        <p style="color: red">{{$message}}</p>
                    @enderror
                    </div>
                    <div class="form-group">
                        <label for="gia">Giá</label>
                        <input type="text" class="form-control" id="gia" name="gia">
                        @error('gia')
                        <p style="color: red">{{$message}}</p>
                    @enderror
                    </div>
                </div>
                <div id="right">
                    <div class="form-group">
                        <label for="gia_cu">Giá Cũ</label>
                        <input type="text" class="form-control" id="gia_cu" name="gia_cu">
                        @error('gia_cu')
                        <p style="color: red">{{$message}}</p>
                    @enderror
                    </div>
                    <div class="form-group">
                        <label for="ma_loai">Loại</label>
                        <select name="ma_loai" id="ma_loai" class="form-control">
                            @if ($maloai)
                                @foreach ($maloai as $maloai)
                                <option value="{{$maloai->Ma_Loai}}">{{$maloai->Ten_loai}}</option>
                                @endforeach
                            @endif
                            
                            
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="img">Ảnh</label>
                        <input type="file" class="form-control-file" id="img" name="img">
                        @error('img')
                        <p style="color: red">{{$message}}</p>
                    @enderror
                    </div>
                </div>
                
            </div>
            <div>
                <label for="img">Mô tả</label>
                <textarea name="mo_ta" id="text"></textarea>
                @error('mo_ta')
                <p style="color: red">{{$message}}</p>
            @enderror
            </div>
            @if (session('tb'))
                    <p style="color: red">
                        {{ session('tb') }}
                    </p>
                @endif
            <input type="submit" class="btn " value="Thêm">
            
        </form>
    </div>
@endsection
