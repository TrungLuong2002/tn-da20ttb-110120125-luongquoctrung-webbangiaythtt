@extends('admin.layout.main')
@section('title', 'quan li anh san pham')
@section('content')
    <div class="container">

        <h1>Danh sách ảnh sản phẩm</h1>
        <a href="{{ route('admin.product.showcreateimage') }}" class="btn-them">+Thêm Ảnh</a>
        <table id="tb-image">
            <thead>
                <tr>
                    <th>STT</th>

                    <th>Mã Sản Phẩm</th>
                    <th>Ảnh</th>


                </tr>
            </thead>
            <tbody>
                @php
                    $stt = 0;
                @endphp
                @if ($image)
                    @foreach ($image as $ma_sp => $imageGroup)
                        @php
                            $stt++;
                        @endphp
                        <tr>
                            <td id="stt">{{ $stt }}</td>
                            <td id="ma_sp">{{ $ma_sp }}</td>
                            <td id="image">
                                @foreach ($imageGroup as $image)
                                    <div>
                                        <img src="{{ asset($image->Link) }}"" alt="">
                                        <a class="btn-xoa"
                                            href="{{ route('admin.product.deleteimage_item', ['id' => $image->Anh_id]) }}"><i
                                                class="fa-solid fa-trash"></i></a>

                                    </div>
                                @endforeach
                            </td>
                            <td>
                                <a class="btn-xoa" href="{{route('admin.product.deleteimage',['Ma_SP'=>$ma_sp])}}"><i class="fa-solid fa-trash"></i></a>
                            </td>

                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>
@endsection
