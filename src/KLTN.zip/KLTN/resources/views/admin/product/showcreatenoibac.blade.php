@extends('admin.layout.main')
@section('title', 'Thêm chi tiết Sản Phẩm')
@section('content')
    <div class="container">
        <h1>Thêm Sản Phẩm Nổi Bậc</h1>
        <form id="frm-themCT_SP" method="POST" action="{{ route('admin.product.createnoibac') }}"
            enctype="multipart/form-data">
            @csrf
            <div id="wp-form">

                <div class="form-group">
                    <label for="masp">Mã Sản Phẩm:</label>
                    <select name="ma_sp" id="">
                        <option value="">--------</option>
                        @if ($product)
                            @foreach ($product as $item)
                                <option value="{{ $item->Ma_SP }}">{{ $item->Ma_SP }}</option>
                            @endforeach
                        @endif
                    </select>
                    @error('ma_sp')
                        <p style="color:red">{{ $message }}</p>
                    @enderror
                </div>
               
                @if (session('tb'))
                    <p style="color: red">{{ session('tb') }}</p>
                @endif
                <input type="submit" class="btn " value="Thêm">
            </div>





        </form>
    </div>
@endsection
