@extends('admin.layout.main')
@section('title','quan li san pham')
@section('content')
<div class="container">
<style>
    #frm-serch-sp{
        float: right;
    }
    #frm-serch-sp #timkiem{
       padding: 5px;

    }
    #frm-serch-sp #btn-tim{
       
       padding: 7px;
border: none;
       
    }
    #tb-kho{
        font-family: Arial, Helvetica, sans-serif;
        font-weight: bold;
    }
    #tb-kho a{
       display: inline-block;
       text-decoration: none;
       color: red;
    }

</style>
    <h1>Kết quả tìm kiếm cho "{{$title}}"</h1>
   
    <a href="{{route('admin.product.create')}}" class="btn-them">+Thêm Sản Phẩm</a>
    <a href="{{ route('admin.product.rac') }}" class="btn-rac"><i class="fa-solid fa-trash-can"></i></a>
    <form action="{{route('admin.product.search')}}" id="frm-serch-sp" method="post">
        @csrf
        <input type="text" id="timkiem" name="search" placeholder="Nhập tên hoặc mã sản phẩm">
        <input type="submit" id="btn-tim" value="Tìm kiếm" class="btn-them">
    </form>
   
   
  
    <table id="tb-product">
        <thead>
            <tr>
                <th>STT</th>
                <th>Ảnh</th>
                <th>Mã Sản Phẩm</th>
                <th>Tên Sản Phẩm</th>
                <th>Giá</th>
                <th>Giá Cũ</th>
                <th>Mã Loại</th>
                
            </tr>
        </thead>
        <tbody>
            @php
                $stt=0;
            @endphp
            @if($product)
            @foreach ( $product as $item)
            @php
                $stt++;
            @endphp
            <tr>
                <td>{{ $stt }}</td>
                <td><img src="{{asset($item->Img)}}"" alt=""></td>
                <td>{{$item->Ma_SP}}</td>
                <td>{{$item->Ten_SP}}</td>
                <td>{{$item->Gia}}</td>
                <td>{{$item->Gia_cu}}</td>
                <td>{{$item->Ma_Loai}}</td>
                <td>
                    <a class="btn-chitiet" href="{{route('admin.product.detail',['Ma_SP'=>$item->Ma_SP])}}">Xem chi tiết</a>
                </td>
                <td>
                    <a class="btn-sua" href="{{route('admin.product.updateshow',['id'=>$item->San_Pham_id])}}"><i class="fa-solid fa-gear"></i></a>
                    <a class="btn-xoa" href="{{route('admin.product.delete',['id'=>$item->San_Pham_id])}}"><i class="fa-solid fa-trash"></i></a>
                   
                </td>
            </tr>
            @endforeach
            @endif
        </tbody>
    </table>
</div>
@endsection
