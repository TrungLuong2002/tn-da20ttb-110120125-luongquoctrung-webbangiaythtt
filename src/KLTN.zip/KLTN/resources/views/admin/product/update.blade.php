@extends('admin.layout.main')
@section('title', 'Thêm Sản Phẩm')
@section('content')
    <div class="container">
        <h1>Sửa sản phẩm</h1>
        @if ($product)
            <form id="frm-themSP" method="POST"
                action="{{ route('admin.product.updateproduct', ['id' => $product->San_Pham_id]) }}"
                enctype="multipart/form-data">
                @csrf


                <div id="wp-form">
                    <div id="left">
                        <div class="form-group">
                            <label for="ma_sp">Mã Sản Phẩm</label>
                            <input type="text" class="form-control" id="ma_sp" name="ma_sp"
                                value="{{ $product->Ma_SP }}">
                            @error('ma_sp')
                                <p style="color: red">{{ $message }}</p>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="ten_sp">Tên Sản Phẩm</label>
                            <input type="text" class="form-control" id="ten_sp" name="ten_sp"
                                value="{{ $product->Ten_SP }}">
                            @error('ten_sp')
                                <p style="color: red">{{ $message }}</p>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="gia">Giá</label>
                            <input type="text" class="form-control" id="gia" name="gia"
                                value="{{ $product->Gia }}">
                            @error('gia')
                                <p style="color: red">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    <div id="right">
                        <div class="form-group">
                            <label for="gia_cu">Giá Cũ</label>
                            <input type="text" class="form-control" id="gia_cu" name="gia_cu"
                                value="{{ $product->Gia_cu }}">
                                
                        </div>
                        <div class="form-group">
                            <label for="ma_loai">Loại</label>
                            <select name="ma_loai" id="ma_loai" class="form-control">
                                @if ($maloai)
                                    @foreach ($maloai as $maloai)
                                        <option value="{{ $maloai->Ma_Loai }}"
                                            {{ $product->Ma_Loai == $maloai->Ma_Loai ? 'selected' : '' }}>
                                            {{ $maloai->Ten_loai }}</option>
                                    @endforeach
                                @endif


                            </select>
                        </div>
                        <div class="form-group">
                            <label for="img">Ảnh</label>
                            <input type="file" class="form-control-file" id="img" name="img">
                            @error('img')
                                <p style="color: red">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                </div>
                <div>
                    <label for="img">Mô tả</label>
                    <textarea name="mo_ta" id="text">{{ $product->Mo_Ta }}</textarea>
                    @error('mo_ta')
                        <p style="color: red">{{ $message }}</p>
                    @enderror
                </div>
                <input type="submit" class="btn " value="Cập nhật">



            </form>
        @endif
    </div>
@endsection
