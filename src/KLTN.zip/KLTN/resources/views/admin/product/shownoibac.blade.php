@extends('admin.layout.main')
@section('title','quan li san pham')
@section('content')
<div class="container">
<style>
    #frm-serch-sp{
        float: right;
    }
    #frm-serch-sp #timkiem{
       padding: 5px;

    }
    #frm-serch-sp #btn-tim{
       
       padding: 7px;
border: none;
       
    }
   

</style>
    <h1>Danh sách sản phẩm nổi bậc</h1>
   
    <a href="{{route('admin.product.showcreatenoibac')}}" class="btn-them">+Thêm Sản Phẩm</a>

    <table id="tb-product">
        <thead>
            <tr>
                <th>STT</th>
                <th>Ảnh</th>
                <th>Mã Sản Phẩm</th>
                <th>Tên Sản Phẩm</th>
                
            </tr>
        </thead>
        <tbody>
            @php
                $stt=0;
            @endphp
            @if($product)
            @foreach ( $product as $item)
            @php
                $stt++;
            @endphp
            <tr>
                <td>{{ $stt }}</td>
                <td><img src="{{asset($item->product->Img)}}"" alt=""></td>
                <td>{{$item->Ma_SP}}</td>
                <td>{{$item->product->Ten_SP}}</td>
              
               
                <td>
                    <a class="btn-xoa" href="{{route('admin.product.deletenoibac',['id'=>$item->SP_NB_id])}}"><i class="fa-solid fa-trash"></i></a>
                   
                </td>
            </tr>
            @endforeach
            @endif
        </tbody>
    </table>
</div>
@endsection
