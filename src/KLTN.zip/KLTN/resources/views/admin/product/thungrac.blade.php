@extends('admin.layout.main')
@section('title','quan li san pham')
@section('content')
<div class="container">

    <h1>Thùng rác</h1>
    <table id="tb-product">
        <thead>
            <tr>
                <th>STT</th>
                <th>Ảnh</th>
                <th>Mã Sản Phẩm</th>
                <th>Tên Sản Phẩm</th>
                <th>Giá</th>
                <th>Giá Cũ</th>
                <th>Mã Loại</th>
                
            </tr>
        </thead>
        <tbody>
            @php
                $stt=0;
            @endphp
            @if($rac)
            @foreach ( $rac as $item)
            @php
                $stt++;
            @endphp
            <tr>
                <td>{{ $stt }}</td>
                <td><img src="{{asset($item->Img)}}"" alt=""></td>
                <td>{{$item->Ma_SP}}</td>
                <td>{{$item->Ten_SP}}</td>
                <td>{{$item->Gia}}</td>
                <td>{{$item->Gia_cu}}</td>
                <td>{{$item->Ma_Loai}}</td>
                <td>
                    <a class="btn-chitiet" href="{{route('admin.product.detail',['Ma_SP'=>$item->Ma_SP])}}">Xem chi tiết</a>
                </td>
                <td>
                    <a class="btn-sua" href="{{route('admin.product.khoiphuc',['id'=>$item->San_Pham_id])}}">Khôi phục</a>
                    <a class="btn-xoa" href="{{route('admin.product.xoavv',['id'=>$item->San_Pham_id])}}"> Xoá</a>
                   
                </td>
            </tr>
            @endforeach
            @endif
        </tbody>
    </table>
</div>
@endsection
