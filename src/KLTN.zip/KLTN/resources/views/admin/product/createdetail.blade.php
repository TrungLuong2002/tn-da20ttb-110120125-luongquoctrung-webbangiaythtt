@extends('admin.layout.main')
@section('title', 'Thêm chi tiết Sản Phẩm')
@section('content')
    <div class="container">
        <h1>Thêm Chi Tiết Sản Phẩm</h1>
        <form id="frm-themCT_SP" method="POST" action="{{ route('admin.product.createdetailproduct') }}"
            enctype="multipart/form-data">
            @csrf
            <div id="wp-form">

                <div class="form-group">
                    <label for="masp">Mã Sản Phẩm:</label>
                    <select name="ma_sp" id="">
                        <option value="">--------</option>
                        @if ($product)
                            @foreach ($product as $item)
                                <option value="{{ $item->Ma_SP }}">{{ $item->Ma_SP }}</option>
                            @endforeach
                        @endif
                    </select>
                    @error('ma_sp')
                        <p style="color:red">{{ $message }}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="color">Màu Sắc:</label>
                    <select name="color" id="">
                        <option value="">--------</option>
                        @if ($color)
                            @foreach ($color as $item)
                                <option value="{{ $item->Ten_Mau }}">{{ $item->Ten_Mau }}</option>
                            @endforeach
                        @endif

                    </select>
                    @error('color')
                        <p style="color:red">{{ $message }}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="size">Kích Thước</label>
                    <select name="size" id="">
                        <option value="">--------</option>
                        @if ($size)
                            @foreach ($size as $item)
                                <option value="{{ $item->Kich_Thuoc }}">{{ $item->Kich_Thuoc }}</option>
                            @endforeach
                        @endif
                    </select>
                    @error('size')
                        <p style="color:red">{{ $message }}</p>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="soluong">Số lượng:</label>
                    <input type="text" name="soluong" id="soluong">
                    @error('soluong')
                        <p style="color:red">{{ $message }}</p>
                    @enderror
                </div>
                @if (session('tb'))
                    <p style="color: red">{{ session('tb') }}</p>
                @endif
                <input type="submit" class="btn " value="Thêm">
            </div>





        </form>
    </div>
@endsection
