@extends('admin.layout.main')
@section('title', 'Thêm chi tiết Sản Phẩm')
@section('content')
    <div class="container">
        <h1>Sửa Chi Tiết Sản Phẩm</h1>
        <form id="frm-themCT_SP" method="POST" action="{{route('admin.product.updateproductdetail',['id'=>$productdetail->Chi_Tiet_SP_id])}}"
            enctype="multipart/form-data">
            @csrf
            <div id="wp-form">

                <div class="form-group">
                    <label for="masp">Mã Sản Phẩm:</label>
                    <input type="text" name="ma_sp" value="{{$productdetail->Ma_SP}}" id="ma_sp">
                   
                </div>
                <div class="form-group">
                    <label for="color">Màu Sắc:</label>
                    <select name="color" id="">
                        @if ($color)
                            @foreach ($color as $item)
                                <option value="{{ $item->Ten_Mau }}"   {{ $productdetail->Ten_Mau == $item->Ten_Mau ? 'selected' : '' }}>{{ $item->Ten_Mau }}</option>
                            @endforeach
                        @endif

                    </select>
                   
                </div>
                <div class="form-group">
                    <label for="size">Kích Thước</label>
                    <select name="size" id="">
                        @if ($size)
                            @foreach ($size as $item)
                                <option value="{{ $item->Kich_Thuoc }}"   {{ $productdetail->Kich_Thuoc == $item->Kich_Thuoc ? 'selected' : '' }}>{{ $item->Kich_Thuoc }}</option>
                            @endforeach
                        @endif
                    </select>
                   
                </div>
                <div class="form-group">
                    <label for="soluong">Số lượng:</label>
                    <input type="text" name="soluong" id="soluong" value="{{$productdetail->So_Luong}}">
                </div>
                @if (session('tb'))
                    <p style="color: red">{{ session('tb') }}</p>
                @endif
                <input type="submit" class="btn " value="Sửa thông tin">
            </div>





        </form>
    </div>
@endsection
