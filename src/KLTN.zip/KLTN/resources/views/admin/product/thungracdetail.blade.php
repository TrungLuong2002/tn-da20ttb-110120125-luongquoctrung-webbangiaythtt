@extends('admin.layout.main')
@section('title', 'quan li san pham')
@section('content')
    <div class="container">

        <h1>Thùng rác chi tiết sản phẩm</h1>
        <table id="tb-product-detail">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã Sản Phẩm</th>
                   
                    <th>Size</th>
                    <th>Màu sắc</th>
                    <th>Số lượng</th>

                </tr>
            </thead>
            <tbody>
                @php
                    $stt = 0;
                @endphp
                @if (isset($rac))
                    @foreach ($rac as $item)
                        @php
                            $stt++;
                        @endphp
                        <tr>
                            <td>{{ $stt }}</td>
                            <td>{{ $item->Ma_SP }}</td>
                          
                            <td>{{ $item->Kich_Thuoc }}</td>
                            <td>{{ $item->Ten_Mau }}</td>
                            <td>{{ $item->So_Luong }}</td>
                            <td>
                                <a class="btn-sua" href="{{route('admin.product.khoiphucdetail',['id'=>$item->Chi_Tiet_SP_id])}}">Khôi phục</a>
                                <a class="btn-xoa" href="{{route('admin.product.xoavvdetail',['id'=>$item->Chi_Tiet_SP_id])}}"> Xoá</a>
                               
                            </td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>
@endsection
