@extends('admin.layout.main')
@section('title', 'quan li size')
@section('content')
    <div class="container">
        <div id="wp-color">
            <div id="showcolor">

                <h1>Danh sách kích thước sản phẩm</h1>
                <table id="tb-color">
                    <thead>
                        <tr>
                            <th>STT</th>

                            <th>Kích thước</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $stt = 0;
                        @endphp
                        @if ($size)
                            @foreach ($size as $item)
                                @php
                                    $stt++;
                                @endphp
                                <tr>
                                    <td id="stt">{{ $stt }}</td>
                                    <td id="ma_sp">{{ $item->Kich_Thuoc }}</td>

                                    <td>
                                        <a class="btn-xoa"
                                            href="{{ route('admin.product.deletesize', ['id' => $item->Kich_Thuoc_id]) }}"><i
                                                class="fa-solid fa-trash"></i></a>
                                    </td>

                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div id="createcolor">
                <h1>Thêm kích thước mới</h1>
                <form id="frm-themSP" method="POST" action="{{ route('admin.product.createsize') }}"
                    enctype="multipart/form-data">
                    @csrf
                    <div id="wp-form">

                        <div class="form-group">
                            <label for="kich_thuoc">Kích thước</label>
                            <input type="text" class="form-control" id="mau" name="kich_thuoc">
                            @error('kich_thuoc')
                                <p style="color: red">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    @if (session('tb'))
                        <p style="color: red">{{ session('tb') }}</p>
                    @endif
                    <input type="submit" class="btn " value="Thêm">


                </form>
            </div>
            <div id="updatecolor">
                <h1>Sửa</h1>
                <form id="frm-themSP" method="POST" action="{{ route('admin.product.updatesize') }}"
                    enctype="multipart/form-data">
                    @csrf
                    <div id="wp-form">
                        <div class="form-group">
                            <label for="kich_thuoc_cu">Kích thước cũ</label>
                            <select name="kich_thuoc_cu" class="form-control" id="mau_cu">
                                <option value="">----</option>
                                @if ($size)
                                    @foreach ($size as $item)
                                        <option value="{{ $item->Kich_Thuoc_id }}">{{ $item->Kich_Thuoc }}</option>
                                    @endforeach
                                @endif
                            </select>

                        </div>
                        <div class="form-group">
                            <label for="mau">Kích thước mới</label>
                            <input type="text" class="form-control" id="mau" name="kich_thuoc_moi">
                        </div>



                    </div>
                    @if (session('tb2'))
                        <p style="color: red">{{ session('tb2') }}</p>
                    @endif
                    @error('kich_thuoc_cu')
                    <p style="color: red">{{ $message }}</p>
                    @enderror
                    @error('kich_thuoc_moi')
                    <p style="color: red">{{ $message }}</p>
                    @enderror
                    <input type="submit" class="btn " value="Sửa">

                </form>
            </div>
        </div>
    </div>
@endsection
