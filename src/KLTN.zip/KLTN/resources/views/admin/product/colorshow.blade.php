@extends('admin.layout.main')
@section('title', 'quan li color')
@section('content')
    <div class="container">
        <div id="wp-color">
            <div id="showcolor">

                <h1>Danh sách màu sản phẩm</h1>
                <table id="tb-color">
                    <thead>
                        <tr>
                            <th>STT</th>

                            <th>Tên màu</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $stt = 0;
                        @endphp
                        @if ($color)
                            @foreach ($color as $item)
                                @php
                                    $stt++;
                                @endphp
                                <tr>
                                    <td id="stt">{{ $stt }}</td>
                                    <td id="ma_sp">{{ $item->Ten_Mau }}</td>

                                    <td>
                                        <a class="btn-xoa"
                                            href="{{ route('admin.product.deletecolor', ['id' => $item->Mau_id]) }}"><i
                                                class="fa-solid fa-trash"></i></a>
                                    </td>

                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div id="createcolor">
                <h1>Thêm màu mới</h1>
                <form id="frm-themSP" method="POST" action="{{ route('admin.product.createcolor') }}"
                    enctype="multipart/form-data">
                    @csrf
                    <div id="wp-form">

                        <div class="form-group">
                            <label for="mau">Tên màu</label>
                            <input type="text" class="form-control" id="mau" name="ten_mau">
                            @error('ten_mau')
                                <p style="color: red">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    @if (session('tb'))
                        <p style="color: red">{{ session('tb') }}</p>
                    @endif
                    <input type="submit" class="btn " value="Thêm">


                </form>
            </div>
            <div id="updatecolor">
                <h1>Sửa</h1>
                <form id="frm-themSP" method="POST" action="{{ route('admin.product.updatecolor') }}"
                    enctype="multipart/form-data">
                    @csrf
                    <div id="wp-form">
                        <div class="form-group">
                            <label for="mau_cu">Màu cũ</label>
                            <select name="mau_cu" class="form-control" id="mau_cu">
                                <option value="">----</option>
                                @if ($color)
                                    @foreach ($color as $item)
                                        <option value="{{ $item->Mau_id }}">{{ $item->Ten_Mau }}</option>
                                    @endforeach
                                @endif
                            </select>

                        </div>
                        <div class="form-group">
                            <label for="mau">Tên màu mới</label>
                            <input type="text" class="form-control" id="mau" name="mau_moi">
                        </div>



                    </div>
                    @if (session('tb2'))
                        <p style="color: red">{{ session('tb2') }}</p>
                    @endif
                    @error('mau_cu')
                    <p style="color: red">{{ $message }}</p>
                    @enderror
                    @error('mau_moi')
                    <p style="color: red">{{ $message }}</p>
                    @enderror
                    <input type="submit" class="btn " value="Sửa">

                </form>
            </div>
        </div>
    </div>
@endsection
