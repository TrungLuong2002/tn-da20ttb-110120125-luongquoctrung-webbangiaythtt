@extends('admin.layout.main')
@section('title', 'quan li san pham')
@section('content')
    <div class="container">
        <style>
            #frm-serch-sp {
                float: right;
            }

            #frm-serch-sp #timkiem {
                padding: 5px;

            }

            #frm-serch-sp #btn-tim {

                padding: 7px;
                border: none;

            }
        </style>
        <h1>Danh sách sản phẩm hết</h1>
        <table id="tb-product">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã Sản Phẩm</th>
                    <th>Màu</th>
                    <th>Kích thước</th>

                </tr>
            </thead>
            <tbody>
                @php
                    $stt = 0;
                @endphp
                @if ($product_het)
                    @foreach ($product_het as $item)
                        @php
                            $stt++;
                        @endphp
                        <tr>
                            <td>{{ $stt }}</td>
                            <td>{{ $item->Ma_SP }}</td>
                            <td>{{ $item->Ten_Mau }}</td>
                            <td>{{ $item->Kich_Thuoc }}</td>
                            <td>
                                <form action="{{ route('admin.product.capnhatsoluong', ['id' => $item->Chi_Tiet_SP_id]) }}" method="post"
                                    class="frm-traloi">
                                    @csrf

                                    <input type="text" name="soluong">
                                    <input type="submit" value="Cập nhật">
                                </form>
                            </td>


                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>
@endsection
