@extends('admin.layout.main')
@section('title','THONGKE')
@section('content')
<div id="wp-thongke">
   
 
    <h1>Doanh thu</h1>
    <form action="">
        @csrf
        <select name="tuy-chon" id="tuy-chon">
            <option value="">------</option>
            <option value="7ngay">7 ngày</option>
            <option value="thang-truoc">Tháng trước</option>
        </select>
    </form>
    <div id="myfirstchart" style="height: 250px;"></div>
</div>
   
@endsection