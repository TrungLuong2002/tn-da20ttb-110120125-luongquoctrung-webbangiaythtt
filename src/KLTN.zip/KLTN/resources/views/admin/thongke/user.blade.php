<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <p>thang trc: {{   $tong_thang_truoc_count}}</p>
    <p>thang nay: {{ $tong_thang_nay_count}}</p>
    <p>truy cap: {{ $user_truy_cap_count}}</p>
</body>
</html>