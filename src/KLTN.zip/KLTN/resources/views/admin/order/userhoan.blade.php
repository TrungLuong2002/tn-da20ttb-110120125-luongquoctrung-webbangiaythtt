@extends('admin.layout.main')
@section('title', 'quan li user')
@section('content')
    <div class="container">

        <h1>Danh sách người dùng hoàn đơn</h1>

        <table id="tb-user">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>ID</th>
                    <th>Tên</th>
                    <th>Số Điện Thoại</th>
                    <th>Email</th>
                  
                    <th>Số đơn hoàn</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $stt = 0;
                @endphp
                @if ($user)
                    @foreach ($user as $item)
                        @php
                            $stt++;
                        @endphp
                        <tr>
                            <td>{{ $stt }}</td>
                            <td>{{ $item->User_id }}</td>
                            <td>{{ $item->FullName }}</td>
                            <td>{{ $item->SDT }}</td>
                            <td>{{ $item->Email }}</td>
                            <td>{{ $item->solan }}</td>
                            <td>
                                <a class="btn-xoa" href="{{route('admin.user.delete',['id'=> $item->User_id])}}"><i class="fa-solid fa-trash"></i></a>
                            </td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
    </div>
@endsection
