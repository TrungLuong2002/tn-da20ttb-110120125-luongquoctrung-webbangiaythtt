@extends('admin.layout.main')
@section('title', 'quan li san pham')
@section('content')
    <div class="container">

        <h1>Danh sách đơn hàng</h1>
       <a href="{{route('admin.order.showhoandon')}}" style="text-decoration: none;   margin-bottom: 15px; display:block"> Danh sách người dùng từ chối nhận hàng</a>
        <table id="tb-order">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Tên Khách Hàng</th>
                    <th>Tổng tiền</th>
                    <th>Phương Thức Thanh Toán</th>
                    <th>Ghi chú</th>
                    <th>Trạng thái</th>
                    <th>Ngày đặt</th>
                    <th>Địa chỉ</th>
                    <th>SDT</th>

                </tr>
            </thead>
            <tbody>
                @php
                    $stt = 0;
                @endphp
                @if ($order)
                    @foreach ($order as $item)
                        @php
                            $stt++;
                        @endphp
                        <tr>
                            <td>{{ $stt }}</td>
                            <td>{{ $item->User->FullName }}</td>
                            <td>{{ $item->Tong_Tien }}đ</td>
                            <td>{{ $item->Phuong_Thuc->Ten_Phuong_Thuc }}</td>
                            <td>{{ $item->Ghi_Chu }}</td>
                            <td>{{ $item->Trang_Thai }}</td>
                            <td>{{ $item->Ngay_Dat }}</td>
                            <td>{{ $item->Dia_Chi }}</td>
                            <td>{{ $item->User->SDT }}</td>
                            <td>
                                @if($item->Trang_Thai=="Đang xử lí")
                                <a href="{{ route('sendmail.checkout', ['id' => $item->Don_Hang_id, 'mail' => $item->User->Email]) }}" class="btn-duyet">Duyệt <i class="fa-solid fa-check"></i></a>
                                <a href="{{ route('sendmail.huydon', ['id' => $item->Don_Hang_id, 'mail' => $item->User->Email]) }}" class="btn-huy">Huỷ <i class="fa-solid fa-x"></i></a>
                                @endif
                                @if($item->Trang_Thai=="Đã Thanh Toán" || $item->Trang_Thai=="Đã duyệt")
                                <a href="{{ route('admin.order.hoandon', ['id' => $item->Don_Hang_id]) }}" class="btn-duyet" style="background-color: yellow; color:black; border:1px solid black;">Hoàn Đơn </a>
                                @endif
                            </td>
                            <td>
                                <a class="btn-chitiet"
                                    href="{{ route('admin.order.orderdetail', ['id' => $item->Don_Hang_id]) }}">Xem chi tiết</a>
                            </td>
                        </tr>
                    @endforeach
                @endif


            </tbody>
        </table>
    </div>
   
@endsection
