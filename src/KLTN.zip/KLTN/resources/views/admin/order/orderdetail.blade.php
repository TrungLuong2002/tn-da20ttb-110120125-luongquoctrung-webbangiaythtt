@extends('admin.layout.main')
@section('title','quan li chi tiet don')
@section('content')
<div class="container">

    <h1>Danh sách chi tiết đơn hàng</h1>
    <table id="tb-order">
        <thead>
            <tr>
                <th>STT</th>
                <th>Tên sản phẩm</th>
                <th>Màu</th>
                <th>Kích thước</th>
                <th>Số lượng</th>
                <th>Tổng</th>
                
            </tr>
        </thead>
        <tbody>
           @php
               $stt=0;
           @endphp
           @if ($order)
           @foreach ($order->orderDetails as $item)
           @php
               $stt++;
           @endphp
           <tr>
            <td>{{$stt}}</td>
            <td>{{$item->productdetail->product->Ten_SP}}</td>
            <td>{{$item->productdetail->Ten_Mau}}</td>
            <td>{{$item->productdetail->Kich_Thuoc}}</td>
            <td>{{$item->So_Luong}}</td>
            <td>{{ number_format($item->Tong_Tien, 0, ',', '.') }}đ</td>
        </tr>
           @endforeach
           @endif
            
            
        </tbody>
    </table>
</div>
@endsection
