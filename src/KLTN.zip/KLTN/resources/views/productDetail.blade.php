@extends('layout.app')
@section('title', 'Trang chi tiet')
@section('content')
    <style>
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
            display: none;
        }

        .centered-form {
            width: 300px;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            z-index: 1000;
            display: none;

            flex-direction: column;
            align-items: center;
            max-width: 400px;
            margin: 0 auto;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .centered-form h3 {
            text-align: center;
            margin-bottom: 20px;
            color: #f50c0c;
        }

        .centered-form label {
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .centered-form select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 15px;
            background-color: #fff;
            font-size: 16px;
        }

        .form-phu {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-phu .btn-add {
            font-size: 12px;
            display: block;
            border: 1px solid #fd0101;
            color: #fd0101;
            padding: 5px 5px;
            margin-right: 5px;
            width: 100px;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
            margin: 0 auto;
        }

        .form-phu .btn-add:hover {

            background-color: #fd0101;
            color: #f2f2f2;

        }

        .form-phu select {
            background-color: #f2f2f2;
            color: #333;
        }

        /* -------------- */
        .centered-form2 {
            width: 300px;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            z-index: 1000;
            display: none;

            flex-direction: column;
            align-items: center;
            max-width: 400px;
            margin: 0 auto;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .centered-form2 h3 {
            text-align: center;
            margin-bottom: 20px;
            color: #f50c0c;
        }

        .centered-form2 label {
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .centered-form2 select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 15px;
            background-color: #fff;
            font-size: 16px;
        }

        .form-phu2 {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-phu2 .btn-add {
            font-size: 12px;
            display: block;
            border: 1px solid #fd0101;
            color: #fd0101;
            padding: 5px 5px;
            margin-right: 5px;
            width: 100px;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
            margin: 0 auto;
        }

        .form-phu2 .btn-add:hover {

            background-color: #fd0101;
            color: #f2f2f2;

        }

        .form-phu2 select {
            background-color: #f2f2f2;
            color: #333;
        }

        /* ------------ */
        .traloi {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 13px;
            font-style: italic;
        }
    </style>
    <div class="overlay" id="overlay"></div>
    @if (isset($productDetail))

        <div id="product-detail-wp">
            <div id="product-images">
                <div id="images">
                    <img class="thumb" src="{{ asset($productDetail->Img) }}" alt="">
                </div>
                <ul id="list-img">
                    @if (isset($img))
                        @foreach ($img as $item)
                            <li>
                                <a href="" title="" class="thumb">
                                    <img src="{{ asset($item->Link) }}">
                                </a>

                            </li>
                        @endforeach
                    @endif

                </ul>
            </div>

    @endif
    @if (isset($productDetail))

        <div id="product-detail">

            <h3 class="title">{{ $productDetail->Ten_SP }}</h3>
            @for ($i = 1; $i <= 5; $i++)
                @if ($i <= $tbsao)
                    <span class="user-rating" style="color: #f5b301;"">&#9733;</span>
                @else
                    <span class="user-rating" style="color: #ccc;">&#9733;</span>
                @endif
            @endfor

            <br><span id="price">{{ number_format($productDetail->Gia, 0, ',', '.') }}đ</span>
            <form action="{{ route('addcart', ['Ma_SP' => $productDetail->Ma_SP]) }}" method="POST" id="frm-thuoctinh">
                @csrf
                <label id="txt-size" for="size">Size:</label>
                <div class="radio-group" id="size">
                    @if (isset($size))
                        @foreach ($size as $kichThuoc)
                            <input type="radio" id="size{{ $kichThuoc }}" name="size" value="{{ $kichThuoc }}">
                            <label for="size{{ $kichThuoc }}">{{ $kichThuoc }}</label>
                        @endforeach
                    @endif
                    @error('size')
                        <p style="color: red">{{ $message }}</p>
                    @enderror
                </div>

                <label id="txt-color" for="color">Màu:</label>
                <div class="radio-group" id="color">
                    @if (isset($color))
                        @foreach ($color as $color)
                            <input type="radio" id="color{{ $color }}" name="color"
                                value="{{ $color }}">
                            <label for="color{{ $color }}">{{ $color }}</label>
                        @endforeach
                    @endif
                    @error('color')
                        <p style="color: red">{{ $message }}</p>
                    @enderror
                </div>

                <input type="submit" id="btn-them" name="btn-them" value="THÊM VÀO GIỎ HÀNG">
            </form>


        </div>
        </div>

    @endif
    <div id="product-detail-end">
        <div id="mota">
            <h3 class="title">MÔ TẢ SẢN PHẨM</h3>
            @if (isset($productDetail))
                <p>{{ $productDetail->Mo_Ta }}</p>
            @endif
        </div>
        <div id="related-product">
            <h3 class="title">SP LIÊN QUAN</h3>
            @if (isset($product_lq))
                <ul class="list-product">
                    @php $count = 0; @endphp
                    @foreach ($product_lq as $item)
                        @if ($count < 4)
                            <li>
                                <a href="{{ route('productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP]) }}"
                                    title="" class="thumb">
                                    <img src="{{ asset($item->Img) }}">
                                </a>
                                <a href="{{ route('productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP]) }}"
                                    title="" class="product-name">{{ $item->Ten_SP }}</a>
                                <div class="price">
                                    <span class="new">{{ number_format($item->Gia, 0, ',', '.') }}đ</span>
                                    @if ($item->Gia_cu != null)
                                        <span class="old">{{ number_format($item->Gia_cu, 0, ',', '.') }}đ</span>
                                    @endif
                                </div>
                                <div class="task">
                                    <a href="javascript:void(0)" title="Thêm giỏ hàng" class="add-cart"
                                        data-id="{{ $item->San_Pham_id }}" data-masp="{{ $item->Ma_SP }}">Thêm giỏ
                                        hàng</a>
                                    <a href="javascript:void(0)" title="Thêm giỏ hàng" data-id="{{ $item->San_Pham_id }}"
                                        data-masp="{{ $item->Ma_SP }}" class="buy-now">Mua
                                        ngay</a>

                                </div>
                                <div class="centered-form form-phu">
                                    <form action="{{ route('addcart', ['Ma_SP' => $item->Ma_SP]) }}" method="post">
                                        @csrf
                                        <h3>Chọn tùy chọn</h3>
                                        <label for="color">Màu sắc</label>
                                        <select name="color" class="color-select" required>
                                            <option value=""></option>
                                        </select>
                                        <label for="size">Kích cỡ</label>
                                        <select name="size" class="size-select" required>
                                            <option value=""></option>
                                        </select>
                                        <input type="submit" class="btn-add" value="Thêm giỏ hàng">
                                    </form>

                                </div>
                                <div class="centered-form2 form-phu2">
                                    <form action="{{ route('addcartbuynow', ['Ma_SP' => $item->Ma_SP]) }}" method="post">
                                        @csrf
                                        <h3>Chọn tùy chọn</h3>
                                        <label for="color">Màu sắc</label>
                                        <select name="color" class="color-select" required>
                                            <option value=""></option>
                                        </select>
                                        <label for="size">Kích cỡ</label>
                                        <select name="size" class="size-select" required>
                                            <option value=""></option>
                                        </select>
                                        <input type="submit" class="btn-add" value="Mua">
                                    </form>

                                </div>
                            </li>
                            @php $count++; @endphp
                        @endif
                    @endforeach
                </ul>
            @endif


        </div>
        <div id="comment">
            <div>
                <div id="tab-rating" class="tab active">Đánh giá</div>
                <div id="tab-comment" class="tab">Bình luận</div>
            </div>
            <div id="content-rating" class="tab-content active">
                <h2>Đánh giá sản phẩm</h2>
                <ul class="list-comment">
                    @if ($danhgia)
                        @foreach ($danhgia as $item)
                            <li>
                                @php
                                    $rating = $item->So_Sao;
                                @endphp
                                <span class="user">{{ $item->User->FullName }}</span>
                                @for ($i = 1; $i <= 5; $i++)
                                    @if ($i <= $rating)
                                        <span class="user-rating">&#9733;</span>
                                    @else
                                        <span class="user-rating" style="color: #ccc;">&#9733;</span>
                                    @endif
                                @endfor

                                <p>{{ $item->Noi_Dung }}</p>
                            </li>
                        @endforeach

                    @endif

                </ul>



            </div>
            <div id="content-comment" class="tab-content">
                <ul class="list-comment">
                    @if ($comment)
                        @foreach ($comment as $cmt)
                            <li>
                                <span class="user">{{ $cmt->Ten_User }}</span>
                                <p>{{ $cmt->Binh_Luan }}</p>
                                @if ($cmt->Tra_Loi != null)
                                    <p><strong> Trả lời:{{ $cmt->Ten_User }}</strong>{{ $cmt->Tra_Loi }}</p>
                                @endif
                            </li>
                        @endforeach
                    @endif


                </ul>
                <form action="{{ route('comment', ['Ma_SP' => $productDetail->Ma_SP]) }}" method="POST">
                    @csrf
                    <h2>Bình luận</h2>
                    <div>
                        <label for="name">Tên:</label>
                        <input type="text" name="name" required><br>
                        <label for="comment">Bình luận của bạn:</label><br>
                        <textarea id="comment" name="comment" rows="4" cols="50" required></textarea>
                    </div>
                    <button class="btn-cmt" type="submit">Gửi bình luận</button>
                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#list-img').on('click', '.thumb', function(e) {
                e.preventDefault();
                var imgSrc = $(this).find('img').attr('src');
                $('#images img').attr('src', imgSrc);
            });
            $('#tab-rating').click(function() {
                $('#tab-rating').addClass('active');
                $('#tab-comment').removeClass('active');
                $('#content-rating').addClass('active');
                $('#content-comment').removeClass('active');
            });

            $('#tab-comment').click(function() {
                $('#tab-comment').addClass('active');
                $('#tab-rating').removeClass('active');
                $('#content-comment').addClass('active');
                $('#content-rating').removeClass('active');
            });

            // ------------------
            $('.add-cart').click(function(e) {
                e.preventDefault();
                var productId = $(this).data('id');
                var productMaSP = $(this).data('masp');
                var overlay = $('#overlay');
                var centeredForm = $(this).closest('li').find('.centered-form');
                var colorSelect = centeredForm.find('.color-select');
                var sizeSelect = centeredForm.find('.size-select');
                overlay.fadeIn();
                centeredForm.fadeIn();
                $.ajax({
                    url: "{{ route('user.getcolor') }}",
                    method: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        id: productId,
                        Ma_SP: productMaSP
                    },
                    success: function(response) {
                        if (response.success) {
                            var colorOptions = '<option value="">Chọn màu</option>';
                            $.each(response.colors, function(index, color) {
                                colorOptions += '<option value="' + color + '">' +
                                    color + '</option>';
                            });
                            colorSelect.html(colorOptions);
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error fetching colors: ' + xhr.responseText);
                    }
                });
                centeredForm.on('change', '.color-select', function() {
                    var selectedColor = $(this).val();
                    $.ajax({
                        url: "{{ route('user.getsize') }}",
                        method: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}',
                            color: selectedColor,
                            Ma_SP: productMaSP
                        },
                        success: function(response) {
                            if (response.success) {
                                var sizeOptions =
                                    '<option value="">Chọn kích cỡ</option>';
                                $.each(response.sizes, function(index, size) {
                                    sizeOptions += '<option value="' + size +
                                        '">' + size + '</option>';
                                });
                                sizeSelect.html(sizeOptions);
                            } else {
                                alert(response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('Error fetching sizes: ' + xhr.responseText);
                        }
                    });
                });
            });

            $('.buy-now').click(function(e) {
                e.preventDefault();
                var productId = $(this).data('id');
                var productMaSP = $(this).data('masp');
                var overlay = $('#overlay');
                var centeredForm = $(this).closest('li').find('.centered-form2');
                var colorSelect = centeredForm.find('.color-select');
                var sizeSelect = centeredForm.find('.size-select');
                overlay.fadeIn();
                centeredForm.fadeIn();
                $.ajax({
                    url: "{{ route('user.getcolor') }}",
                    method: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        id: productId,
                        Ma_SP: productMaSP
                    },
                    success: function(response) {
                        if (response.success) {
                            var colorOptions = '<option value="">Chọn màu</option>';
                            $.each(response.colors, function(index, color) {
                                colorOptions += '<option value="' + color + '">' +
                                    color + '</option>';
                            });
                            colorSelect.html(colorOptions);
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error fetching colors: ' + xhr.responseText);
                    }
                });
                centeredForm.on('change', '.color-select', function() {
                    var selectedColor = $(this).val();
                    $.ajax({
                        url: "{{ route('user.getsize') }}",
                        method: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}',
                            color: selectedColor,
                            Ma_SP: productMaSP
                        },
                        success: function(response) {
                            if (response.success) {
                                var sizeOptions =
                                    '<option value="">Chọn kích cỡ</option>';
                                $.each(response.sizes, function(index, size) {
                                    sizeOptions += '<option value="' + size +
                                        '">' + size + '</option>';
                                });
                                sizeSelect.html(sizeOptions);
                            } else {
                                alert(response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            alert('Error fetching sizes: ' + xhr.responseText);
                        }
                    });
                });
            });

            $('#overlay').click(function() {
                $(this).fadeOut();
                $('.centered-form').fadeOut();
                $('.centered-form2').fadeOut();
            });
        });
    </script>
@endsection
