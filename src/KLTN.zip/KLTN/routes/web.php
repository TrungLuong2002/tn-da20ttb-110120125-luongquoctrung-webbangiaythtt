<?php

use App\Http\Controllers\AdminCommentController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MailController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\UserproductController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminOptionController;
use App\Http\Controllers\AdminOrderController;
use App\Http\Controllers\AdminProductController;
use App\Http\Controllers\AdminUserController;
use App\Http\Controllers\AdminThongKeController;
use App\Http\Controllers\PaypalController;
use App\Http\Controllers\XuLidiachiController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// ----------------USER------------
Route::get('/', [ProductController::class, 'show'])->name('index');
Route::get('/product/{action}/{name}', [ProductController::class, 'showAll'])->name('productAll');
Route::post('/product/loc/{name}', [ProductController::class, 'loc'])->name('loc');
Route::get('/productDetail/{id}/{Ma_SP}', [ProductController::class, 'showDetail'])->name('productDetail');
Route::post('/product/search', [ProductController::class, 'search'])->name('search');

Route::get('/cart/show',[CartController::class,'show'])->name('show.cart');
Route::post('/addcart/{Ma_SP}', [CartController::class, 'addcart'])->name('addcart');
Route::get('/cart/remove/{rowId}',[CartController::class, 'remove'])->name('remove.cart');
Route::get('/cart/destroy', [CartController::class, 'destroy'])->name('destroy.cart');
Route::post('/cart/update', [CartController::class, 'update'])->name('update.cart');
Route::get('/cart/checkout',[CartController::class,'checkout'])->name('checkoutcart');

Route::get('/login', function () {
    return view('user.login'); 
})->name('login');

Route::get('/register', function () {
    return view('user.register'); 
})->name('register');

Route::get('/laylaimk', function () {
    return view('user.quenmk'); 
})->name('quenmk');

Route::post('/user/login',[UserController::class,'login'])->name('User.login');
Route::get('/user/logout',[UserController::class,'logout'])->name('User.logout');
Route::post('/user/dangki',[UserController::class,'dangki'])->name('User.dangki');

Route::get('/user', [UserproductController::class, 'show'])->name('Trangchu');
Route::get('/user/product/{action}/{name}', [UserProductController::class, 'showAll'])->name('user.productAll');
Route::post('/user/product/loc/{name}', [UserProductController::class, 'loc'])->name('user.loc');
Route::get('/user/productDetail/{id}/{Ma_SP}', [UserproductController::class, 'showDetail'])->name('User.productDetail');
Route::post('/user/product/search', [UserproductController::class, 'search'])->name('user.search');

Route::post('/user/dathang',[CartController::class,'dathang'])->name('dat-hang');
Route::post('/user/dathang/momo',[CartController::class,'momo'])->name('momo');
Route::post('/user/dathang/vnpay',[CartController::class,'vnpay'])->name('vnpay');
Route::post('/user/dathang/onepay',[CartController::class,'onepay'])->name('onepay');
Route::get('/user/momo/xuli',[CartController::class,'momoxuli'])->name('momo.xuli');

Route::get('user/donhang/huy/{id}',[UserController::class,'huydon'])->name('user.huydon');

Route::get('user/tt',[UserController::class,'showtt'])->name('user.tt');
Route::post('user/update/tt',[UserController::class,'update_tt'])->name('user.updatett');
Route::get('user/doipass',[UserController::class,'doipass'])->name('user.doipass');
Route::post('user/doipass',[UserController::class,'doimk'])->name('user.doimk');
Route::get('user/order',[UserController::class,'order'])->name('user.order');
Route::get('user/order/huy',[UserController::class,'orderhuy'])->name('user.order.huy');
Route::get('user/order/duyet',[UserController::class,'orderduyet'])->name('user.order.duyet');
Route::get('user/order/detail/{id}',[UserController::class,'orderdetail'])->name('user.order.detail');
Route::get('/user/huyen/{tinh_id}', [XuLidiachiController::class, 'getHuyen'])->name('user.gethuyen');
Route::get('/user/xa/{huyen_id}', [XuLidiachiController::class, 'getXa'])->name('user.getxa');

Route::post('user/product/danhgia/{id_user}/{Ma_SP}',[UserproductController::class,'danhgia'])->name(('user.danhgia'));
Route::post('user/product/comment/{Ma_SP}',[UserproductController::class,'comment'])->name(('user.comment'));
Route::post('product/comment/{Ma_SP}',[ProductController::class,'comment'])->name(('comment'));
// ------------ADMIN-----------
Route::get('/admin', function () {
    return view('admin.login'); 
})->name('admin');
Route::post('/admin/login', [AdminController::class, 'login'])->name('admin.login');

Route::get('/admin/index', [AdminController::class, 'show'])->name('admin.index');

Route::get('/admin/user',[AdminUserController::class,'show'])->name('admin.user');
Route::get('/admin/user/delete/{id}',[AdminUserController::class,'deleteuser'])->name('admin.user.delete');

Route::get('/admin/product',[AdminProductController::class,'show'])->name('admin.product');
Route::get('/admin/product/detail/{Ma_SP}',[AdminProductController::class,'showdetail'])->name('admin.product.detail');

Route::post('/admin/product/search',[AdminProductController::class,'searchproduct'])->name('admin.product.search');

Route::get('/admin/product/createshow',[AdminProductController::class,'showcreate'])->name('admin.product.create');
Route::post('/admin/product/createproduct',[AdminProductController::class,'createproduct'])->name('admin.product.createproduct');
Route::get('/admin/product/createdetail',[AdminProductController::class,'showcreatedetail'])->name('admin.product.createdetail');
Route::post('/admin/product/createdetailproduct',[AdminProductController::class,'createdetailproduct'])->name('admin.product.createdetailproduct');
Route::get('/admin/product/showimage',[AdminOptionController::class,'showimage'])->name('admin.product.showimage');

Route::get('/admin/product/delete/{id}',[AdminProductController::class,'deleteproduct'])->name('admin.product.delete');
Route::get('/admin/product/thungrac',[AdminProductController::class,'thungrac'])->name('admin.product.rac');
Route::get('/admin/product/thungrac/khoiphuc/{id}',[AdminProductController::class,'khoiphuc'])->name('admin.product.khoiphuc');
Route::get('/admin/product/thungrac/xoa/{id}',[AdminProductController::class,'xoavv'])->name('admin.product.xoavv');

Route::get('/admin/product/updateshow/{id}',[AdminProductController::class,'updateshow'])->name('admin.product.updateshow');
Route::post('/admin/product/update/{id}',[AdminProductController::class,'updateproduct'])->name('admin.product.updateproduct');

Route::get('/admin/product/deletedetail/{id}',[AdminProductController::class,'deleteproductdetail'])->name('admin.product.deletedetail');
Route::get('/admin/product/thungracdetail',[AdminProductController::class,'thungracdetail'])->name('admin.product.racdetail');
Route::get('/admin/product/thungrac/khoiphucdetail/{id}',[AdminProductController::class,'khoiphucdetail'])->name('admin.product.khoiphucdetail');
Route::get('/admin/product/thungrac/xoadetail/{id}',[AdminProductController::class,'xoavvdetail'])->name('admin.product.xoavvdetail');

Route::get('/admin/product/updatedetailshow/{id}',[AdminProductController::class,'updatedetailshow'])->name('admin.product.updatedetailshow');
Route::post('/admin/product/updatedetail/{id}',[AdminProductController::class,'updateproductdetail'])->name('admin.product.updateproductdetail');

Route::get('/admin/product/showcreateimage',[AdminOptionController::class,'showcreateimage'])->name('admin.product.showcreateimage');
Route::post('/admin/product/createimage',[AdminOptionController::class,'createimage'])->name('admin.product.createimage');

Route::get('/admin/product/deleteimage_item/{id}',[AdminOptionController::class,'deleteimage_item'])->name('admin.product.deleteimage_item');
Route::get('/admin/product/deleteimage/{Ma_SP}',[AdminOptionController::class,'deleteimage'])->name('admin.product.deleteimage');

Route::get('/admin/product/showcolor',[AdminOptionController::class,'showcolor'])->name('admin.product.showcrolor');
Route::post('/admin/product/createcolor',[AdminOptionController::class,'createcolor'])->name('admin.product.createcolor');
Route::get('/admin/product/deletecolor/{id}',[AdminOptionController::class,'deletecolor'])->name('admin.product.deletecolor');
Route::post('/admin/product/updatecolor',[AdminOptionController::class,'updatecolor'])->name('admin.product.updatecolor');

Route::get('/admin/product/showsize',[AdminOptionController::class,'showsize'])->name('admin.product.showsize');
Route::post('/admin/product/createsize',[AdminOptionController::class,'createsize'])->name('admin.product.createsize');
Route::get('/admin/product/deletesize/{id}',[AdminOptionController::class,'deletesize'])->name('admin.product.deletesize');
Route::post('/admin/product/updatesize',[AdminOptionController::class,'updatesize'])->name('admin.product.updatesize');

Route::get('/admin/order',[AdminOrderController::class,'show'])->name('admin.order');
Route::get('/admin/order/orderddetail/{id}',[AdminOrderController::class,'showdetail'])->name('admin.order.orderdetail');
Route::get('/admin/order/hoandon/{id}',[AdminOrderController::class,'hoandon'])->name('admin.order.hoandon');
Route::get('/admin/order/showhoandon',[AdminOrderController::class,'showhoandon'])->name('admin.order.showhoandon');

Route::get('/admin/slider',[AdminOptionController::class,'showslider'])->name('admin.slider');
Route::get('/admin/createslidershow',[AdminOptionController::class,'createslidershow'])->name('admin.createslidershow');
Route::post('/admin/createslider',[AdminOptionController::class,'createslider'])->name('admin.createslider');
Route::get('/admin/deleteslider/{id}',[AdminOptionController::class,'deleteslider'])->name('admin.deleteslider');

Route::get('/admin/thongke',[AdminThongKeController::class,'show'])->name('admin.thongke.doanhthu');
Route::post('/admin/thongke/tinh', [AdminThongKeController::class, 'tinh'])->name('tinh');

Route::get('/admin/thongke/user',[AdminThongKeController::class,'user'])->name('admin.thongke.user');


Route::get('/mail/checkout/{id}/{mail}',[MailController::class, 'sendmail'])->name('sendmail.checkout');
Route::get('/mail/huydon/{id}/{mail}',[MailController::class, 'huydon'])->name('sendmail.huydon');
Route::post('/mail/xacnhan',[MailController::class, 'xacnhan'])->name('sendmail.xacnhan');
Route::post('/mail/check',[MailController::class, 'checkmail'])->name('sendmail.check');
Route::post('/mail/laymk',[MailController::class, 'laylaimk'])->name('sendmail.laymk');


Route::get('/test', function(){
return view('productAll');
});


Route::post('/product/getcolor', [ProductController::class, 'getcolor'])->name('getcolor');
Route::post('/product/getsize', [ProductController::class, 'getsize'])->name('getsize');

Route::post('/user/product/getcolor', [UserproductController::class, 'getcolor'])->name('user.getcolor');
Route::post('/user/product/getsize', [UserproductController::class, 'getsize'])->name('user.getsize');

Route::post('/addcart/buynow/{Ma_SP}', [CartController::class, 'addcartbuynow'])->name('addcartbuynow');

Route::get('/admin/comment/showdanhgia', [AdminCommentController::class, 'showdanhgia'])->name('admin.showdanhgia');
Route::get('/admin/comment/locdanhgia/{noidung}', [AdminCommentController::class, 'locdanhgia'])->name('admin.locdanhgia');
Route::get('/admin/comment/traloidanhgia/{id}', [AdminCommentController::class, 'traloidanhgia'])->name('admin.traloidanhgia');
Route::get('/admin/comment/deletedanhgia/{id}', [AdminCommentController::class, 'deletedanhgia'])->name('admin.deletedanhgia');

Route::get('/admin/comment/showbinhluan', [AdminCommentController::class, 'showbinhluan'])->name('admin.showbinhluan');
Route::get('/admin/comment/locbinhluan/{noidung}', [AdminCommentController::class, 'locbinhluan'])->name('admin.locbinhluan');
Route::get('/admin/comment/traloibinhluan/{id}', [AdminCommentController::class, 'traloibinhluan'])->name('admin.traloibinhluan');
Route::get('/admin/comment/deletebinhluan/{id}', [AdminCommentController::class, 'deletebinhluan'])->name('admin.deletebinhluan');

Route::get('/paypal', [PaypalController::class, 'createTransaction'])->name('createTransaction');
Route::get('laravel/php/process-transaction', [PayPalController::class, 'processTransaction'])->name('processTransaction');
Route::get('laravel/php/success-transaction', [PayPalController::class, 'successTransaction'])->name('successTransaction');
Route::get('laravel/php/cancel-transaction', [PayPalController::class, 'cancelTransaction'])->name('cancelTransaction');

Route::get('/admin/product/noibac',[AdminOptionController::class,'shownoibac'])->name('admin.product.noibac');
Route::get('/admin/product/showcreatenoibac',[AdminOptionController::class,'showcreatenoibac'])->name('admin.product.showcreatenoibac');
Route::post('/admin/product/createnoibac',[AdminOptionController::class,'createnoibac'])->name('admin.product.createnoibac');
Route::get('/admin/product/deletenoibac/{id}',[AdminOptionController::class,'deletenoibac'])->name('admin.product.deletenoibac');

Route::get('/admin/product/producthet',[AdminOptionController::class,'showproducthet'])->name('admin.product.showhet');
Route::post('/admin/product/capnhatsoluong/{id}',[AdminOptionController::class,'capnhatsoluong'])->name('admin.product.capnhatsoluong');