<?php $__env->startSection('title', 'quan li san pham'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Thùng rác chi tiết sản phẩm</h1>
        <table id="tb-product-detail">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã Sản Phẩm</th>
                   
                    <th>Size</th>
                    <th>Màu sắc</th>
                    <th>Số lượng</th>

                </tr>
            </thead>
            <tbody>
                <?php
                    $stt = 0;
                ?>
                <?php if(isset($rac)): ?>
                    <?php $__currentLoopData = $rac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $stt++;
                        ?>
                        <tr>
                            <td><?php echo e($stt); ?></td>
                            <td><?php echo e($item->Ma_SP); ?></td>
                          
                            <td><?php echo e($item->Kich_Thuoc); ?></td>
                            <td><?php echo e($item->Ten_Mau); ?></td>
                            <td><?php echo e($item->So_Luong); ?></td>
                            <td>
                                <a class="btn-sua" href="<?php echo e(route('admin.product.khoiphucdetail',['id'=>$item->Chi_Tiet_SP_id])); ?>">Khôi phục</a>
                                <a class="btn-xoa" href="<?php echo e(route('admin.product.xoavvdetail',['id'=>$item->Chi_Tiet_SP_id])); ?>"> Xoá</a>
                               
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/thungracdetail.blade.php ENDPATH**/ ?>