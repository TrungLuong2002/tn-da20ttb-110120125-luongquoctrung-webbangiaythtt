<?php $__env->startSection('title', 'quan li san pham'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Danh sách chi tiết sản phẩm</h1>
        <a href="<?php echo e(route('admin.product.createdetail')); ?>" class="btn-them">+Thêm Chi Tiết</a>
        <a href="<?php echo e(route('admin.product.racdetail')); ?>" class="btn-rac"><i class="fa-solid fa-trash-can"></i></a>
       
        <table id="tb-product-detail">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã Sản Phẩm</th>
                    <th>Tên Sản Phẩm</th>
                    <th>Size</th>
                    <th>Màu sắc</th>
                    <th>Số lượng</th>

                </tr>
            </thead>
            <tbody>
                <?php
                    $stt = 0;
                ?>
                <?php if(isset($product_detail)): ?>
                    <?php $__currentLoopData = $product_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $stt++;
                        ?>
                        <tr>
                            <td><?php echo e($stt); ?></td>
                            <td><?php echo e($item->Ma_SP); ?></td>
                            <?php if(isset($product_ten)): ?>
                            <td><?php echo e($product_ten->Ten_SP); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($item->Kich_Thuoc); ?></td>
                            <td><?php echo e($item->Ten_Mau); ?></td>
                            <td><?php echo e($item->So_Luong); ?></td>
                            <td>
                                <a class="btn-sua" href="<?php echo e(route('admin.product.updatedetailshow',['id'=>$item->Chi_Tiet_SP_id])); ?>"><i class="fa-solid fa-gear"></i></a>
                                <a class="btn-xoa" href="<?php echo e(route('admin.product.deletedetail',['id'=>$item->Chi_Tiet_SP_id])); ?>"><i class="fa-solid fa-trash"></i></a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/productdetail.blade.php ENDPATH**/ ?>