<?php $__env->startSection('title','THONGKE'); ?>
<?php $__env->startSection('content'); ?>
<div id="wp-thongke">
   
 
    <h1>Doanh thu</h1>
    <form action="">
        <?php echo csrf_field(); ?>
        <select name="tuy-chon" id="tuy-chon">
            <option value="">------</option>
            <option value="7ngay">7 ngày</option>
            <option value="thang-truoc">Tháng trước</option>
        </select>
    </form>
    <div id="myfirstchart" style="height: 250px;"></div>
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/thongke/doanhthu.blade.php ENDPATH**/ ?>