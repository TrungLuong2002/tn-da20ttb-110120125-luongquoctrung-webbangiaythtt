<?php $__env->startSection('title','Trang chu'); ?>
<?php $__env->startSection('tt-phu'); ?>
<h3 class="title">SẢN PHẨM NỔI BẬC</h3>
<ul class="list-product-phu">
    <?php if(isset($product)): ?>
    <?php $__currentLoopData = $productNB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <div class="ttp-wp">
            <a href="<?php echo e(route('productDetail', ['id' => $item->product->San_Pham_id, 'Ma_SP' => $item->product->Ma_SP])); ?>" title="" class="img-ttp">
                <img src="<?php echo e(asset($item->product->Img)); ?>">
            </a>
            <div class="tt">
                <a href="<?php echo e(route('productDetail', ['id' => $item->product->San_Pham_id, 'Ma_SP' => $item->product->Ma_SP])); ?>"  title="" class="product-name"><?php echo e($item->product->Ten_SP); ?></a>
                <div class="price">
                    <span class="new"><?php echo e($item->product->Gia); ?></span>
                    <span class="old"><?php echo e($item->product->Gia_Cu); ?></span>
                </div>


            </div>
        </div>
        <a href="<?php echo e(route('productDetail', ['id' => $item->product->San_Pham_id, 'Ma_SP' => $item->product->Ma_SP])); ?>"  class="xem">Xem</a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="slider">
    <div class="slide"><img src="<?php echo e(asset('uploads/images/img-pro-16.png')); ?>" alt="Image 1"></div>
    <div class="slide"><img src="<?php echo e(asset('uploads/images/img-pro-16.png')); ?>" alt="Image 2"></div>
    <div class="slide"><img src="<?php echo e(asset('uploads/images/img-pro-16.png')); ?>" alt="Image 3"></div>

</div>
<script>

</script>
<div id="support-wp">
    <ul id="support">
        <li>
            <div class="thumb">
                <img src="<?php echo e(asset('uploads/images/icon-1.png')); ?>">
            </div>
            <h3 class="title">Miễn phí vận chuyển</h3>
            <p class="desc">Tới tận tay khách hàng</p>
        </li>
        <li>
            <div class="thumb">
                <img src="<?php echo e(asset('uploads/images/icon-2.png')); ?>">
            </div>
            <h3 class="title">Tư vấn 24/7</h3>
            <p class="desc">09999999</p>
        </li>
        <li>
            <div class="thumb">
                <img src="<?php echo e(asset('uploads/images/icon-3.png')); ?>">
            </div>
            <h3 class="title">Tiết kiệm hơn</h3>
            <p class="desc">Với nhiều ưu đãi cực lớn</p>
        </li>
        <li>
            <div class="thumb">
                <img src="<?php echo e(asset('uploads/images/icon-4.png')); ?>">
            </div>
            <h3 class="title">Thanh toán nhanh</h3>
            <p class="desc">Hỗ trợ nhiều hình thức</p>
        </li>
        <li>
            <div class="thumb">
                <img src="<?php echo e(asset('uploads/images/icon-5.png')); ?>">
            </div>
            <h3 class="title">Đặt hàng online</h3>
            <p class="desc">Thao tác đơn giản</p>
        </li>
    </ul>
</div>
<div class="product">
    <div class="section-head">
        <h3 class="section-title">SẢN PHẨM MỚI</h3>
    </div>
    <ul class="list-product">
        <?php if(isset($product)): ?>
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="" title="" class="thumb">
                <img src="<?php echo e(asset($item->Img)); ?>">
            </a>
            <a href="" title="" class="product-name"><?php echo e($item->Ten_SP); ?></a>
            <div class="price">
                <span class="new">6.990.000đđ</span>
                <span class="old">8.990.000đđ</span>
            </div>
            <div class="task">
                <a href="" title="Thêm giỏ hàng" class="add-cart">Thêm giỏ hàng</a>
                <a href="" title="Mua ngay" class="buy-now">Mua ngay</a>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>
    <a href="" class="xemthem">XEM THÊM</a>
</div>
<div class="product">
    <div class="section-head">
        <h3 class="section-title">Giày Nam</h3>
    </div>
    <ul class="list-product">
        <?php if(isset($productNam)): ?>
        <?php $__currentLoopData = $productNam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemNam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="" title="" class="thumb">
                <img src="<?php echo e(asset($itemNam->Img)); ?>">
            </a>
            <a href="" title="" class="product-name"><?php echo e($itemNam->Ten_SP); ?></a>
            <div class="price">
                <span class="new">6.990.000đđ</span>
                <span class="old">8.990.000đđ</span>
            </div>
            <div class="task">
                <a href="" title="Thêm giỏ hàng" class="add-cart">Thêm giỏ hàng</a>
                <a href="" title="Mua ngay" class="buy-now">Mua ngay</a>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>
    <a href="" class="xemthem">XEM THÊM</a>
    <div class="section-head">
        <h3 class="section-title">Giày Nữ</h3>
    </div>
    <ul class="list-product">
        <?php if(isset($productNu)): ?>
        <?php $__currentLoopData = $productNu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="" title="" class="thumb">
                <img src="<?php echo e(asset($item->Img)); ?>">
            </a>
            <a href="" title="" class="product-name"><?php echo e($item->Ten_SP); ?></a>
            <div class="price">
                <span class="new">6.990.000đđ</span>
                <span class="old">8.990.000đđ</span>
            </div>
            <div class="task">
                <a href="" title="Thêm giỏ hàng" class="add-cart">Thêm giỏ hàng</a>
                <a href="" title="Mua ngay" class="buy-now">Mua ngay</a>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </ul>
    <a href="" class="xemthem">XEM THÊM</a>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/Trangchu.blade.php ENDPATH**/ ?>