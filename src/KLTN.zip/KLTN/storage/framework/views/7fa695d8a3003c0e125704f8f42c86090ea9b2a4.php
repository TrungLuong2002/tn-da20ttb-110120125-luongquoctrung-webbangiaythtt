<?php $__env->startSection('title', 'Thêm chi tiết Sản Phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Thêm Sản Phẩm Nổi Bậc</h1>
        <form id="frm-themCT_SP" method="POST" action="<?php echo e(route('admin.product.createnoibac')); ?>"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div id="wp-form">

                <div class="form-group">
                    <label for="masp">Mã Sản Phẩm:</label>
                    <select name="ma_sp" id="">
                        <option value="">--------</option>
                        <?php if($product): ?>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->Ma_SP); ?>"><?php echo e($item->Ma_SP); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <?php $__errorArgs = ['ma_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color:red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
               
                <?php if(session('tb')): ?>
                    <p style="color: red"><?php echo e(session('tb')); ?></p>
                <?php endif; ?>
                <input type="submit" class="btn " value="Thêm">
            </div>





        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/showcreatenoibac.blade.php ENDPATH**/ ?>