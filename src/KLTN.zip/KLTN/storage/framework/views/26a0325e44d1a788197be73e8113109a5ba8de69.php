<?php $__env->startSection('title','quan li san pham'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Thùng rác</h1>
    <table id="tb-product">
        <thead>
            <tr>
                <th>STT</th>
                <th>Ảnh</th>
                <th>Mã Sản Phẩm</th>
                <th>Tên Sản Phẩm</th>
                <th>Giá</th>
                <th>Giá Cũ</th>
                <th>Mã Loại</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
                $stt=0;
            ?>
            <?php if($rac): ?>
            <?php $__currentLoopData = $rac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $stt++;
            ?>
            <tr>
                <td><?php echo e($stt); ?></td>
                <td><img src="<?php echo e(asset($item->Img)); ?>"" alt=""></td>
                <td><?php echo e($item->Ma_SP); ?></td>
                <td><?php echo e($item->Ten_SP); ?></td>
                <td><?php echo e($item->Gia); ?></td>
                <td><?php echo e($item->Gia_cu); ?></td>
                <td><?php echo e($item->Ma_Loai); ?></td>
                <td>
                    <a class="btn-chitiet" href="<?php echo e(route('admin.product.detail',['Ma_SP'=>$item->Ma_SP])); ?>">Xem chi tiết</a>
                </td>
                <td>
                    <a class="btn-sua" href="<?php echo e(route('admin.product.khoiphuc',['id'=>$item->San_Pham_id])); ?>">Khôi phục</a>
                    <a class="btn-xoa" href="<?php echo e(route('admin.product.xoavv',['id'=>$item->San_Pham_id])); ?>"> Xoá</a>
                   
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/thungrac.blade.php ENDPATH**/ ?>