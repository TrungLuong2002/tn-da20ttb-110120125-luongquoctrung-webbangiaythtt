<?php $__env->startSection('title', 'Trang chi tiet'); ?>
<?php $__env->startSection('content'); ?>
    <div id="product-detail-wp">
        <div id="product-images">
            <div id="images">
                <img class="thumb" src="images/anhphu.jpeg" alt="">
            </div>
            <ul id="list-img">
                <li>
                    <a href="" title="" class="thumb">
                        <img src="images/anhphu.jpeg">
                    </a>
                </li>
                <li>
                    <a href="" title="" class="thumb">
                        <img src="images/anhphu.jpeg">
                    </a>
                </li>
                <li>
                    <a href="" title="" class="thumb">
                        <img src="images/anhphu.jpeg">
                    </a>
                </li>
                <li>
                    <a href="" title="" class="thumb">
                        <img src="images/anhphu.jpeg">
                    </a>
                </li>


            </ul>
        </div>
        <div id="product-detail">
            <?php if(isset($productDetail)): ?>
                <?php $__currentLoopData = $productDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h3 class="title"><?php echo e($item->Ten_SP); ?></h3>
                    <span id="price"><?php echo e($item->Gia); ?></span>
                    <form action="<?php echo e(route('addcart',['Ma_SP' => $item->Ma_SP])); ?>" method="POST" id="frm-thuoctinh">
                        <?php echo csrf_field(); ?>
                        <label id="txt-size" for="size">Size:</label>
                        <div class="radio-group" id="size">
                            <?php if(isset($Detail)): ?>
                                <?php $__currentLoopData = $Detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="radio" id="size<?php echo e($detailItem->Kich_Thuoc); ?>" name="size"
                                        value="<?php echo e($detailItem->Kich_Thuoc); ?>">
                                    <label for="size<?php echo e($detailItem->Kich_Thuoc); ?>"><?php echo e($detailItem->Kich_Thuoc); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                        <label id="txt-color" for="color">Màu:</label>
                        <div class="radio-group" id="color">
                            <?php if(isset($DetailColor)): ?>
                                <?php $__currentLoopData = $DetailColor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="radio" id="color<?php echo e($detailItem->Ten_Mau); ?>" name="color" value="<?php echo e($detailItem->Ten_Mau); ?>">
                                    <label for="color<?php echo e($detailItem->Ten_Mau); ?>"><?php echo e($detailItem->Ten_Mau); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                        <input type="submit" id="btn-them" name="btn-them" value="THÊM VÀO GIỎ HÀNG">
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
    </div>
    <div id="product-detail-end">
        <div id="mota">
            <h3 class="title">MÔ TẢ SẢN PHẨM</h3>
            <?php if(isset($productDetail)): ?>
                <?php $__currentLoopData = $productDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($item->Mo_Ta); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div id="related-product">
            <h3 class="title">SP LIÊN QUAN</h3>
            <ul class="list-product">
                <li>
                    <a href="" title="" class="thumb">
                        <img src="images/img-pro-16.png">
                    </a>
                    <a href="" title="" class="product-name">Supper Thượng Đình</a>
                    <div class="price">
                        <span class="new">6.990.000đđ</span>
                        <span class="old">8.990.000đđ</span>
                    </div>
                    <div class="task">
                        <a href="" title="Thêm giỏ hàng" class="add-cart">Thêm giỏ hàng</a>
                        <a href="" title="Mua ngay" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li>
                    <a href="" title="" class="thumb">
                        <img src="images/img-pro-16.png">
                    </a>
                    <a href="" title="" class="product-name">Supper Thượng Đình</a>
                    <div class="price">
                        <span class="new">6.990.000đđ</span>
                        <span class="old">8.990.000đđ</span>
                    </div>
                    <div class="task">
                        <a href="" title="Thêm giỏ hàng" class="add-cart">Thêm giỏ hàng</a>
                        <a href="" title="Mua ngay" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li>
                    <a href="" title="" class="thumb">
                        <img src="images/img-pro-16.png">
                    </a>
                    <a href="" title="" class="product-name">Supper Thượng Đình</a>
                    <div class="price">
                        <span class="new">6.990.000đđ</span>
                        <span class="old">8.990.000đđ</span>
                    </div>
                    <div class="task">
                        <a href="" title="Thêm giỏ hàng" class="add-cart">Thêm giỏ hàng</a>
                        <a href="" title="Mua ngay" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li>
                    <a href="" title="" class="thumb">
                        <img src="images/img-pro-16.png">
                    </a>
                    <a href="" title="" class="product-name">Supper Thượng Đình</a>
                    <div class="price">
                        <span class="new">6.990.000đđ</span>
                        <span class="old">8.990.000đđ</span>
                    </div>
                    <div class="task">
                        <a href="" title="Thêm giỏ hàng" class="add-cart">Thêm giỏ hàng</a>
                        <a href="" title="Mua ngay" class="buy-now">Mua ngay</a>
                    </div>
                </li>

            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/productDetailLogin.blade.php ENDPATH**/ ?>