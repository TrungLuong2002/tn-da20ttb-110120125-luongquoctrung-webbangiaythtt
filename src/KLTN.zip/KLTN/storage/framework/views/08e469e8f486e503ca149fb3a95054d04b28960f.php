<?php $__env->startSection('title', 'Thêm Sản Phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <style>
            #frm-themAnhSP #wp-form {
                width: 400px;
                margin: 0 auto;
                display: flex;
                flex-direction: column;
                gap: 15px;
                padding: 20px;
                border: 1px solid #ddd;
                border-radius: 8px;
                background-color: #f9f9f9;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }

            #frm-themAnhSP #wp-form .form-group {
                display: flex;
                flex-direction: column;
            }

            #frm-themAnhSP #wp-form .form-group label {
                margin-bottom: 5px;
                font-weight: bold;
            }

            #frm-themAnhSP #wp-form .form-group select,
            #frm-themAnhSP #wp-form .form-group input[type="file"] {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }

            #frm-themAnhSP #wp-form .btn {
                align-self: center;
                padding: 10px 20px;
                border: none;
                border-radius: 4px;
                background-color: #007bff;
                color: white;
                font-size: 16px;
                cursor: pointer;
                transition: background-color 0.3s;
            }

            #frm-themAnhSP #wp-form .btn:hover {
                background-color: #0056b3;
            }
        </style>

        <h1>Thêm slide</h1>
        <form id="frm-themAnhSP" action="<?php echo e(route('admin.createslider')); ?>" method="POST" 
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div id="wp-form">
              
                <div class="form-group">
                    <label for="img">Ảnh</label>
                    <input type="file" class="form-control-file" id="image" name="image">
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <input type="submit" class="btn" value="Thêm">
                <?php if(session('tb')): ?>
                <p style="color: red"><?php echo e(session('tb')); ?></p>
            <?php endif; ?>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/slider/showcreate.blade.php ENDPATH**/ ?>