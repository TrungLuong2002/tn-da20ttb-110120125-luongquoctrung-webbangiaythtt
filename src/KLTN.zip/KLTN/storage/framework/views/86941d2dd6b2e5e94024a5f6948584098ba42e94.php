<?php $__env->startSection('title', 'quan li anh san pham'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Danh sách slide</h1>
        <div id="wp-img">
            <a href="<?php echo e(route('admin.createslidershow')); ?>" class="btn-them">+Thêm slide</a>
            <table id="tb-image">
                <thead>
                    <tr>
                        
                        <th>Ảnh</th>
    
                    </tr>
                </thead>
                <tbody>
    
                    <?php if($slide): ?>
                        <tr>
    
                            <td id="image">
                                <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <img src="<?php echo e(asset($item->Link)); ?>"" alt="">
                                        <a class="btn-xoa" href="<?php echo e(route('admin.deleteslider',['id'=>$item->Slide_id])); ?>"><i class="fa-solid fa-trash"></i></a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
    
    
                        </tr>
    
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
     
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/slider/show.blade.php ENDPATH**/ ?>