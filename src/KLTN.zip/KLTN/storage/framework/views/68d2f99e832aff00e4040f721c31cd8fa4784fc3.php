<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/mainUser.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Trangchu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/productDetail.css')); ?>">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title><?php echo $__env->yieldContent('title'); ?></title>

</head>

<body>
    <div id="container">
        <div id="header-wp">
            <div id="head-top">

                <div id="main-menu-wp">
                    <ul id="main-menu">
                        <li>
                            <a href="<?php echo e(route('Trangchu')); ?>" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user.productAll',['action'=>'all','name'=>'Sản Phẩm'])); ?>" title="">Sản phẩm</a>
                        </li>
                        <li>
                            <a href="" title="">Giới thiệu</a>
                        </li>
                        <li>
                            <a href="" title="">Liên hệ</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user.tt')); ?>" title="">Thông tin cá nhân</a>
                        </li>
                    </ul>
                </div>

            </div>
            <div id="head-body-wp">
                <div id="head-body">
                    <div id="logo">
                        <a href="<?php echo e(route('Trangchu')); ?>"><img class="max-width" src="<?php echo e(asset('uploads/images/logo3.jpeg')); ?>"
                                alt=""></a>
                    </div>
                    <div id="form-search">
                        <form action="<?php echo e(route('user.search')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="search" id="search" placeholder="tim kiem">
                            <input type="submit" value="Tìm Kiếm" id="btn-search" name="btn-search">
                        </form>
                    </div>
                    <div id="acction">
                        <div id="phone">
                            <div id="icon-phone">
                                <a href=""> <i class="fa-solid fa-headphones"></i></a>

                            </div>
                            <div id="phone-number">
                                <p>Tư vấn</p>
                                <p>0376166306</p>
                            </div>

                        </div>
                        <div id="cart">
                            <a href="<?php echo e(route('show.cart')); ?>"><i class="fa-solid fa-cart-shopping"></i></a>
                        </div>
                        <div id="logout">
                            <a href="<?php echo e(route('User.logout')); ?>"><i class="fa-solid fa-right-to-bracket"></i></a>
                        </div>

                    </div>

                </div>
            </div>

        </div>
        <div id="main-content">
            <div id="content-wp">
                <div id="side-bar">
                    <div id="menu">
                        <div id="title-menu">
                            <h3>DANH MỤC SẢN PHẨM</h3>
                        </div>
                        <div id="menu-sp">
                            <ul class="list-item">
                                <li>
                                    <a href="<?php echo e(route('user.productAll',['action'=>'ML001','name'=>'Giày Nam'])); ?>" title="">Giày nam</a>
                                    <ul class="sub-menu">
                                        <li>
                                            <a href="<?php echo e(route('user.productAll',['action'=>'GNTT','name'=>'Giày Nam Thể Thao'])); ?>" title="">Giày thể thao nam</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('user.productAll',['action'=>'GNSD','name'=>'Sandal Nam'])); ?>" title="" >Sandal nam</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('user.productAll',['action'=>'ML002','name'=>'Giày Nữ'])); ?>" title="">Giày nữ</a>
                                    <ul class="sub-menu">
                                        <li>
                                            <a href="<?php echo e(route('user.productAll',['action'=>'GNUTT','name'=>'Giày Nữ Thể Thao'])); ?>" title="">Giày thể thao nữ</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('user.productAll',['action'=>'GNUCG','name'=>'Giày Cao Gót'])); ?>" title="">Giày cao gót</a>

                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('user.productAll',['action'=>'PK','name'=>'Phụ Kiện'])); ?>" title="">Phụ kiện</a>
                                </li>
                            </ul>

                        </div>
                    </div>
                    <div id="tt-phu">
                        <?php echo $__env->yieldContent('tt-phu'); ?>
                    </div>

                </div>
                <div id="content">
                    <?php echo $__env->yieldContent('content'); ?>

                </div>



            </div>
        </div>

        <div id="footer">
            <div id="foot-body">

                <div class="block" id="info-company">
                    <h3 class="title">SHOP GIÀY</h3>
                    <p>SHOP GIÀY luôn cung cấp luôn là sản phẩm chất lượng, có nhiều chính sách ưu đãi cực lớn cho khách
                        hàng .</p>

                </div>
                <div class="block" id="info-shop">
                    <h3 class="title">Thông tin cửa hàng</h3>
                    <ul class="list-item">
                        <li>
                            <p>Cầu Ngang-Trà Vinh</p>
                        </li>
                        <li>
                            <p>0987.654.321 - 0989.989.989</p>
                        </li>
                        <li>
                            <p>luongtrung9902@gmail.com</p>
                        </li>
                    </ul>
                </div>
                <div class="block ">
                    <h3 class="title">Chính sách mua hàng</h3>
                    <ul class="list-item">
                        <li>
                            <a href="" title="">Quy định - chính sách</a>
                        </li>
                        <li>
                            <a href="" title="">Chính sách bảo hành - đổi trả</a>
                        </li>

                    </ul>
                </div>

            </div>
            <div id="food-end">
                <p id="copyright">© Bản quyền thuộc về Lương Quốc Trung</p>
            </div>
        </div>

    </div>
    <div class="overlay"></div>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/layout/appUser.blade.php ENDPATH**/ ?>