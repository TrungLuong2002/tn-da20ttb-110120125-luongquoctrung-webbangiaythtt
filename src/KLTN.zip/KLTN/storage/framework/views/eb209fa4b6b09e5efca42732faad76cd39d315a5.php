<!DOCTYPE html>
<html>

<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="<?php echo e(asset('js/jquery-2.2.4.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" type="text/javascript"></script>
    <link href="<?php echo e(asset('css/admin/user.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/admin/main.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/admin/product.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/admin/product_detail.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/admin/createproduct.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/admin/createproductdetail.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/admin/order.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/admin/image.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/admin/color.css')); ?>" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>

    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>

    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>


    <script src="https://cdn.anychart.com/releases/8.10.0/js/anychart-core.min.js"></script>
    <script src="https://cdn.anychart.com/releases/8.10.0/js/anychart-pie.min.js"></script>

</head>

<body>
    <div id="container">
        <div id="header-wp">
            <a href="<?php echo e(route('admin.index')); ?>" title="" id="logo" class="float-left">ADMIN</a>
            <div id="dropdown-user" class="float-left">
                <div id="thumb-circle">
                    <img src="<?php echo e(asset('uploads/images/logo3.jpeg')); ?>" alt="Admin">
                </div>
                <a id="logout" href="#" title="Thoát">Thoát</a>
            </div>
        </div>

        <div id="main-content-wp" class="add-cat-page">
            <div id="sidebar">
                <ul id="sidebar-menu">
                    <li class="nav-item">
                        <a href="" class="nav-link nav-toggle">
                            <span class="fa-solid fa-user"></span>
                            <span class="title">User</span>
                        </a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.user')); ?>" class="nav-link">Danh sách User</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="" class="nav-link nav-toggle">
                            <span class="fa fa-product-hunt icon"></span>
                            <span class="title">Sản phẩm</span>
                        </a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.product')); ?>" class="nav-link">Danh sách sản phẩm</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.product.create')); ?>" class="nav-link">Thêm mới</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.product.createdetail')); ?>" class="nav-link">Thêm chi tiết
                                    mới</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.product.showimage')); ?>" class="nav-link">Ảnh sản phẩm</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.product.noibac')); ?>" class="nav-link">Nổi bậc</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.product.showcrolor')); ?>" class="nav-link">Màu sắc</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.product.showsize')); ?>" class="nav-link">Kích thước</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="" class="nav-link nav-toggle">
                            <span class="fa fa-database icon"></span>
                            <span class="title">Bán hàng</span>
                        </a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.order')); ?>" class="nav-link">Danh sách đơn hàng</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link nav-toggle">
                            <i class="fa-regular fa-window-maximize"></i>
                            <span class="title">Slider</span>
                        </a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.createslidershow')); ?>" class="nav-link">Thêm mới</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.slider')); ?>" class="nav-link">Danh sách slider</a>
                            </li>
                          
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link nav-toggle">
                            <i class="fa-regular fa-window-maximize"></i>
                            <span class="title">Đánh giá</span>
                        </a>
                        <ul class="sub-menu">
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.showdanhgia', ['noidung' => 'chua-tra-loi'])); ?>" class="nav-link">Danh sách đánh giá</a>
                            </li>
                          
                        </ul>
                    </li>
                </ul>
            </div>
            <div id="content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

        <div id="footer-wp">
            <div>
                <p id="copyright">© Bản quyền thuộc về Lương Quốc Trung</p>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/layout/main.blade.php ENDPATH**/ ?>