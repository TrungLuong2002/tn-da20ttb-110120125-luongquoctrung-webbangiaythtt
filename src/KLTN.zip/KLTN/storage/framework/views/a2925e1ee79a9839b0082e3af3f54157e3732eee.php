<?php $__env->startSection('title','gio hang'); ?>
<?php $__env->startSection('content'); ?>
                <?php if(session()->has('userlogin') && Cart::count()>0): ?>
                <div id="info-cart">
                    <form action="<?php echo e(route('update.cart')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>STT</td>
                                    <td>Ảnh sản phẩm</td>
                                    <td>Tên sản phẩm</td>
                                    <td>Giá sản phẩm</td>
                                    <td>Màu sắc</td>
                                    <td>Kích thước</td>
                                    <td>Số lượng</td>
                                    <td>Thành tiền</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $t = 0;
                                ?>
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $t++;
                                    ?>
                                  
                                    <tr>
                                        <td><?php echo e($t); ?></td>
                                        <td>
                                            <a href="" title="" class="thumb">
                                                <img src="<?php echo e(asset($item->options->img)); ?>" alt="">
                                            </a>
                                        </td>
                                        <td>
                                            <a href="" title=""
                                                class="name-product"><?php echo e($item->name); ?></a>
                                        </td>
                                        <td><?php echo e(number_format($item->price, 0, ',', '.')); ?> đ</td>
                                        <td><?php echo e($item->options->color); ?></td>
                                        <td><?php echo e($item->options->size); ?></td>
                                        <td>
                                         
                                            <input type="number" min="1" max="<?php echo e($item->options->soluong); ?>" name="qty[<?php echo e($item->rowId); ?>]"
                                                value="<?php echo e($item->qty); ?>" class="num-order">
                                        </td>
                                        <td><?php echo e(number_format($item->total, 0, ',', '.')); ?> đ</td>
                                        <td>
                                            <a href="<?php echo e(route('remove.cart', ['rowId' => $item->rowId])); ?>"
                                                title="" class="del-product"><i
                                                    class="fa-solid fa-trash-can"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                            <tfoot>
                                <tr class="not">
                                    <td colspan="8">

                                        <p id="total-price">Tổng giá: <span><?php echo e(Cart::total()); ?> đ</span></p>

                                    </td>
                                </tr>
                                <tr class="not">
                                    <td id="tt" colspan="8">



                                        <input type="submit" value="Cập nhật giỏ hàng" id="update-cart" name="checkout-cart">
                                          <?php if(session('tb')): ?>
                    <p style="color: red">
                        <?php echo e(session('tb')); ?>

                    </p>
                <?php endif; ?>
                                        <a href="<?php echo e(route('checkoutcart')); ?>" title="" id="checkout-cart">Đặt hàng</a>

                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </form>
                </div>
                <div id="action-cart-wp">

                    <p class="title">Click vào <span>“Cập nhật giỏ hàng”</span> để cập nhật số lượng. Click vào
                        <span>“Xoá” </span>để xóa sản phẩm ra khỏi giỏ hàng. Nhấn vào thanh toán để hoàn tất mua hàng.
                    </p>
                    <a href="<?php echo e(route('Trangchu')); ?>" title="" id="buy-more">Mua tiếp</a><br />
                    <a href="<?php echo e(route('destroy.cart')); ?>" title="" id="delete-cart">Xóa giỏ hàng</a>

                </div>
                <?php else: ?>
                <div id="thong-bao">
                    <p >Không có sản phẩm trong giỏ hàng</p>
                    <?php if(session()->has('userlogin')): ?>
                    <a href="<?php echo e(route('Trangchu')); ?>"> Mua Ngay</a>
                    <?php else: ?>
                    <a href="<?php echo e(route('index')); ?>"> Mua Ngay</a>
                    <?php endif; ?>
                    

                </div>
                <?php endif; ?>
                
               
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.Cartlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/user/cart.blade.php ENDPATH**/ ?>