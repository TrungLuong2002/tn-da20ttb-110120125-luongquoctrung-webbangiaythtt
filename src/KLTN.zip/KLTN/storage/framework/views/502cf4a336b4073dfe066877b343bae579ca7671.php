<?php $__env->startSection('title', 'gio hang'); ?>
<?php $__env->startSection('content'); ?>

    <div id="sidebar">
        <ul id="tt">
            <li><a href="<?php echo e(route('user.tt')); ?>">Thông tin cá nhân</a></li>
            <li><a href="<?php echo e(route('user.doipass')); ?>">Đổi mật khẩu</a></li>
            <li><a href="<?php echo e(route('user.order')); ?>">Đơn hàng</a></li>
        </ul>
    </div>
    <div id="content">
        <div class="container">

            <h2>Chi tiết đơn hàng</h2>
            <nav class="order-menu">
                <ul>
                    <li><a href="<?php echo e(route('user.order')); ?>">Đang xử lí</a></li>
                    <li><a href="<?php echo e(route('user.order.huy')); ?>">Đơn đã hủy</a></li>
                    <li><a href="<?php echo e(route('user.order.duyet')); ?>">Đơn đã duyệt</a></li>
                </ul>
            </nav>
            <?php if(isset($order)): ?>

                <table class="order-table">
                    <thead>
                        <tr>
                            <th>STT</th>
                            <th>Tên sản phẩm</th>
                            <th>Màu sắc</th>
                            <th>Kích thước</th>
                            <th>Số lượng</th>
                            <th>Tổng Tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 0;
                        ?>
                        <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $count++;
                            ?>
                            <tr>
                                <td><?php echo e($count); ?></td>
                                <td><?php echo e($item->productdetail->product->Ten_SP); ?></td>
                                <td><?php echo e($item->productdetail->Ten_Mau); ?></td>
                                <td><?php echo e($item->productdetail->Kich_Thuoc); ?></td>
                                <td><?php echo e($item->So_Luong); ?></td>
                                <td><?php echo e(number_format($item->Tong_Tien, 0, ',', '.')); ?>đ</td>
                             

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


            <?php endif; ?>

        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.Cartlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/user/orderDetail.blade.php ENDPATH**/ ?>