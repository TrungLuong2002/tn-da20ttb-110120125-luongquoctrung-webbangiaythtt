<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/cartLayout.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/ttUser.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/doipass.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Userorder.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/checkout.css')); ?>">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title><?php echo $__env->yieldContent('titlle'); ?></title>
</head>

<body>
    <div id="container">
        <div id="header-wp">
            <div id="head-top">

                <div id="main-menu-wp">
                    <ul id="main-menu">
                        <li>
                            <a href="<?php echo e(route('Trangchu')); ?>" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user.productAll',['action'=>'all','name'=>'Sản Phẩm'])); ?>" title="">Sản phẩm</a>
                        </li>
                        <li>
                            <a href="" title="">Giới thiệu</a>
                        </li>
                        <li>
                            <a href="" title="">Liên hệ</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user.tt')); ?>" title="">Thông tin cá nhân</a>
                        </li>
                    </ul>
                </div>

            </div>
            <div id="head-body-wp">
                <div id="head-body">
                    <div id="logo">
                        <a href="<?php echo e(route('Trangchu')); ?>"><img class="max-width" src="<?php echo e(asset('uploads/images/logo3.jpeg')); ?>" alt=""></a>
                    </div>
                    <div id="form-search">
                        <form action="<?php echo e(route('user.search')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="search" id="search" placeholder="tim kiem">
                            <input type="submit" value="Tìm Kiếm" id="btn-search" name="btn-search">
                        </form>
                    </div>
                    <div id="acction">
                        <div id="phone">
                            <div id="icon-phone">
                                <a href=""> <i class="fa-solid fa-headphones"></i></a>

                            </div>
                            <div id="phone-number">
                                <p>Tư vấn</p>
                                <p>0376166306</p>
                            </div>

                        </div>
                        <div id="cart">
                            <a href="<?php echo e(route('show.cart')); ?>"><i class="fa-solid fa-cart-shopping"></i></a>
                        </div>
                        <div id="logout">
                            <?php if(session()->has('userlogin')): ?>
                            <a href="<?php echo e(route('User.logout')); ?>"><i class="fa-solid fa-right-to-bracket"></i></a>
                            <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-user"></i></a>
                            <?php endif; ?>
                          
                        </div>

                    </div>

                </div>
            </div>

        </div>
        <div id="main-content-wp">
           
                <?php echo $__env->yieldContent('content'); ?>
           
        </div>

        <div id="footer">
            <div id="foot-body">

                <div class="block" id="info-company">
                    <h3 class="title">SHOP GIÀY</h3>
                    <p>SHOP GIÀY luôn cung cấp luôn là sản phẩm chất lượng, có nhiều chính sách ưu đãi cực lớn cho khách
                        hàng .</p>

                </div>
                <div class="block" id="info-shop">
                    <h3 class="title">Thông tin cửa hàng</h3>
                    <ul class="list-item">
                        <li>
                            <p>Cầu Ngang-Trà Vinh</p>
                        </li>
                        <li>
                            <p>0987.654.321 - 0989.989.989</p>
                        </li>
                        <li>
                            <p>luongtrung9902@gmail.com</p>
                        </li>
                    </ul>
                </div>
                <div class="block ">
                    <h3 class="title">Chính sách mua hàng</h3>
                    <ul class="list-item">
                        <li>
                            <a href="" title="">Quy định - chính sách</a>
                        </li>
                        <li>
                            <a href="" title="">Chính sách bảo hành - đổi trả</a>
                        </li>

                    </ul>
                </div>

            </div>
            <div id="food-end">
                <p id="copyright">© Bản quyền thuộc về Lương Quốc Trung</p>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/layout/Cartlayout.blade.php ENDPATH**/ ?>