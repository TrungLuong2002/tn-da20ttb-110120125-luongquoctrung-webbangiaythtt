<?php $__env->startSection('title', 'quan li anh san pham'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Danh sách ảnh sản phẩm</h1>
        <a href="<?php echo e(route('admin.product.showcreateimage')); ?>" class="btn-them">+Thêm Ảnh</a>
        <table id="tb-image">
            <thead>
                <tr>
                    <th>STT</th>

                    <th>Mã Sản Phẩm</th>
                    <th>Ảnh</th>


                </tr>
            </thead>
            <tbody>
                <?php
                    $stt = 0;
                ?>
                <?php if($image): ?>
                    <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma_sp => $imageGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $stt++;
                        ?>
                        <tr>
                            <td id="stt"><?php echo e($stt); ?></td>
                            <td id="ma_sp"><?php echo e($ma_sp); ?></td>
                            <td id="image">
                                <?php $__currentLoopData = $imageGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <img src="<?php echo e(asset($image->Link)); ?>"" alt="">
                                        <a class="btn-xoa"
                                            href="<?php echo e(route('admin.product.deleteimage_item', ['id' => $image->Anh_id])); ?>"><i
                                                class="fa-solid fa-trash"></i></a>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <a class="btn-xoa" href="<?php echo e(route('admin.product.deleteimage',['Ma_SP'=>$ma_sp])); ?>"><i class="fa-solid fa-trash"></i></a>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/showimage.blade.php ENDPATH**/ ?>