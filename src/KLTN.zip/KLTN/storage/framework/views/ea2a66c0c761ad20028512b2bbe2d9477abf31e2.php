<?php $__env->startSection('title', 'quan li size'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div id="wp-color">
            <div id="showcolor">

                <h1>Danh sách kích thước sản phẩm</h1>
                <table id="tb-color">
                    <thead>
                        <tr>
                            <th>STT</th>

                            <th>Kích thước</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $stt = 0;
                        ?>
                        <?php if($size): ?>
                            <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $stt++;
                                ?>
                                <tr>
                                    <td id="stt"><?php echo e($stt); ?></td>
                                    <td id="ma_sp"><?php echo e($item->Kich_Thuoc); ?></td>

                                    <td>
                                        <a class="btn-xoa"
                                            href="<?php echo e(route('admin.product.deletesize', ['id' => $item->Kich_Thuoc_id])); ?>"><i
                                                class="fa-solid fa-trash"></i></a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div id="createcolor">
                <h1>Thêm kích thước mới</h1>
                <form id="frm-themSP" method="POST" action="<?php echo e(route('admin.product.createsize')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div id="wp-form">

                        <div class="form-group">
                            <label for="kich_thuoc">Kích thước</label>
                            <input type="text" class="form-control" id="mau" name="kich_thuoc">
                            <?php $__errorArgs = ['kich_thuoc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <?php if(session('tb')): ?>
                        <p style="color: red"><?php echo e(session('tb')); ?></p>
                    <?php endif; ?>
                    <input type="submit" class="btn " value="Thêm">


                </form>
            </div>
            <div id="updatecolor">
                <h1>Sửa</h1>
                <form id="frm-themSP" method="POST" action="<?php echo e(route('admin.product.updatesize')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div id="wp-form">
                        <div class="form-group">
                            <label for="kich_thuoc_cu">Kích thước cũ</label>
                            <select name="kich_thuoc_cu" class="form-control" id="mau_cu">
                                <option value="">----</option>
                                <?php if($size): ?>
                                    <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->Kich_Thuoc_id); ?>"><?php echo e($item->Kich_Thuoc); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>

                        </div>
                        <div class="form-group">
                            <label for="mau">Kích thước mới</label>
                            <input type="text" class="form-control" id="mau" name="kich_thuoc_moi">
                        </div>



                    </div>
                    <?php if(session('tb2')): ?>
                        <p style="color: red"><?php echo e(session('tb2')); ?></p>
                    <?php endif; ?>
                    <?php $__errorArgs = ['kich_thuoc_cu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['kich_thuoc_moi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="submit" class="btn " value="Sửa">

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/sizeshow.blade.php ENDPATH**/ ?>