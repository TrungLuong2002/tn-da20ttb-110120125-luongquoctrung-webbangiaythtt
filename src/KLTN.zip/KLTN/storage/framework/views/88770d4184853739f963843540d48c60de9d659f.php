<?php $__env->startSection('title', 'gio hang'); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('dat-hang')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div id="content-wp">
            <div id="customer-info">
                <h2>THÔNG TIN KHÁCH HÀNG</h1>
                    <div id="frm-tt">
                        <?php if($user): ?>

                            <div class="form-row clearfix">
                                <div class="form-col fl-left">
                                    <label for="fullname">Họ tên</label>
                                    <input type="text" name="fullname" id="fullname" value="<?php echo e($user->FullName); ?>">
                                </div>
                                <div class="form-col fl-right">
                                    <label for="email">Email</label>
                                    <input type="email" name="email" id="email" value="<?php echo e($user->Email); ?>">
                                </div>
                            </div>
                            <div class="form-row clearfix">
                                <div class="form-col fl-left">
                                    <label for="address">Địa chỉ</label>
                                    <?php if($address): ?>
                                        <input type="text" name="address" id="address"
                                            value="<?php echo e($ward->Ten_Xa); ?>, <?php echo e($district->Ten_Huyen); ?>, <?php echo e($provine->Ten_Tinh); ?>">
                                    <?php else: ?>
                                        <input type="text" name="address" id="address" value="">
                                    <?php endif; ?>

                                </div>
                                <div class="form-col fl-right">
                                    <label for="phone">Số điện thoại</label>
                                    <input type="tel" name="phone" id="phone" value="<?php echo e($user->SDT); ?>">
                                </div>
                            </div>
                            <div class="form-row  clearfix">
                                <div class="form-col">
                                    <label for="notes">Ghi chú</label>
                                    <textarea name="note"></textarea>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
            </div>
            <div id="order-info">
                <h2>THÔNG TIN ĐƠN HÀNG</h1>
                    <table class="shop-table">
                        <thead>
                            <tr>
                                <td>Sản phẩm</td>
                                <td>Tổng</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="cart-item">
                                    <td class="product-name"><?php echo e($item->name); ?> ( <?php echo e($item->options->color); ?> |
                                        <?php echo e($item->options->size); ?> )<strong class="product-quantity">x
                                            <?php echo e($item->qty); ?></strong></td>
                                    <td class="product-total"><?php echo e(number_format($item->total, 0, ',', '.')); ?> đ</td>
                                </tr </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tfoot>
                            <tr class="order-total">
                                <td>Tổng đơn hàng:</td>
                                <td><strong class="total-price"><?php echo e(Cart::total()); ?> đ</strong></td>
                            </tr>
                        </tfoot>
                    </table>

                    <ul id="payment-methods">
                        <li>
                            <input type="radio" id="direct-payment" name="payment-method" value="home-payment">
                            <label for="direct-payment">Thanh toán Khi nhận hàng</label>
                        </li>
                        <input type="hidden" name="total" value="<?php echo e(Cart::total()); ?>">
                        <button type="submit" name="payUrl" id="momo">Thanh toán MOMO</button>
                        
                        <button type="submit" name="onepay" id="onepay">Thanh toán ONEPAY</button>
                      
                        <a href="<?php echo e(route('processTransaction')); ?>" id="paypal"><img
                                src="<?php echo e(asset('uploads/images/paypalicon.jpeg')); ?>" alt=""></a>


                    </ul>
                    <?php $__errorArgs = ['payment-method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if(session('tb')): ?>
                        <p style="color: red">
                            <?php echo e(session('tb')); ?>

                        </p>
                    <?php endif; ?>


                    <div class="place-order-wp clearfix">
                        <input type="submit" id="order-now" name="dathang" value="Đặt hàng">
                    </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.Cartlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/user/checkoutcart.blade.php ENDPATH**/ ?>