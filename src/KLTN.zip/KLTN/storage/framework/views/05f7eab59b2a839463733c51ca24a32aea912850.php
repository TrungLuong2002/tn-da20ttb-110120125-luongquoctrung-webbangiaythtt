<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <style>
        #login-container {
            display: block;


            width: 300px;
            padding: 20px;
            background-color: rgb(255, 255, 255);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;


            text-align: center;
        }

        #login-container h3 {
            color: #f12a43;
        }

        #login-container #loginForm .input-group {
            margin-bottom: 15px;
        }

        #login-container #loginForm .input-group label {
            text-align: left;
            display: block;
            margin-bottom: 5px;
        }

        #login-container #loginForm .input-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        #login-container #loginForm button {
            width: 30%;
            padding: 10px;
            background-color: #f12a43;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        #login-container #loginForm button:hover {
            background-color: #d9263c;
        }

        #login-container #loginForm #action {
            font-size: 14px;
            margin-top: 15px;
            text-align: left;
            margin-bottom: 15px;
        }

        #login-container #loginForm #action a {
            color: #0066cc;
            text-decoration: none;
        }

        #login-container #loginForm #action a:hover {
            text-decoration: underline;
        }

        #loginForm #btn-thoat {
            display: block;
            text-decoration: none;
            text-align: center;
            padding: 10px;
            background-color: #999;
        
            color:#fff;
            float: right;
        }

        .error {
            text-align: center;
            color: #d9263c;
            font-weight: bold
        }
    </style>
    <div id="login-container">
        <h3>Đăng Nhập</h3>
        <form id="loginForm" action="<?php echo e(route('User.login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <label for="username">Tên đăng nhập:</label>
                <input type="text" id="username" name="username">
            </div>
            <div class="input-group">
                <label for="password">Mật khẩu:</label>
                <input type="password" id="password" name="password">
            </div>
            <div id="action">
                <a href="<?php echo e(route('quenmk')); ?>">Quên mật khẩu?</a>
                <p>Bạn chưa có tài khoản?<a href="<?php echo e(route('register')); ?>"> Đăng kí</a></p>

            </div>
            <button type="submit">Login</button>
            <?php if($errors->any()): ?>
                <div class="error">

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            <?php endif; ?>
            
        </form>
        
    </div>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/user/login.blade.php ENDPATH**/ ?>