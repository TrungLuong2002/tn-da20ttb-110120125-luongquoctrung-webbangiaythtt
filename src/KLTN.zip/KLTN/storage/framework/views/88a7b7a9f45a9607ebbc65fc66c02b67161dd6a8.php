<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xác nhận đăng kí thành công</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.tick-container {
    text-align: center;
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 500px;
    max-width: 100%;
}

.tick-icon {
    margin: 0 auto 20px;
    width: 150px; /* Kích thước của hình ảnh tick */
    height: 150px; /* Kích thước của hình ảnh tick */
}

.tick-icon img {
    width: 100%;
    height: 100%;
}

p {
    font-size: 18px;
    color: #333;
    margin-bottom: 20px;
}

a {
    display: inline-block;
    text-decoration: none;
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border-radius: 4px;
}

a:hover {
    background-color: #0056b3;
}

    </style>
    <div class="tick-container">
        <div class="tick-icon">
            <img src="<?php echo e(asset('uploads/images/tick.png')); ?>" alt="Tick">
        </div>
        <p>Bạn đã đăng kí thành công</p>
        <a href="<?php echo e(route('login')); ?>">Đăng nhập</a>
    </div>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/user/thanhcong.blade.php ENDPATH**/ ?>