<p>Mật khẩu của bạn là: <strong><?php echo e($data['pass']); ?></strong></p>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/user/MailLaymk.blade.php ENDPATH**/ ?>