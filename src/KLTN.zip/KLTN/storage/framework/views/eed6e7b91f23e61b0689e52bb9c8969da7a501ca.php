<?php $__env->startSection('title', 'gio hang'); ?>
<?php $__env->startSection('content'); ?>

    <style>
        #sidebar ul li a.mau-menu.mau-menu {
            border-left: 2px solid #fa0101;
            background-color: #ffe3e3;
        }
    </style>

    <div id="sidebar">
        <ul id="tt">
            <li><a class="mau-menu" href="<?php echo e(route('user.tt')); ?>">Thông tin cá nhân</a></li>
            <li><a href="<?php echo e(route('user.doipass')); ?>">Đổi mật khẩu</a></li>
            <li><a href="<?php echo e(route('user.order')); ?>">Đơn hàng</a></li>
        </ul>
    </div>
    <div id="content">
        <h2>Thông tin cá nhân</h2>
        <form action="<?php echo e(route('user.updatett')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label for="name">Tên</label>
            <input type="text" id="name" name="name" value="<?php echo e($user->FullName); ?>">

            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo e($user->Email); ?>">

            <label for="phone">Số điện thoại</label>
            <input type="text" id="phone" name="phone" value="<?php echo e($user->SDT); ?>">

            <label for="address">Địa chỉ</label><br>

            <?php if(isset($address)): ?>
                <?php
                    $diachi = $ward->Ten_Xa . ', ' . $district->Ten_Huyen . ', ' . $provine->Ten_Tinh;
                    Session::put('diachi', $diachi);
                ?>
                <select name="tinh" id="tinh">
                    <?php if(isset($tinh)): ?>
                        <?php $__currentLoopData = $tinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tinh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tinh->Tinh_id); ?>"
                                <?php echo e($provine->Ten_Tinh == $tinh->Ten_Tinh ? 'selected' : ''); ?>>
                                <?php echo e($tinh->Ten_Tinh); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <select name="huyen" id="huyen">
                    <?php if(isset($huyen)): ?>
                        <?php $__currentLoopData = $huyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $huyen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($huyen->Huyen_id); ?>"
                                <?php echo e($district->Ten_Huyen == $huyen->Ten_Huyen ? 'selected' : ''); ?>>
                                <?php echo e($huyen->Ten_Huyen); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <select name="xa" id="xa">
                    <?php if(isset($xa)): ?>
                        <?php $__currentLoopData = $xa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $xa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($xa->Xa_id); ?>" <?php echo e($ward->Ten_Xa == $xa->Ten_Xa ? 'selected' : ''); ?>>
                                <?php echo e($xa->Ten_Xa); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select><br><br>
            <?php else: ?>
            <?php
            $diachi = "";
            Session::put('diachi', $diachi);
        ?>
                <select name="tinh" id="tinh">
                    <?php if(isset($tinh)): ?>
                        <option value="">----chọn tỉnh-----</option>
                        <?php $__currentLoopData = $tinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tinh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tinh->Tinh_id); ?>"><?php echo e($tinh->Ten_Tinh); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <select name="huyen" id="huyen">
                    <?php if(isset($huyen)): ?>
                        <option value="">----chọn huyện-----</option>
                        <?php $__currentLoopData = $huyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $huyen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($huyen->Huyen_id); ?>"><?php echo e($huyen->Ten_Huyen); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <select name="xa" id="xa">
                    <?php if(isset($xa)): ?>
                        <option value="">----chọn xã-----</option>
                        <?php $__currentLoopData = $xa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $xa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($xa->Xa_id); ?>"><?php echo e($xa->Ten_Xa); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select><br><br>
            <?php endif; ?>
            <?php if(session('tb')): ?>
                <p style="color:rgb(5, 132, 0)"><?php echo e(session('tb')); ?></p>
            <?php endif; ?>
            <?php $__errorArgs = ['tinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['huyen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['xa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="submit" value="Cập nhật">
        </form>
    </div>

    <script>
        $(document).ready(function() {
            $('#tinh').change(function() {
                var tinh_id = $(this).val();
                $.ajax({
                    url: '<?php echo e(route('user.gethuyen', ':tinh_id')); ?>'.replace(':tinh_id', tinh_id),
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        $('#huyen').empty();
                        $('#huyen').append('<option value="">Chọn huyện</option>');
                        $('#xa').empty();
                        $('#xa').append('<option value="">Chọn xã</option>');
                        $.each(response, function(key, huyen) {
                            $('#huyen').append('<option value="' + huyen.Huyen_id +
                                '">' + huyen.Ten_Huyen + '</option>');
                        });
                    }
                });
            });

            $('#huyen').change(function() {
                var huyen_id = $(this).val();
                $.ajax({
                    url: '<?php echo e(route('user.getxa', ':huyen_id')); ?>'.replace(':huyen_id', huyen_id),
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {

                        $.each(response, function(key, xa) {
                            $('#xa').append('<option value="' + xa.Xa_id + '">' + xa
                                .Ten_Xa + '</option>');
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.Cartlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/user/tt.blade.php ENDPATH**/ ?>