<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xác nhận tài khoản</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 500px;
            max-width: 100%;
        }

        h3 {
            text-align: center;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        input[type="text"] {
            width: calc(100% - 20px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            width: 30%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            display: block;
            margin: 10px auto;
        }

        button:hover {
            background-color: #0056b3;
        }

        form a {
            float: right;
            display: block;
            text-decoration: none;
            padding: 10px;
            background-color: #cdcccc;
            border-radius: 7px;
            color: black;
        }

        form a:hover {
            background-color: #a2a0a0;
        }
    </style>
    <div class="container">
        <h3>Xác nhận tài khoản</h3>
        <form action="<?php echo e(route('sendmail.check')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if($data): ?>
            <input type="hidden" name="data" value="<?php echo e($data); ?>">
            <input type="hidden" name="fullname" value="<?php echo e($fullname); ?>">
            <input type="hidden" name="username" value="<?php echo e($username); ?>">
            <input type="hidden" name="password" value="<?php echo e($password); ?>">
            <input type="hidden" name="email" value="<?php echo e($email); ?>">
            <input type="hidden" name="phone" value="<?php echo e($phone); ?>">
            <?php endif; ?>
         
            <div class="form-group">
                <p>Kiểm tra email của bạn và nhập mã xác nhận vào ô bên dưới.</p>
                <input type="text" id="giatri" name="giatri">
            </div>
            <button type="submit">Xác nhận</button>
  
            <a href="<?php echo e(route('register')); ?>">Quay lại</a>
            <?php if(isset($tb)): ?>
            <p style="color: red">
                <?php echo e($tb); ?>

            </p>
        <?php endif; ?>
        </form>
    </div>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/user/xacnhan.blade.php ENDPATH**/ ?>