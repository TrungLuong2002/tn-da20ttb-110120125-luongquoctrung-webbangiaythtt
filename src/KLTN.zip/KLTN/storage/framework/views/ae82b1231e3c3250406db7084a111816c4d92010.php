<?php $__env->startSection('title', 'gio hang'); ?>
<?php $__env->startSection('content'); ?>
    <style>
          #sidebar ul li a.mau-menu {
            border-left: 2px solid #fa0101;
            background-color: #ffe3e3;
        }
    </style>
    <div id="sidebar">
        <ul id="tt">
            <li><a href="<?php echo e(route('user.tt')); ?>">Thông tin cá nhân</a></li>
            <li><a class="mau-menu" href="<?php echo e(route('user.doipass')); ?>">Đổi mật khẩu</a></li>
            <li><a href="<?php echo e(route('user.order')); ?>">Đơn hàng</a></li>
        </ul>
    </div>
    <div id="content">
        <h2>Đổi mật khẩu</h2>
        <form id="frm-doimk" action="<?php echo e(route('user.doimk')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label for="name">Mật khẩu cũ</label>
            <input type="password" id="password" name="password" required>

            <label for="passnew">mật khẩu mới</label>
            <input type="password" id="passnew" name="passnew" required>

            <label for="passnewN">Nhập lại mật khẩu mới</label>
            <input type="password" id="passnewN" name="passnewN" required>
            <?php if(isset($tb)): ?>
                <p style="color:red; margin-bottom:10px"><?php echo e($tb); ?></p>
            <?php endif; ?>

            <input type="submit" value="Đổi mật khẩu">

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.Cartlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/user/doipass.blade.php ENDPATH**/ ?>