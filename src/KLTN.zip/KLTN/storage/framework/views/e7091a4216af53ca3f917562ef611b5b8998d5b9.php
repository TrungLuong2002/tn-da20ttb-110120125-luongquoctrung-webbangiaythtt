<?php $__env->startSection('title', 'quan li user'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Danh sách người dùng</h1>

        <table id="tb-user">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>ID</th>
                    <th>Tên</th>
                    <th>Số Điện Thoại</th>
                    <th>Email</th>
                    <th>Địa chỉ</th>

                </tr>
            </thead>
            <tbody>
                <?php
                    $stt = 0;
                ?>
                <?php if($user): ?>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $stt++;
                        ?>
                        <tr>
                            <td><?php echo e($stt); ?></td>
                            <td><?php echo e($item->User_id); ?></td>
                            <td><?php echo e($item->FullName); ?></td>
                            <td><?php echo e($item->SDT); ?></td>
                            <td><?php echo e($item->Email); ?></td>
                            <td>
                                <?php if($item->Dia_Chi_id != null): ?>
                                    <?php echo e($item->diaChi->Tinh->Ten_Tinh); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn-xoa" href=""><i class="fa-solid fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/user/user.blade.php ENDPATH**/ ?>