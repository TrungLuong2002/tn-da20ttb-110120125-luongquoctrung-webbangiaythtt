<?php $__env->startSection('title', 'Thêm chi tiết Sản Phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Sửa Chi Tiết Sản Phẩm</h1>
        <form id="frm-themCT_SP" method="POST" action="<?php echo e(route('admin.product.updateproductdetail',['id'=>$productdetail->Chi_Tiet_SP_id])); ?>"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div id="wp-form">

                <div class="form-group">
                    <label for="masp">Mã Sản Phẩm:</label>
                    <input type="text" name="ma_sp" value="<?php echo e($productdetail->Ma_SP); ?>" id="ma_sp">
                   
                </div>
                <div class="form-group">
                    <label for="color">Màu Sắc:</label>
                    <select name="color" id="">
                        <?php if($color): ?>
                            <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->Ten_Mau); ?>"   <?php echo e($productdetail->Ten_Mau == $item->Ten_Mau ? 'selected' : ''); ?>><?php echo e($item->Ten_Mau); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </select>
                   
                </div>
                <div class="form-group">
                    <label for="size">Kích Thước</label>
                    <select name="size" id="">
                        <?php if($size): ?>
                            <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->Kich_Thuoc); ?>"   <?php echo e($productdetail->Kich_Thuoc == $item->Kich_Thuoc ? 'selected' : ''); ?>><?php echo e($item->Kich_Thuoc); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                   
                </div>
                <div class="form-group">
                    <label for="soluong">Số lượng:</label>
                    <input type="text" name="soluong" id="soluong" value="<?php echo e($productdetail->So_Luong); ?>">
                </div>
                <?php if(session('tb')): ?>
                    <p style="color: red"><?php echo e(session('tb')); ?></p>
                <?php endif; ?>
                <input type="submit" class="btn " value="Sửa thông tin">
            </div>





        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/updatedetail.blade.php ENDPATH**/ ?>