<?php $__env->startSection('title','quan li san pham'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<style>
    #frm-serch-sp{
        float: right;
    }
    #frm-serch-sp #timkiem{
       padding: 5px;

    }
    #frm-serch-sp #btn-tim{
       
       padding: 7px;
border: none;
       
    }
    #tb-kho{
        font-family: Arial, Helvetica, sans-serif;
        font-weight: bold;
    }
    #tb-kho a{
       display: inline-block;
       text-decoration: none;
       color: red;
    }
    

</style>
    <h1>Danh sách sản phẩm</h1>
   
    <a href="<?php echo e(route('admin.product.create')); ?>" class="btn-them">+Thêm Sản Phẩm</a>
    <a href="<?php echo e(route('admin.product.rac')); ?>" class="btn-rac"><i class="fa-solid fa-trash-can"></i></a>
    <form action="<?php echo e(route('admin.product.search')); ?>" id="frm-serch-sp" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" id="timkiem" name="search" placeholder="Nhập tên hoặc mã sản phẩm">
        <input type="submit" id="btn-tim" value="Tìm kiếm" class="btn-them">
    </form>
    <?php if($product_het): ?>
    <p id="tb-kho">Có <?php echo e($product_het); ?> sản phẩm hết hàng <a href="<?php echo e(route('admin.product.showhet')); ?>">Xem</a></p>
    <?php endif; ?>
   
  
    <table id="tb-product">
        <thead>
            <tr>
                <th>STT</th>
                <th>Ảnh</th>
                <th>Mã Sản Phẩm</th>
                <th>Tên Sản Phẩm</th>
                <th>Giá</th>
                <th>Giá Cũ</th>
                <th>Mã Loại</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
                $stt=0;
            ?>
            <?php if($product): ?>
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $stt++;
            ?>
            <tr>
                <td><?php echo e($stt); ?></td>
                <td><img src="<?php echo e(asset($item->Img)); ?>"" alt=""></td>
                <td><?php echo e($item->Ma_SP); ?></td>
                <td><?php echo e($item->Ten_SP); ?></td>
                <td><?php echo e($item->Gia); ?></td>
                <td><?php echo e($item->Gia_cu); ?></td>
                <td><?php echo e($item->Ma_Loai); ?></td>
                <td>
                    <a class="btn-chitiet" href="<?php echo e(route('admin.product.detail',['Ma_SP'=>$item->Ma_SP])); ?>">Xem chi tiết</a>
                </td>
                <td>
                    <a class="btn-sua" href="<?php echo e(route('admin.product.updateshow',['id'=>$item->San_Pham_id])); ?>"><i class="fa-solid fa-gear"></i></a>
                    <a class="btn-xoa" href="<?php echo e(route('admin.product.delete',['id'=>$item->San_Pham_id])); ?>"><i class="fa-solid fa-trash"></i></a>
                   
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

           
        </tbody>
        
    </table>
    <div class="pagination">
        <?php echo e($product->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/product.blade.php ENDPATH**/ ?>