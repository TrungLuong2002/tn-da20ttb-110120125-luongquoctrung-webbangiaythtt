<?php $__env->startSection('title', 'quan li san pham'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <style>
            #frm-serch-sp {
                float: right;
            }

            #frm-serch-sp #timkiem {
                padding: 5px;

            }

            #frm-serch-sp #btn-tim {

                padding: 7px;
                border: none;

            }
        </style>
        <h1>Danh sách sản phẩm hết</h1>
        <table id="tb-product">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã Sản Phẩm</th>
                    <th>Màu</th>
                    <th>Kích thước</th>

                </tr>
            </thead>
            <tbody>
                <?php
                    $stt = 0;
                ?>
                <?php if($product_het): ?>
                    <?php $__currentLoopData = $product_het; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $stt++;
                        ?>
                        <tr>
                            <td><?php echo e($stt); ?></td>
                            <td><?php echo e($item->Ma_SP); ?></td>
                            <td><?php echo e($item->Ten_Mau); ?></td>
                            <td><?php echo e($item->Kich_Thuoc); ?></td>
                            <td>
                                <form action="<?php echo e(route('admin.product.capnhatsoluong', ['id' => $item->Chi_Tiet_SP_id])); ?>" method="post"
                                    class="frm-traloi">
                                    <?php echo csrf_field(); ?>

                                    <input type="text" name="soluong">
                                    <input type="submit" value="Cập nhật">
                                </form>
                            </td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/hethang.blade.php ENDPATH**/ ?>