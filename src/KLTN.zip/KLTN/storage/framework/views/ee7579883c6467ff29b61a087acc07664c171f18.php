<?php $__env->startSection('title', 'quan li san pham'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .frm-traloi .traloi {
            font-family: Arial, Helvetica, sans-serif;
            width: 300px;
            height: 50px;
        }
        #frm-locdanhgia{
            margin-bottom: 20px;
        }
        #frm-locdanhgia #locdanhgia{
            padding: 3px;
        }
        #frm-locdanhgia #btn-locdanhgia{
            display: inline-block;
            padding: 3px;
         
        }
    </style>
    <div class="container">

        <h1>Danh sách đánh giá</h1>
        <form action="<?php echo e(route('admin.locdanhgia',['noidung'=>"khac"])); ?>" id="frm-locdanhgia">
            <?php echo csrf_field(); ?>
            <select name="locdanhgia" id="locdanhgia">
                <option value="">------------</option>
                <option value="all">Tất cả đánh giá</option>
                <option value="chua-tra-loi">Chưa trả lời</option>
                <option value="7ngay">7 ngày</option>
                <option value="1sao">1 sao</option>
                <option value="2sao">2 sao</option>
                <option value="3sao">3 sao</option>
                <option value="4sao">4 sao</option>
                <option value="5sao">5 sao</option>
            </select>
        
            <input type="submit" id="btn-locdanhgia" value="Lọc">
            <?php $__errorArgs = ['locdanhgia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p style="color: red"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>
        <table id="tb-order">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã sản phẩm</th>
                    <th>Số sao</th>
                    <th>Nội dung</th>
                    <?php if(session('tb')): ?>
                        <p style="color: #00af26"><?php echo e(session('tb')); ?></p>
                    <?php endif; ?>

                </tr>
            </thead>
            <tbody>
                <?php
                    $stt = 0;
                ?>
                <?php if($danhgia): ?>
                    <?php $__currentLoopData = $danhgia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $stt++;
                        ?>
                        <tr>
                            <td><?php echo e($stt); ?></td>
                            <td><?php echo e($item->product->Ma_SP); ?></td>
                            <td>
                                <?php for($i = 1; $i <= $item->So_Sao; $i++): ?>
                                    <span class="user-rating" style="color: #f5b301;"">&#9733;</span>
                                <?php endfor; ?>
                            </td>
                            <td><?php echo e($item->Noi_Dung); ?></td>
                            <td>
                                <form action="<?php echo e(route('admin.traloidanhgia', ['id' => $item->Danh_Gia_id])); ?>"
                                    class="frm-traloi">
                                    <?php echo csrf_field(); ?>
                                    <textarea name="traloi" class="traloi"><?php echo e($item->Tra_Loi); ?></textarea><br>
                                    <input type="submit" value="Trả lời">
                                </form>
                            </td>
                            <td>
                                <a class="btn-xoa" href="<?php echo e(route('admin.deletedanhgia',['id'=>$item->Danh_Gia_id])); ?>"><i class="fa-solid fa-trash"></i></a>
                            </td>
                        
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>


            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/conment/danhgia.blade.php ENDPATH**/ ?>