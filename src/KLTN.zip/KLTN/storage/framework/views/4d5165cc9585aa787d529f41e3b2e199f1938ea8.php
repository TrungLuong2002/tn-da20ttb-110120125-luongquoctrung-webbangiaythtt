<?php $__env->startSection('title', 'Search'); ?>
<?php $__env->startSection('tt-phu'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content-head">
        <?php if(isset($product_search)): ?>
            <h1>Kết quả tìm kiếm cho "<?php echo e($key); ?>"</h1>
        <?php endif; ?>
    </div>
    <div id="content-body">
        <ul class="list-product">
            <?php if(isset($product_search) && count($product_search) > 0): ?>
                <?php $__currentLoopData = $product_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('User.productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP])); ?>"
                            title="" class="thumb">
                            <img src="<?php echo e(asset($item->Img)); ?>">
                        </a>
                        <a href="<?php echo e(route('User.productDetail', ['id' => $item->San_Pham_id, 'Ma_SP' => $item->Ma_SP])); ?>"
                            title="" class="product-name"><?php echo e($item->Ten_SP); ?></a>
                        <div class="price">
                            <span class="new"><?php echo e(number_format($item->Gia, 0, ',', '.')); ?>đ</span>
                            <?php if($item->Gia_cu != null): ?>
                                <span class="old"><?php echo e(number_format($item->Gia_cu, 0, ',', '.')); ?>đ</span>
                            <?php endif; ?>
                        </div>
                        <div class="task">
                            <a href="#" title="Thêm giỏ hàng" class="add-cart">Thêm giỏ hàng</a>
                            <a href="#" title="Mua ngay" class="buy-now">Mua ngay</a>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Không tìm thấy sản phẩm nào.</p>
            <?php endif; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.appUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/User/Usersearch.blade.php ENDPATH**/ ?>