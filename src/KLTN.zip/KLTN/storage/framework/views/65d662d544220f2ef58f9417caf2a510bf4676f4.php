<?php $__env->startSection('title','quan li chi tiet don'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Danh sách chi tiết đơn hàng</h1>
    <table id="tb-order">
        <thead>
            <tr>
                <th>STT</th>
                <th>Tên sản phẩm</th>
                <th>Màu</th>
                <th>Kích thước</th>
                <th>Số lượng</th>
                <th>Tổng</th>
                
            </tr>
        </thead>
        <tbody>
           <?php
               $stt=0;
           ?>
           <?php if($order): ?>
           <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php
               $stt++;
           ?>
           <tr>
            <td><?php echo e($stt); ?></td>
            <td><?php echo e($item->productdetail->product->Ten_SP); ?></td>
            <td><?php echo e($item->productdetail->Ten_Mau); ?></td>
            <td><?php echo e($item->productdetail->Kich_Thuoc); ?></td>
            <td><?php echo e($item->So_Luong); ?></td>
            <td><?php echo e(number_format($item->Tong_Tien, 0, ',', '.')); ?>đ</td>
        </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
            
            
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/order/orderdetail.blade.php ENDPATH**/ ?>