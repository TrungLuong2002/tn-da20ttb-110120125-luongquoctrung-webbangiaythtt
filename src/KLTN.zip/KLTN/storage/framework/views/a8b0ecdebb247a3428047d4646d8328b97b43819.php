<?php $__env->startSection('title', 'Thêm Sản Phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Thêm Sản Phẩm Mới</h1>
        <form id="frm-themSP" method="POST" action="<?php echo e(route('admin.product.createproduct')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div id="wp-form">
                <div id="left">
                    <div class="form-group">
                        <label for="ma_sp">Mã Sản Phẩm</label>
                        <input type="text" class="form-control" id="ma_sp" name="ma_sp">
                        <?php $__errorArgs = ['ma_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color: red"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="ten_sp">Tên Sản Phẩm</label>
                        <input type="text" class="form-control" id="ten_sp" name="ten_sp">
                        <?php $__errorArgs = ['ten_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="gia">Giá</label>
                        <input type="text" class="form-control" id="gia" name="gia">
                        <?php $__errorArgs = ['gia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div id="right">
                    <div class="form-group">
                        <label for="gia_cu">Giá Cũ</label>
                        <input type="text" class="form-control" id="gia_cu" name="gia_cu">
                        <?php $__errorArgs = ['gia_cu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="ma_loai">Loại</label>
                        <select name="ma_loai" id="ma_loai" class="form-control">
                            <?php if($maloai): ?>
                                <?php $__currentLoopData = $maloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maloai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($maloai->Ma_Loai); ?>"><?php echo e($maloai->Ten_loai); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                            
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="img">Ảnh</label>
                        <input type="file" class="form-control-file" id="img" name="img">
                        <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
            </div>
            <div>
                <label for="img">Mô tả</label>
                <textarea name="mo_ta" id="text"></textarea>
                <?php $__errorArgs = ['mo_ta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if(session('tb')): ?>
                    <p style="color: red">
                        <?php echo e(session('tb')); ?>

                    </p>
                <?php endif; ?>
            <input type="submit" class="btn " value="Thêm">
            
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/KLTN/resources/views/admin/product/create.blade.php ENDPATH**/ ?>